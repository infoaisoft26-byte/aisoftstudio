import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRole } from '../server/db/types';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  businessName?: string;
  phone?: string;
  status: string;
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  quickSwitchRole: (role: UserRole) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_CREDENTIALS: Record<UserRole, { email: string; pass: string }> = {
  super_admin: { email: 'admin@aisoft.studio', pass: 'StudioAdmin2026!' },
  staff: { email: 'staff@aisoft.studio', pass: 'Staff2026!' },
  developer: { email: 'dev@aisoft.studio', pass: 'Developer2026!' },
  client: { email: 'client@forma.com', pass: 'Client2026!' },
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('aisoft_auth_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Validate existing token on mount
  useEffect(() => {
    const fetchMe = async () => {
      const stored = localStorage.getItem('aisoft_auth_token');
      if (!stored) {
        setIsLoading(false);
        return;
      }

      try {
        const res = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${stored}` },
        });

        if (res.ok) {
          const data = await res.json();
          setUser(data.user);
          setToken(stored);
        } else {
          // Token expired or invalid
          localStorage.removeItem('aisoft_auth_token');
          setUser(null);
          setToken(null);
        }
      } catch (err) {
        console.error('Failed to restore session:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMe();
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed.' };
      }

      setUser(data.user);
      setToken(data.token);
      localStorage.setItem('aisoft_auth_token', data.token);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during login.' };
    }
  };

  const logout = () => {
    localStorage.removeItem('aisoft_auth_token');
    setUser(null);
    setToken(null);
  };

  const quickSwitchRole = async (role: UserRole) => {
    const creds = DEMO_CREDENTIALS[role];
    if (creds) {
      await login(creds.email, creds.pass);
    }
  };

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, logout, quickSwitchRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
};
