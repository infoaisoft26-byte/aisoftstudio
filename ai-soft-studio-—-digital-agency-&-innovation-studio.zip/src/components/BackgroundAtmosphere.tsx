import React, { useEffect, useRef } from 'react';

export const BackgroundAtmosphere: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Particle field
    const particleCount = 45;
    const particles = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 1.5 + 0.5,
      speedX: (Math.random() - 0.5) * 0.25,
      speedY: (Math.random() - 0.5) * 0.25,
      color: Math.random() > 0.4 ? 'rgba(255, 90, 31, ' : 'rgba(36, 75, 255, ',
      opacity: Math.random() * 0.4 + 0.1,
    }));

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw subtle particles
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${p.opacity})`;
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
      {/* Deep Navy Base */}
      <div className="absolute inset-0 bg-[#080D25]" />

      {/* Layer 2: Slow ambient neon orange and royal blue lights */}
      <div className="absolute -top-[20%] -right-[10%] w-[650px] h-[650px] rounded-full bg-[#244BFF]/15 blur-[140px] animate-pulse-slow" />
      <div className="absolute top-[35%] -left-[15%] w-[600px] h-[600px] rounded-full bg-[#FF5A1F]/12 blur-[150px] animate-pulse-slow" style={{ animationDelay: '4s' }} />
      <div className="absolute bottom-[10%] right-[10%] w-[700px] h-[700px] rounded-full bg-[#244BFF]/10 blur-[160px] animate-pulse-slow" style={{ animationDelay: '2s' }} />

      {/* Layer 3: Fine perspective grid */}
      <div className="absolute inset-0 bg-grid-pattern opacity-40 [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black_80%)]" />

      {/* Layer 4: Particle Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 opacity-60" />
    </div>
  );
};
