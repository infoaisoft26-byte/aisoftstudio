import React from 'react';
import { ArrowRight, ShieldCheck, Zap, Sparkles } from 'lucide-react';

interface FinalCTAProps {
  onStartProject: () => void;
  onExploreServices: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onStartProject, onExploreServices }) => {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-gradient-to-br from-[#0c133b] via-[#080d25] to-[#120a26] border border-white/15 p-8 sm:p-14 lg:p-16 overflow-hidden shadow-2xl">
          {/* Subtle glow accents */}
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 rounded-full bg-[#FF5A1F]/15 blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-[#244BFF]/20 blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-[#FF5A1F] uppercase tracking-wider mb-6">
              <Sparkles className="w-3.5 h-3.5 text-[#FF5A1F]" />
              <span>Ready To Elevate Your Digital Footprint?</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-6 leading-tight [text-wrap:balance]">
              Build The Digital Future Of Your Business Today.
            </h2>

            <p className="text-base sm:text-lg text-white/75 leading-relaxed mb-8 max-w-2xl">
              From flagship web experiences and autonomous AI pipelines to hardened cloud architectures, our engineers are ready to bring your vision to life.
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onStartProject}
                className="group inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white font-semibold text-sm shadow-[0_4px_25px_rgba(255,90,31,0.4)] hover:shadow-[0_4px_35px_rgba(255,90,31,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <span>Start Your Project</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                type="button"
                onClick={onExploreServices}
                className="inline-flex items-center justify-center px-7 py-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium text-sm transition-colors cursor-pointer"
              >
                <span>Explore Services</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
