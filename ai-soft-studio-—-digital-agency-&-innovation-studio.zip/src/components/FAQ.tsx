import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Shield, Clock, FileCheck2, Cpu } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  category: 'Engagement' | 'Process' | 'Security' | 'Technology';
}

const FAQ_LIST: FAQItem[] = [
  {
    category: 'Engagement',
    question: 'How do project engagements begin with AI SOFT STUDIO?',
    answer:
      'Every project begins with a structured project brief submitted through our inquiry form. Our engineering lead reviews your requirements, prepares a technical scope assessment and itemized quotation. Once the proposal and terms are approved, development milestones begin with assigned senior engineers.',
  },
  {
    category: 'Process',
    question: 'What is your typical turnaround timeline for custom development?',
    answer:
      'Standard high-performance websites and landing pages are typically delivered within 2–4 weeks. Complex AI automation pipelines, custom operations consoles, and headless e-commerce platforms range between 4–8 weeks depending on scope, API integrations, and milestone sign-offs.',
  },
  {
    category: 'Security',
    question: 'How are cybersecurity reviews and hardening assessments conducted?',
    answer:
      'All security assessments are strictly lawful, authorized, and non-destructive. Before any testing begins, we establish explicit written scope boundaries and obtain signed authorization from verified system owners. We audit access control, authentication routines, dependency vulnerabilities, and server configuration, providing detailed remediation roadmaps without ever disrupting live production environments.',
  },
  {
    category: 'Technology',
    question: 'What technologies and frameworks does the studio specialize in?',
    answer:
      'Our primary stack is built around React 19, TypeScript, modern Node.js/Express, and Vite, paired with Tailwind CSS for high-performance styling. For automation and intelligent workflows, we integrate official Gemini and LLM APIs, Webhooks, and secure database architectures.',
  },
  {
    category: 'Engagement',
    question: 'How do payments, invoices, and milestones work?',
    answer:
      'Projects are structured around transparent milestones. Invoices and payments are processed server-side through Razorpay or direct bank transfer, complete with itemized receipts and cryptographic transaction verification. Progress is tracked through client-accessible milestones.',
  },
  {
    category: 'Process',
    question: 'Do you work with existing systems or only build from scratch?',
    answer:
      'Both. We regularly architect bespoke digital solutions from the ground up, as well as integrate AI workflows, audit security configurations, or construct custom admin dashboards on top of existing business databases and APIs.',
  },
];

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="relative py-24 sm:py-32 border-t border-white/5 bg-[#080D25]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-20">
          <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
            Clear Answers
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-sm sm:text-base text-white/60">
            Everything you need to know about partnering with our technical studio, timelines, and deliverables.
          </p>
        </div>

        <div className="space-y-3">
          {FAQ_LIST.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-xl bg-white/[0.03] border border-white/10 hover:border-white/20 transition-all overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-white/5 text-white/50 border border-white/5">
                      {item.category}
                    </span>
                    <span className="text-sm sm:text-base font-semibold text-white/90">
                      {item.question}
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-4 h-4 text-white/60 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-[#FF5A1F]' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 sm:px-6 sm:pb-6 pt-0 text-xs sm:text-sm text-white/70 leading-relaxed border-t border-white/5 animate-in fade-in duration-150">
                    <p className="mt-3">{item.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
