import React, { useState } from 'react';
import { ArrowUpRight, Monitor, Smartphone, X, Layers, CheckCircle2 } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  category: 'Websites' | 'AI Automation' | 'E-Commerce' | 'Admin Panels';
  typeLabel: string;
  summary: string;
  challenge: string;
  solution: string;
  techStack: string[];
  imageSrc: string;
  aspectRatio: string;
  highlights: string[];
}

const PROJECTS_DATA: Project[] = [
  {
    id: 'forma-studio',
    title: 'FORMA Architectural Atelier',
    category: 'Websites',
    typeLabel: 'Design Concept · Website Development',
    summary:
      'High-performance editorial showcase designed for an architectural studio, featuring typography-driven project storytelling, smooth image transitions, and instant page transitions.',
    challenge:
      'Balancing high-resolution architectural imagery and editorial typography without degrading mobile load performance or scroll framerates.',
    solution:
      'Engineered a Vite/React application with modern WebP asset delivery, client-side route caching, and tailored CSS perspective transitions maintaining 60fps.',
    techStack: ['React 19', 'TypeScript', 'Tailwind CSS', 'Vite', 'Motion'],
    imageSrc: '/src/assets/images/project_web_modern_1791732642658.jpg',
    aspectRatio: '16/9',
    highlights: ['Sub-50ms navigation latency', 'Responsive across mobile to 4K', 'Zero layout shift'],
  },
  {
    id: 'cognitive-ops',
    title: 'Cognitive Ops Pipeline Architect',
    category: 'AI Automation',
    typeLabel: 'Design Concept · AI Automation',
    summary:
      'Visual node-based workflow orchestration dashboard that structures document ingestion, neural classification, and downstream automated action dispatch.',
    challenge:
      'Providing non-technical business operators with full transparency into multi-step LLM classification chains and automated webhook triggers.',
    solution:
      'Created an intuitive node graph interface with real-time throughput metrics, automated failover queues, and instant trace logging.',
    techStack: ['Google GenAI SDK', 'Node.js', 'React 19', 'TypeScript', 'Tailwind CSS'],
    imageSrc: '/src/assets/images/project_ai_automation_1791732668727.jpg',
    aspectRatio: '16/9',
    highlights: ['Multi-stage logic branching', 'Real-time telemetry tracking', 'Schema-enforced JSON validation'],
  },
  {
    id: 'maison-elixir',
    title: "Maison d'Elixir Boutique",
    category: 'E-Commerce',
    typeLabel: 'Design Concept · E-Commerce Development',
    summary:
      'Minimalist digital storefront for an artisanal luxury perfume brand, prioritizing unhurried product discovery, scent profile storytelling, and single-click checkout.',
    challenge:
      'Eliminating checkout friction and cluttered layouts common to generic multi-brand e-commerce templates.',
    solution:
      'Engineered a bespoke headless shopping experience with instantaneous cart drawer state, multi-currency pricing, and streamlined Stripe checkout flows.',
    techStack: ['React 19', 'Tailwind CSS', 'Stripe Elements', 'Vite', 'TypeScript'],
    imageSrc: '/src/assets/images/project_ecommerce_luxury_1791732691406.jpg',
    aspectRatio: '16/9',
    highlights: ['Frictionless 1-step cart', 'Dynamic fragrance note filter', 'High-contrast luxury palette'],
  },
  {
    id: 'opernx-console',
    title: 'OpernX Enterprise Console',
    category: 'Admin Panels',
    typeLabel: 'Design Concept · Custom Admin Panels',
    summary:
      'Operations mission control dashboard engineered for multi-tenant server management, incident monitoring, and automated resource reallocation.',
    challenge:
      'Displaying dense telemetry datasets without overwhelming operations personnel or slowing down interface responsiveness.',
    solution:
      'Developed a modular dark-mode dashboard with tabular numeric alignment, granular role-based access controls, and custom query filters.',
    techStack: ['React 19', 'TypeScript', 'Tailwind CSS', 'Express Backend', 'Tabular Metrics'],
    imageSrc: '/src/assets/images/project_admin_panel_1791732717020.jpg',
    aspectRatio: '16/9',
    highlights: ['Role-based access matrix', 'Tabular data sorting & filtering', 'Zero-latency system status'],
  },
];

type CategoryFilter = 'All' | 'Websites' | 'AI Automation' | 'E-Commerce' | 'Admin Panels';

interface SelectedWorkProps {
  onStartProject: () => void;
}

export const SelectedWork: React.FC<SelectedWorkProps> = ({ onStartProject }) => {
  const [activeFilter, setActiveFilter] = useState<CategoryFilter>('All');
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');

  const filteredProjects =
    activeFilter === 'All'
      ? PROJECTS_DATA
      : PROJECTS_DATA.filter((p) => p.category === activeFilter);

  const filterTabs: CategoryFilter[] = ['All', 'Websites', 'AI Automation', 'E-Commerce', 'Admin Panels'];

  return (
    <section id="work" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header and Filter Row */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-12 sm:mb-16">
          <div className="max-w-2xl">
            <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
              Selected Work & Concept Systems
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white [text-wrap:balance]">
              Built With Purpose. Designed To Stand Out.
            </h2>
            <p className="text-base text-white/70 mt-4 leading-relaxed">
              Explore recent architectural concepts and production systems crafted by AI SOFT STUDIO.
              Every interface is tailored to specific operational goals.
            </p>
          </div>

          {/* Interactive Filter Tabs (Buttons) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-white/5 border border-white/10 rounded-xl backdrop-blur-md self-start lg:self-end">
            {filterTabs.map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveFilter(tab)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeFilter === tab
                    ? 'bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white shadow-md shadow-[#FF5A1F]/30'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Editorial Project Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10">
          {filteredProjects.map((project) => (
            <article
              key={project.id}
              className="group rounded-2xl glass-surface overflow-hidden border border-white/10 hover:border-white/20 transition-all duration-300 flex flex-col justify-between"
            >
              {/* Media Preview Box */}
              <div
                className="relative overflow-hidden aspect-[16/9] bg-[#050818] cursor-pointer"
                onClick={() => {
                  setActiveProject(project);
                  setPreviewDevice('desktop');
                }}
              >
                <img
                  src={project.imageSrc}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  onError={(e) => {
                    // Fallback to stylized container on error
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                {/* Contrast Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#080D25] via-transparent to-transparent opacity-60 pointer-events-none" />

                {/* Hover Trigger Overlay */}
                <div className="absolute inset-0 bg-[#080D25]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
                  <span className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold text-white tracking-wide shadow-xl">
                    <span>Inspect System</span>
                    <ArrowUpRight className="w-4 h-4 text-[#FF5A1F]" />
                  </span>
                </div>
              </div>

              {/* Text & Content Block */}
              <div className="p-6 sm:p-8 flex flex-col justify-between flex-1">
                <div>
                  {/* Clean unboxed metadata with bullet separator */}
                  <div className="flex items-center gap-2 text-xs font-mono text-white/50 mb-2">
                    <span className="text-[#FF5A1F]">{project.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>Design Concept</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-bold font-heading text-white mb-3 group-hover:text-white transition-colors">
                    {project.title}
                  </h3>

                  <p className="text-sm text-white/70 leading-relaxed mb-6">
                    {project.summary}
                  </p>

                  {/* Highlights */}
                  <div className="space-y-1.5 mb-6">
                    {project.highlights.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-white/60">
                        <span className="w-1 h-1 rounded-full bg-[#244BFF]" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer Strip */}
                <div className="pt-5 border-t border-white/10 flex items-center justify-between">
                  <div className="flex flex-wrap gap-1.5">
                    {project.techStack.slice(0, 3).map((tech) => (
                      <span
                        key={tech}
                        className="text-[11px] font-mono text-white/60 bg-white/5 px-2 py-0.5 rounded border border-white/5"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setActiveProject(project);
                      setPreviewDevice('desktop');
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#FF5A1F] hover:text-[#FF7A00] transition-colors cursor-pointer"
                  >
                    <span>View Details</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Project Deep Dive Modal */}
      {activeProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl bg-[#080D25] border border-white/15 p-6 sm:p-8 shadow-2xl">
            {/* Modal Close Button */}
            <button
              onClick={() => setActiveProject(null)}
              className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="mb-6">
              <div className="flex items-center gap-2 text-xs font-mono text-[#FF5A1F] mb-1">
                <span>{activeProject.typeLabel}</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold font-heading text-white">
                {activeProject.title}
              </h3>
            </div>

            {/* Device Preview Controls */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-white/50">DEVICE VIEWPORT SIMULATION</span>
              <div className="flex items-center gap-1 bg-white/5 p-1 rounded-lg border border-white/10">
                <button
                  type="button"
                  onClick={() => setPreviewDevice('desktop')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-mono transition-colors ${
                    previewDevice === 'desktop'
                      ? 'bg-white/20 text-white font-semibold'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDevice('mobile')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-mono transition-colors ${
                    previewDevice === 'mobile'
                      ? 'bg-white/20 text-white font-semibold'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Mobile Frame</span>
                </button>
              </div>
            </div>

            {/* Mockup Display Box */}
            <div className="relative mb-8 bg-[#040612] rounded-xl border border-white/10 p-2 sm:p-4 flex items-center justify-center overflow-hidden">
              {previewDevice === 'desktop' ? (
                <div className="w-full rounded-lg overflow-hidden border border-white/10 shadow-2xl">
                  {/* Browser Bar */}
                  <div className="bg-[#0b102e] px-4 py-2 border-b border-white/10 flex items-center gap-2">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                      <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                    </div>
                    <div className="text-[11px] font-mono text-white/40 px-3 py-0.5 rounded bg-black/40 border border-white/5 mx-auto">
                      https://preview.aisoftstudio.internal/{activeProject.id}
                    </div>
                  </div>
                  <img
                    src={activeProject.imageSrc}
                    alt={activeProject.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-auto object-cover max-h-[440px]"
                  />
                </div>
              ) : (
                <div className="w-[280px] sm:w-[320px] rounded-[32px] overflow-hidden border-4 border-slate-700 bg-black shadow-2xl my-2">
                  <div className="h-4 bg-black flex justify-center items-center">
                    <div className="w-16 h-2 bg-neutral-800 rounded-full" />
                  </div>
                  <img
                    src={activeProject.imageSrc}
                    alt={activeProject.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-[400px] object-cover"
                  />
                </div>
              )}
            </div>

            {/* Architecture & Objectives Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10">
                <h4 className="text-xs font-mono uppercase tracking-wider text-[#FF5A1F] mb-2 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  Project Objective
                </h4>
                <p className="text-xs sm:text-sm text-white/80 leading-relaxed">
                  {activeProject.challenge}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10">
                <h4 className="text-xs font-mono uppercase tracking-wider text-[#244BFF] mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Technical Solution
                </h4>
                <p className="text-xs sm:text-sm text-white/80 leading-relaxed">
                  {activeProject.solution}
                </p>
              </div>
            </div>

            {/* Technology Stack List */}
            <div className="mb-6">
              <div className="text-xs font-mono text-white/50 mb-2">Technology Stack</div>
              <div className="flex flex-wrap gap-2">
                {activeProject.techStack.map((tech) => (
                  <span
                    key={tech}
                    className="px-2.5 py-1 text-xs font-mono bg-white/5 text-white/80 rounded border border-white/10"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Modal Bottom CTAs */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setActiveProject(null)}
                className="px-4 py-2.5 text-xs font-medium text-white/70 hover:text-white rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                Close Preview
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveProject(null);
                  onStartProject();
                }}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] rounded-lg shadow-lg shadow-[#FF5A1F]/30 hover:shadow-[#FF5A1F]/50 transition-all cursor-pointer"
              >
                <span>Discuss Similar Project</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
