import React, { useState } from 'react';
import { Search, Compass, Code, Rocket, CheckCircle2 } from 'lucide-react';

interface ProcessStep {
  step: string;
  name: string;
  headline: string;
  description: string;
  details: string[];
  duration: string;
}

const STEPS: ProcessStep[] = [
  {
    step: '01',
    name: 'Discover',
    headline: 'Understanding Core Business Goals & Workflows',
    description:
      'We begin by analyzing your existing operational workflows, target audiences, and technical requirements to define a concise, unbloated project specification.',
    details: [
      'Technical requirements & API feasibility audit',
      'User journey mapping & friction point identification',
      'Target performance benchmarks and scope definition',
      'Milestone timeline & architecture blueprint',
    ],
    duration: 'Week 1',
  },
  {
    step: '02',
    name: 'Design',
    headline: 'Bespoke UI Systems & High-Fidelity Prototypes',
    description:
      'We craft tailored visual languages, responsive components, and fluid interaction patterns tailored exclusively to your brand identity—never using generic templates.',
    details: [
      'High-contrast visual design system (typography, colors, tokens)',
      'Responsive wireframes for mobile, tablet, and desktop',
      'Interaction prototypes and micro-animation specs',
      'Stakeholder review and rapid design refinement',
    ],
    duration: 'Weeks 2 – 3',
  },
  {
    step: '03',
    name: 'Develop',
    headline: 'Production-Grade Engineering & Clean Integrations',
    description:
      'Our senior engineers build your product using modern, type-safe frameworks. Clean architectures, zero layout shift, and robust server connections are prioritized throughout.',
    details: [
      'Type-safe React, TypeScript, and modern styling implementation',
      'REST & webhook integration with persistent databases',
      'Rigorous cross-browser testing across mobile and desktop devices',
      'Performance profiling for sub-second load times',
    ],
    duration: 'Weeks 3 – 5',
  },
  {
    step: '04',
    name: 'Launch',
    headline: 'Deployment, Monitoring & Seamless Handover',
    description:
      'We orchestrate a zero-downtime production deployment, configure live monitoring, implement SEO structured metadata, and provide thorough technical documentation.',
    details: [
      'Production deployment on high-availability cloud infrastructure',
      'Domain DNS routing, SSL security, and CDN caching configuration',
      'Structured JSON-LD schema & social preview setup',
      'Comprehensive codebase handover and team walkthrough',
    ],
    duration: 'Week 6 & Handover',
  },
];

export const CreativeProcess: React.FC = () => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const getStepIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Search className="w-5 h-5 text-[#FF5A1F]" />;
      case 1:
        return <Compass className="w-5 h-5 text-[#244BFF]" />;
      case 2:
        return <Code className="w-5 h-5 text-[#FF5A1F]" />;
      case 3:
        return <Rocket className="w-5 h-5 text-[#244BFF]" />;
      default:
        return <Search className="w-5 h-5 text-[#FF5A1F]" />;
    }
  };

  return (
    <section id="process" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16 sm:mb-20">
          <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
            Execution Methodology
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-5 [text-wrap:balance]">
            From First Idea To Final Launch.
          </h2>
          <p className="text-base sm:text-lg text-white/70 leading-relaxed">
            A transparent four-phase delivery framework that ensures structured execution, fixed scopes,
            and predictable, high-quality results.
          </p>
        </div>

        {/* Desktop Connected Steps Bar */}
        <div className="relative mb-14 hidden md:block">
          {/* Neon Orange Connecting Line */}
          <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 h-[2px] bg-white/10">
            <div
              className="h-full bg-gradient-to-r from-[#FF5A1F] via-[#FF7A00] to-[#244BFF] transition-all duration-500 shadow-[0_0_12px_#FF5A1F]"
              style={{
                width: `${((activeStepIndex + 1) / STEPS.length) * 100}%`,
              }}
            />
          </div>

          {/* Step Trigger Nodes */}
          <div className="relative flex justify-between">
            {STEPS.map((step, index) => {
              const isActive = index === activeStepIndex;
              const isPassed = index < activeStepIndex;

              return (
                <button
                  key={step.step}
                  type="button"
                  onClick={() => setActiveStepIndex(index)}
                  className="group flex flex-col items-center cursor-pointer focus:outline-none"
                >
                  {/* Circle Node with Royal Blue Pulse */}
                  <div
                    className={`relative w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 border ${
                      isActive
                        ? 'bg-[#080D25] border-[#FF5A1F] shadow-[0_0_20px_rgba(255,90,31,0.6)] scale-110'
                        : isPassed
                        ? 'bg-[#080D25] border-[#244BFF] text-white'
                        : 'bg-[#080D25] border-white/20 text-white/40'
                    }`}
                  >
                    {isActive && (
                      <span className="absolute inset-0 rounded-full bg-[#244BFF]/30 animate-ping pointer-events-none" />
                    )}
                    {getStepIcon(index)}
                  </div>

                  {/* Step Label */}
                  <div className="mt-3 text-center">
                    <span
                      className={`text-xs font-mono block transition-colors ${
                        isActive ? 'text-[#FF5A1F] font-bold' : 'text-white/50'
                      }`}
                    >
                      {step.step} — {step.name}
                    </span>
                    <span className="text-[11px] text-white/30">{step.duration}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Step Editorial Card */}
        <div className="glass-surface rounded-2xl p-6 sm:p-10 border border-white/10 shadow-2xl relative overflow-hidden">
          {/* Subtle Ambient Accent */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#FF5A1F]/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#244BFF]/5 rounded-full blur-3xl pointer-events-none" />

          {/* Mobile Step Selector Pills */}
          <div className="flex md:hidden gap-2 overflow-x-auto pb-4 mb-6 border-b border-white/10">
            {STEPS.map((step, index) => (
              <button
                key={step.step}
                type="button"
                onClick={() => setActiveStepIndex(index)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-colors ${
                  activeStepIndex === index
                    ? 'bg-[#FF5A1F] text-white'
                    : 'bg-white/5 text-white/60 hover:text-white'
                }`}
              >
                {step.step} · {step.name}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Narrative */}
            <div className="lg:col-span-7">
              <div className="flex items-center gap-2 text-xs font-mono text-[#FF5A1F] mb-2">
                <span>Phase {STEPS[activeStepIndex].step}</span>
                <span aria-hidden="true">·</span>
                <span>{STEPS[activeStepIndex].duration}</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-bold font-heading text-white mb-4">
                {STEPS[activeStepIndex].headline}
              </h3>

              <p className="text-sm sm:text-base text-white/75 leading-relaxed mb-6">
                {STEPS[activeStepIndex].description}
              </p>

              {/* Progress Stepper Controls */}
              <div className="flex items-center gap-3 pt-4">
                <button
                  type="button"
                  disabled={activeStepIndex === 0}
                  onClick={() => setActiveStepIndex((prev) => Math.max(0, prev - 1))}
                  className="px-4 py-2 rounded-lg text-xs font-mono border border-white/10 bg-white/5 hover:bg-white/10 text-white disabled:opacity-30 disabled:pointer-events-none transition-colors"
                >
                  ← Previous Phase
                </button>
                <button
                  type="button"
                  disabled={activeStepIndex === STEPS.length - 1}
                  onClick={() => setActiveStepIndex((prev) => Math.min(STEPS.length - 1, prev + 1))}
                  className="px-4 py-2 rounded-lg text-xs font-mono bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white disabled:opacity-30 disabled:pointer-events-none transition-colors shadow-md shadow-[#FF5A1F]/30"
                >
                  Next Phase →
                </button>
              </div>
            </div>

            {/* Right Column: Execution Checklist */}
            <div className="lg:col-span-5 bg-white/[0.02] p-5 sm:p-6 rounded-xl border border-white/10">
              <div className="text-xs font-mono text-white/50 uppercase tracking-wider mb-4">
                Phase Deliverables & Verification
              </div>
              <ul className="space-y-3">
                {STEPS[activeStepIndex].details.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-white/80">
                    <CheckCircle2 className="w-4 h-4 text-[#FF5A1F] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
