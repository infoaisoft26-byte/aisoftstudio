import React from 'react';
import { X, Shield, FileText, CheckCircle2 } from 'lucide-react';

interface LegalModalProps {
  type: 'privacy' | 'terms' | null;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl max-h-[85vh] rounded-2xl bg-[#080D25] border border-white/20 p-6 sm:p-8 shadow-2xl overflow-y-auto space-y-6 text-white/80 animate-in fade-in zoom-in-95 duration-200">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {type === 'privacy' ? (
          <>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FF5A1F]/20 border border-[#FF5A1F]/30 flex items-center justify-center text-[#FF5A1F]">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold font-heading text-white">Privacy Policy</h2>
                <p className="text-xs text-white/40 font-mono">Last updated: October 2026</p>
              </div>
            </div>

            <div className="space-y-4 text-xs sm:text-sm leading-relaxed text-white/70">
              <p>
                <strong className="text-white">1. Data Collection & Purpose:</strong> AI SOFT STUDIO collects information provided directly by prospective and active clients through our project inquiry form, scope estimator, and consultation channels (such as name, work email, phone number, company name, and project descriptions). This data is strictly utilized to evaluate architectural feasibility, prepare proposals, and communicate regarding project execution.
              </p>
              <p>
                <strong className="text-white">2. No Third-Party Sales or Brokerage:</strong> We never sell, lease, or monetize client contact information or project briefs to third-party advertisers or data brokers.
              </p>
              <p>
                <strong className="text-white">3. Security & Zero-Trust Storage:</strong> Submitted inquiries are stored persistently on authenticated server databases protected by cryptographic hashing, rate limits, and access controls restricted to authorized internal studio personnel.
              </p>
              <p>
                <strong className="text-white">4. Payment Processing:</strong> Payments and invoices are verified server-side through Razorpay. AI SOFT STUDIO does not store or process sensitive credit/debit card numbers in browser storage or local databases.
              </p>
              <p>
                <strong className="text-white">5. Security Testing Scope:</strong> Cybersecurity assessments are conducted exclusively under written, bilateral authorization from verified asset owners. We do not inspect or test systems without verifiable authority.
              </p>
              <p>
                <strong className="text-white">6. Contact & Data Deletion:</strong> You may request review or deletion of your submitted inquiry data at any time by contacting our data protection officer at <span className="text-[#FF5A1F] font-mono">infoaisoft26@gmail.com</span>.
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#244BFF]/20 border border-[#244BFF]/30 flex items-center justify-center text-[#244BFF]">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold font-heading text-white">Terms of Service</h2>
                <p className="text-xs text-white/40 font-mono">Standard Studio Agreement · October 2026</p>
              </div>
            </div>

            <div className="space-y-4 text-xs sm:text-sm leading-relaxed text-white/70">
              <p>
                <strong className="text-white">1. Engagement & Deliverables:</strong> All professional development, automation engineering, and design services are defined in individualized Statements of Work (SOW) and formal quotations containing explicit milestone specifications and deliverables.
              </p>
              <p>
                <strong className="text-white">2. Quotations & Validity:</strong> Quotations issued by AI SOFT STUDIO remain valid for fourteen (14) calendar days unless otherwise specified in the formal proposal.
              </p>
              <p>
                <strong className="text-white">3. Intellectual Property:</strong> Upon final milestone completion and settlement of outstanding invoice balances, intellectual property rights and code repositories are transferred to the client in accordance with project agreement terms.
              </p>
              <p>
                <strong className="text-white">4. Lawful Cybersecurity Protocols:</strong> Cybersecurity assessments, vulnerability scans, and access audits are conducted strictly under written authorization. Clients must possess lawful authority over target systems. Unlawful scanning or attacks on unauthorized systems are explicitly prohibited.
              </p>
              <p>
                <strong className="text-white">5. Governing Jurisdiction:</strong> These terms are governed in accordance with international digital commerce practices and applicable jurisdictional standards.
              </p>
            </div>
          </>
        )}

        <div className="pt-4 border-t border-white/10 text-right">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-mono transition-colors cursor-pointer"
          >
            Close Document
          </button>
        </div>
      </div>
    </div>
  );
};
