import React, { useState } from 'react';
import { ArrowUp, ShieldCheck } from 'lucide-react';
import { LegalModal } from './LegalModal';

export const Footer: React.FC = () => {
  const [legalType, setLegalType] = useState<'privacy' | 'terms' | null>(null);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <footer className="relative border-t border-white/10 bg-[#060A1F] py-16 text-white/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12 pb-12 border-b border-white/10">
            {/* Brand Column */}
            <div className="md:col-span-5">
              <div className="flex items-center gap-2 text-xl font-bold font-heading text-white tracking-tight mb-3">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A1F]" />
                <span>AI SOFT STUDIO</span>
              </div>
              <p className="text-sm font-semibold text-white/90 mb-1">
                Your Vision. Our Innovation.
              </p>
              <p className="text-xs font-mono text-[#FF5A1F] mb-4">
                Design. Develop. Secure. Automate. Grow.
              </p>
              <p className="text-xs text-white/60 leading-relaxed max-w-sm">
                Modern digital technology studio specializing in high-performance website development,
                practical AI automation, e-commerce solutions, cybersecurity reviews, and custom admin panels.
              </p>
            </div>

            {/* Quick Links */}
            <div className="md:col-span-3">
              <div className="text-xs font-mono uppercase tracking-wider text-white/40 mb-4">
                Navigation
              </div>
              <ul className="space-y-2.5 text-xs sm:text-sm">
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    Studio Services
                  </a>
                </li>
                <li>
                  <a href="#work" className="hover:text-white transition-colors">
                    Selected Work & Concepts
                  </a>
                </li>
                <li>
                  <a href="#process" className="hover:text-white transition-colors">
                    Creative Process
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-white transition-colors">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#about" className="hover:text-white transition-colors">
                    Why AI SOFT STUDIO
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-white transition-colors">
                    Start a Project
                  </a>
                </li>
              </ul>
            </div>

            {/* Core Services */}
            <div className="md:col-span-4">
              <div className="text-xs font-mono uppercase tracking-wider text-white/40 mb-4">
                Focus Disciplines
              </div>
              <ul className="space-y-2 text-xs text-white/60">
                <li>Website Architecture & Development</li>
                <li>Workflow AI & Process Automation</li>
                <li>Headless E-commerce Solutions</li>
                <li>Custom Operations Admin Dashboards</li>
                <li>Lawful Cybersecurity & Hardening Reviews</li>
              </ul>
              <div className="mt-6 pt-4 border-t border-white/5">
                <div className="text-xs font-mono text-white/40 mb-1">Direct Contact</div>
                <a
                  href="mailto:infoaisoft26@gmail.com"
                  className="text-xs font-mono text-white/80 hover:text-[#FF5A1F] transition-colors"
                >
                  infoaisoft26@gmail.com
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-white/40">
            <div>
              © {new Date().getFullYear()} AI SOFT STUDIO. All rights reserved.
            </div>

            <div className="flex items-center gap-6">
              <button
                type="button"
                onClick={() => setLegalType('privacy')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Privacy Policy
              </button>
              <button
                type="button"
                onClick={() => setLegalType('terms')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Terms of Service
              </button>
              <button
                type="button"
                onClick={scrollToTop}
                className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
              >
                <span>Back to Top</span>
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </footer>

      <LegalModal type={legalType} onClose={() => setLegalType(null)} />
    </>
  );
};

