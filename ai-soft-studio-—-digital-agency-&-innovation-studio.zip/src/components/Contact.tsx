import React, { useState, useEffect } from 'react';
import { Send, CheckCircle2, AlertCircle, RefreshCw, Mail, Clock, ArrowRight, ShieldCheck, Database, Sliders, X } from 'lucide-react';
import { ScopeEstimate } from './ScopeEstimator';

interface ContactProps {
  preselectedService?: string;
  appliedScopeEstimate?: ScopeEstimate | null;
  onClearAppliedEstimate?: () => void;
}

interface SubmittedReceipt {
  enquiryId: string;
  createdAt: string;
  name: string;
  email: string;
  phone?: string;
  businessName?: string;
  service: string;
  preferredContactMethod?: string;
  budgetRange?: string;
  message: string;
}

interface StoredEnquirySummary {
  id: string;
  name: string;
  businessName?: string;
  service: string;
  createdAt: string;
  status: string;
}

export const Contact: React.FC<ContactProps> = ({
  preselectedService,
  appliedScopeEstimate,
  onClearAppliedEstimate,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    businessName: '',
    service: preselectedService || 'Website Development',
    budgetRange: '$5,000 – $15,000',
    timeline: '1–3 Months',
    projectDescription: '',
    preferredContactMethod: 'Email' as 'Email' | 'Phone' | 'WhatsApp',
    privacyConsent: false,
    website_url: '', // Honeypot spam trap
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<SubmittedReceipt | null>(null);
  const [showEnquiryRegistry, setShowEnquiryRegistry] = useState(false);
  const [storedList, setStoredList] = useState<StoredEnquirySummary[]>([]);
  const [registryLoading, setRegistryLoading] = useState(false);

  useEffect(() => {
    if (appliedScopeEstimate) {
      setFormData((prev) => ({
        ...prev,
        service: appliedScopeEstimate.service,
        timeline: appliedScopeEstimate.pace,
        projectDescription: `Project Scope Requirement:
• Track: ${appliedScopeEstimate.service} (${appliedScopeEstimate.scaleLabel})
• Architecture Tier: ${appliedScopeEstimate.complexityTier}
• Estimated Sprint: ${appliedScopeEstimate.estimatedWeeks}
• Target Features: ${appliedScopeEstimate.selectedFeatures.length > 0 ? appliedScopeEstimate.selectedFeatures.join(', ') : 'Core Architecture'}

Additional requirements / context: `,
      }));
    } else if (preselectedService) {
      setFormData((prev) => ({ ...prev, service: preselectedService }));
    }
  }, [appliedScopeEstimate, preselectedService]);

  const fetchRegistry = async () => {
    setRegistryLoading(true);
    try {
      const res = await fetch('/api/enquiry-summary');
      if (res.ok) {
        const data = await res.json();
        setStoredList(data.enquiries || []);
      }
    } catch {
      // ignore
    } finally {
      setRegistryLoading(false);
    }
  };

  const handleToggleRegistry = () => {
    if (!showEnquiryRegistry) {
      fetchRegistry();
    }
    setShowEnquiryRegistry(!showEnquiryRegistry);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Client-side quick validation before submission
    if (!formData.name.trim() || formData.name.trim().length < 2) {
      setError('Please provide your name (at least 2 characters).');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email.trim())) {
      setError('Please enter a valid work email address.');
      return;
    }

    if (!formData.projectDescription.trim() || formData.projectDescription.trim().length < 15) {
      setError('Please describe your project scope (minimum 15 characters).');
      return;
    }

    if (!formData.privacyConsent) {
      setError('Please agree to the privacy policy to submit your project brief.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const result = await res.json();

      if (!res.ok) {
        throw new Error(result.error || 'Server error submitting project enquiry.');
      }

      setReceipt({
        enquiryId: result.enquiryId,
        createdAt: result.createdAt,
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim() || undefined,
        businessName: formData.businessName.trim() || undefined,
        service: formData.service,
        preferredContactMethod: formData.preferredContactMethod,
        budgetRange: formData.budgetRange,
        message: result.message,
      });

      // Reset form after successful confirmation
      setFormData({
        name: '',
        email: '',
        phone: '',
        businessName: '',
        service: 'Website Development',
        budgetRange: '$5,000 – $15,000',
        timeline: '1–3 Months',
        projectDescription: '',
        preferredContactMethod: 'Email',
        privacyConsent: false,
        website_url: '',
      });
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred. Your form inputs remain saved.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Context & Direct Contact */}
          <div className="lg:col-span-5">
            <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
              Initiate Collaboration
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-5 [text-wrap:balance]">
              Have An Idea? Let's Build It.
            </h2>
            <p className="text-base text-white/70 leading-relaxed mb-8">
              Tell us what you want to create. Let's explore the right digital solution for your business.
              We review every scope detail and reply with architectural recommendations and timeline estimates.
            </p>

            {/* Studio Coordinates */}
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 text-sm text-white/80">
                <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-[#FF5A1F]">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-white/40 uppercase">Direct Studio Inbox</div>
                  <a
                    href="mailto:infoaisoft26@gmail.com"
                    className="hover:text-[#FF5A1F] transition-colors"
                  >
                    infoaisoft26@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 text-sm text-white/80">
                <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-[#244BFF]">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-white/40 uppercase">Response Time</div>
                  <div className="text-white/80">Within 24 business hours with initial analysis</div>
                </div>
              </div>

              <div className="flex items-center gap-3 text-sm text-white/80">
                <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-white/60">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-white/40 uppercase">Confidentiality</div>
                  <div className="text-white/80">Mutual NDA provided on request</div>
                </div>
              </div>
            </div>

            {/* Real Backend Verification Toggle */}
            <div className="pt-6 border-t border-white/10">
              <button
                type="button"
                onClick={handleToggleRegistry}
                className="inline-flex items-center gap-2 text-xs font-mono text-white/50 hover:text-white transition-colors cursor-pointer"
              >
                <Database className="w-3.5 h-3.5 text-[#244BFF]" />
                <span>
                  {showEnquiryRegistry ? 'Hide Live Enquiry Log' : 'Inspect Live Studio Submissions'}
                </span>
              </button>

              {showEnquiryRegistry && (
                <div className="mt-3 p-4 rounded-xl bg-black/40 border border-white/10 text-xs font-mono">
                  <div className="flex items-center justify-between mb-2 text-white/60">
                    <span>Persistent Backend Enquiries</span>
                    <button
                      type="button"
                      onClick={fetchRegistry}
                      className="text-[#FF5A1F] hover:underline"
                    >
                      Refresh
                    </button>
                  </div>
                  {registryLoading ? (
                    <div className="py-2 text-white/40">Loading records...</div>
                  ) : storedList.length === 0 ? (
                    <div className="py-2 text-white/40">No enquiries submitted yet. Submit one to test!</div>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {storedList.slice(0, 5).map((e) => (
                        <div
                          key={e.id}
                          className="p-2 rounded bg-white/5 border border-white/5 flex items-center justify-between"
                        >
                          <div>
                            <span className="text-[#FF5A1F] font-bold">{e.id}</span>
                            <span className="text-white/40 mx-1.5">·</span>
                            <span className="text-white/80">{e.name}</span>
                            <div className="text-[10px] text-white/40">{e.service}</div>
                          </div>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {e.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Functional Form / Verified Submission Receipt */}
          <div className="lg:col-span-7">
            <div className="glass-surface rounded-2xl p-6 sm:p-10 border border-white/10 shadow-2xl relative">
              {receipt ? (
                /* Verified Success State */
                <div className="py-6 flex flex-col items-start animate-in fade-in zoom-in-95 duration-300">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-6">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>

                  <div className="text-xs font-mono text-emerald-400 uppercase tracking-wider mb-1">
                    Enquiry Registered Successfully
                  </div>

                  <h3 className="text-2xl sm:text-3xl font-bold font-heading text-white mb-3">
                    Thank You, {receipt.name}.
                  </h3>

                  <p className="text-sm text-white/75 leading-relaxed mb-6">
                    {receipt.message}
                  </p>

                  {/* Submission Receipt Box */}
                  <div className="w-full p-5 rounded-xl bg-white/[0.03] border border-white/10 mb-8 font-mono text-xs space-y-2.5">
                    <div className="flex justify-between border-b border-white/5 pb-2">
                      <span className="text-white/40">Tracking Reference</span>
                      <span className="text-[#FF5A1F] font-bold">{receipt.enquiryId}</span>
                    </div>
                    <div className="flex justify-between border-b border-white/5 pb-2">
                      <span className="text-white/40">Work Email</span>
                      <span className="text-white/80">{receipt.email}</span>
                    </div>
                    {receipt.businessName && (
                      <div className="flex justify-between border-b border-white/5 pb-2">
                        <span className="text-white/40">Business</span>
                        <span className="text-white/80">{receipt.businessName}</span>
                      </div>
                    )}
                    <div className="flex justify-between border-b border-white/5 pb-2">
                      <span className="text-white/40">Requested Service</span>
                      <span className="text-white/80">{receipt.service}</span>
                    </div>
                    {receipt.phone && (
                      <div className="flex justify-between border-b border-white/5 pb-2">
                        <span className="text-white/40">Phone Contact</span>
                        <span className="text-white/80">{receipt.phone}</span>
                      </div>
                    )}
                    {receipt.preferredContactMethod && (
                      <div className="flex justify-between border-b border-white/5 pb-2">
                        <span className="text-white/40">Preferred Channel</span>
                        <span className="text-white/80">{receipt.preferredContactMethod}</span>
                      </div>
                    )}
                    {receipt.budgetRange && (
                      <div className="flex justify-between border-b border-white/5 pb-2">
                        <span className="text-white/40">Budget Range</span>
                        <span className="text-white/80">{receipt.budgetRange}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-white/40">Timestamp</span>
                      <span className="text-white/60">
                        {new Date(receipt.createdAt).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setReceipt(null)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono text-white/80 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors cursor-pointer"
                  >
                    <span>Submit Another Enquiry</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                /* Functional Form */
                <form onSubmit={handleSubmit} noValidate>
                  {appliedScopeEstimate && (
                    <div className="mb-6 p-4 rounded-xl bg-[#FF5A1F]/10 border border-[#FF5A1F]/30 flex items-start justify-between gap-3 text-xs animate-in fade-in duration-200">
                      <div className="flex items-start gap-2.5">
                        <Sliders className="w-4 h-4 text-[#FF5A1F] shrink-0 mt-0.5" />
                        <div>
                          <div className="font-mono text-[#FF5A1F] font-semibold">
                            Scope Estimate Applied
                          </div>
                          <div className="text-white/80 mt-0.5 font-mono text-[11px]">
                            {appliedScopeEstimate.service} · {appliedScopeEstimate.scaleLabel} · {appliedScopeEstimate.estimatedWeeks}
                          </div>
                        </div>
                      </div>
                      {onClearAppliedEstimate && (
                        <button
                          type="button"
                          onClick={onClearAppliedEstimate}
                          className="p-1 rounded text-white/50 hover:text-white transition-colors"
                          aria-label="Remove applied estimate"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}

                  {error && (
                    <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 flex items-start gap-3 text-red-200 text-xs">
                      <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                      <div className="leading-relaxed">{error}</div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    {/* Name */}
                    <div>
                      <label className="block text-xs font-mono text-white/70 mb-2">
                        Full Name <span className="text-[#FF5A1F]">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Elena Vance"
                        className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm placeholder:text-white/30 transition-colors"
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block text-xs font-mono text-white/70 mb-2">
                        Work Email <span className="text-[#FF5A1F]">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="elena@company.com"
                        className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm placeholder:text-white/30 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    {/* Phone Number (Optional) */}
                    <div>
                      <label className="block text-xs font-mono text-white/70 mb-2">
                        Phone Number with Country Code <span className="text-white/40">(Optional)</span>
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+1 (555) 019-2831"
                        className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm placeholder:text-white/30 transition-colors font-mono"
                      />
                    </div>

                    {/* Business Name */}
                    <div>
                      <label className="block text-xs font-mono text-white/70 mb-2">
                        Company Name <span className="text-white/40">(Optional)</span>
                      </label>
                      <input
                        type="text"
                        value={formData.businessName}
                        onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                        placeholder="Company or Brand"
                        className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm placeholder:text-white/30 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    {/* Service Required */}
                    <div>
                      <label className="block text-xs font-mono text-white/70 mb-2">
                        Required Service <span className="text-[#FF5A1F]">*</span>
                      </label>
                      <select
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#080D25] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm transition-colors cursor-pointer"
                      >
                        <option value="Website Development">Website Development</option>
                        <option value="AI Automation">AI Automation</option>
                        <option value="E-commerce Solutions">E-commerce Solutions</option>
                        <option value="Custom Admin Panels">Custom Admin Panels</option>
                        <option value="Cybersecurity & Hardening">Cybersecurity & Hardening (Authorized)</option>
                        <option value="Custom Digital Solution">Custom Full-Stack Solution</option>
                      </select>
                    </div>

                    {/* Budget Range (Optional) */}
                    <div>
                      <label className="block text-xs font-mono text-white/70 mb-2">
                        Budget Range <span className="text-white/40">(Optional)</span>
                      </label>
                      <select
                        value={formData.budgetRange}
                        onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#080D25] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm transition-colors cursor-pointer"
                      >
                        <option value="< $5,000">&lt; $5,000</option>
                        <option value="$5,000 – $15,000">$5,000 – $15,000</option>
                        <option value="$15,000 – $35,000">$15,000 – $35,000</option>
                        <option value="$35,000+">$35,000+ Enterprise</option>
                        <option value="Flexible / Needs Estimation">Flexible / Needs Scope Estimation</option>
                      </select>
                    </div>
                  </div>

                  {/* Preferred Contact Method */}
                  <div className="mb-5">
                    <label className="block text-xs font-mono text-white/70 mb-2">
                      Preferred Contact Method
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['Email', 'Phone', 'WhatsApp'] as const).map((method) => (
                        <button
                          key={method}
                          type="button"
                          onClick={() => setFormData({ ...formData, preferredContactMethod: method })}
                          className={`px-3 py-2.5 rounded-xl text-xs font-mono border transition-all cursor-pointer ${
                            formData.preferredContactMethod === method
                              ? 'bg-[#FF5A1F]/15 border-[#FF5A1F] text-white font-semibold'
                              : 'bg-white/[0.02] border-white/10 text-white/60 hover:text-white'
                          }`}
                        >
                          {method}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Honeypot Spam Trap (Hidden) */}
                  <div className="hidden" aria-hidden="true">
                    <input
                      type="text"
                      name="website_url"
                      tabIndex={-1}
                      autoComplete="off"
                      value={formData.website_url}
                      onChange={(e) => setFormData({ ...formData, website_url: e.target.value })}
                    />
                  </div>

                  {/* Project Description */}
                  <div className="mb-5">
                    <label className="block text-xs font-mono text-white/70 mb-2">
                      Project Description <span className="text-[#FF5A1F]">*</span>
                    </label>
                    <textarea
                      rows={4}
                      required
                      value={formData.projectDescription}
                      onChange={(e) => setFormData({ ...formData, projectDescription: e.target.value })}
                      placeholder="Briefly describe what you are looking to build, desired features, target systems or key operational challenges..."
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 focus:border-[#FF5A1F] focus:outline-none text-white text-sm placeholder:text-white/30 transition-colors resize-y min-h-[110px]"
                    />
                  </div>

                  {/* Timeline Selection */}
                  <div className="mb-6">
                    <label className="block text-xs font-mono text-white/70 mb-2">
                      Target Timeline <span className="text-white/40">(Optional)</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {['Urgent (< 1 Mo)', '1–3 Months', '3–6 Months', 'Flexible'].map((time) => (
                        <button
                          key={time}
                          type="button"
                          onClick={() => setFormData({ ...formData, timeline: time })}
                          className={`px-3 py-2 rounded-lg text-xs font-mono border transition-all cursor-pointer ${
                            formData.timeline === time
                              ? 'bg-white/10 border-[#FF5A1F] text-white shadow-sm'
                              : 'bg-white/[0.02] border-white/10 text-white/50 hover:text-white'
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Privacy Policy Consent Checkbox */}
                  <div className="mb-7 flex items-start gap-3">
                    <input
                      type="checkbox"
                      id="privacyConsent"
                      required
                      checked={formData.privacyConsent}
                      onChange={(e) => setFormData({ ...formData, privacyConsent: e.target.checked })}
                      className="mt-1 w-4 h-4 rounded border-white/20 bg-white/5 text-[#FF5A1F] focus:ring-[#FF5A1F] cursor-pointer"
                    />
                    <label htmlFor="privacyConsent" className="text-xs text-white/70 leading-relaxed cursor-pointer">
                      I agree to the privacy policy and authorize AI SOFT STUDIO to contact me regarding my project brief. Your information is confidential and will never be shared or monetized.
                    </label>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 py-4 px-6 text-sm font-semibold text-white bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] rounded-xl shadow-[0_4px_25px_rgba(255,90,31,0.4)] hover:shadow-[0_4px_35px_rgba(255,90,31,0.6)] hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none transition-all cursor-pointer"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Submitting Project Enquiry...</span>
                      </>
                    ) : (
                      <>
                        <span>Send Project Enquiry</span>
                        <Send className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
