import React from 'react';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { HeroVisual3D } from './HeroVisual3D';

interface HeroProps {
  onExploreWork: () => void;
  onStartProject: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreWork, onStartProject }) => {
  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col justify-between pt-28 pb-12 sm:pt-36 sm:pb-16 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full my-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Typography & CTAs */}
          <div className="lg:col-span-7 z-10 flex flex-col items-start">
            {/* Small Top Label */}
            <div className="mb-6 inline-flex items-center gap-2 text-xs font-mono tracking-widest text-white/70 uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF5A1F]" />
              <span>Independent Digital Innovation Studio</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-heading tracking-tight text-white leading-[1.1] mb-6 [text-wrap:balance]">
              Build{' '}
              <span className="bg-gradient-to-r from-[#FF5A1F] via-[#FF7A00] to-white bg-clip-text text-transparent drop-shadow-[0_0_35px_rgba(255,90,31,0.35)]">
                Smarter.
              </span>{' '}
              Grow{' '}
              <span className="text-[#244BFF] drop-shadow-[0_0_35px_rgba(36,75,255,0.35)]">
                Faster.
              </span>{' '}
              <span className="relative inline-block text-white">
                Stay Secure.
                <span
                  className="absolute -bottom-1 left-0 right-0 h-[3px] bg-gradient-to-r from-[#244BFF] to-[#FF5A1F] rounded-full opacity-80"
                  aria-hidden="true"
                />
              </span>
            </h1>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-white/75 leading-relaxed max-w-2xl mb-8">
              Websites, AI automation, e-commerce, cybersecurity, and custom software solutions designed around your business.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-5 w-full sm:w-auto">
              {/* Primary button */}
              <button
                type="button"
                onClick={onStartProject}
                className="group relative inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-semibold text-white bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] rounded-lg shadow-[0_4px_25px_rgba(255,90,31,0.4)] hover:shadow-[0_4px_35px_rgba(255,90,31,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all whitespace-nowrap cursor-pointer"
              >
                <span>Start Your Project</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              {/* Secondary button */}
              <button
                type="button"
                onClick={onExploreWork}
                className="inline-flex items-center justify-center px-6 py-3.5 text-sm font-medium text-white/90 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#244BFF]/50 rounded-lg backdrop-blur-md transition-all hover:text-white whitespace-nowrap cursor-pointer"
              >
                <span>Explore Our Services</span>
              </button>
            </div>

            {/* Studio Capabilities Strip */}
            <div className="mt-12 pt-8 border-t border-white/10 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/50 font-mono">
              <span className="text-white/80">CORE DISCIPLINES</span>
              <span aria-hidden="true">/</span>
              <span>Bespoke Engineering</span>
              <span aria-hidden="true">·</span>
              <span>Workflow AI</span>
              <span aria-hidden="true">·</span>
              <span>E-Commerce</span>
              <span aria-hidden="true">·</span>
              <span>Custom Ops</span>
            </div>
          </div>

          {/* Right Column: Custom 3D Orb & Motion Environment */}
          <div className="lg:col-span-5 flex items-center justify-center relative">
            <HeroVisual3D />
          </div>
        </div>
      </div>

      {/* Subtle Scroll Indicator */}
      <div className="flex flex-col items-center justify-center gap-1.5 pt-6 text-white/40 text-xs font-mono tracking-wider">
        <span className="text-[10px] uppercase">Scroll to explore</span>
        <ChevronDown className="w-4 h-4 animate-bounce text-[#FF5A1F]" />
      </div>
    </section>
  );
};
