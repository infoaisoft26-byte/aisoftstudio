import React, { useState } from 'react';
import { Globe, Cpu, ShoppingBag, LayoutDashboard, ArrowRight, X, Check, Terminal, Layers, ShieldCheck } from 'lucide-react';
import { ScopeEstimator, ScopeEstimate } from './ScopeEstimator';

interface ServiceDetail {
  id: string;
  title: string;
  category: string;
  tagline: string;
  description: string;
  capabilities: string[];
  technologies: string[];
  deliverables: string[];
  architectureOverview: string;
}

const SERVICES_DATA: ServiceDetail[] = [
  {
    id: 'web-dev',
    title: 'Website Development',
    category: 'Digital Flagships & Web Apps',
    tagline: 'Modern, responsive websites with refined UI, smooth interactions and performance-focused development.',
    description:
      'We architect and engineer bespoke web platforms designed for speed, visual clarity, and responsiveness across every device. From portfolio flagships to complex single-page applications, we eliminate bloat to deliver rapid load times and fluid motion.',
    capabilities: [
      'Responsive design across mobile (360px) to ultra-wide (4K)',
      'Sub-second page load times with optimized asset pipelines',
      'Fluid micro-interactions and hardware-accelerated animations',
      'Clean semantic markup, SEO readiness, and accessible semantics (WCAG AA)',
      'Headless CMS integration or custom content structures',
    ],
    technologies: ['React 19', 'TypeScript', 'Tailwind CSS', 'Vite', 'Next.js', 'Framer Motion'],
    deliverables: [
      'Production-ready modular code repository',
      'Comprehensive design system and component kit',
      'Cross-browser and multi-device QA testing report',
      'SEO metadata and social sharing configuration',
    ],
    architectureOverview:
      'Client-first static-to-dynamic hybrid architecture with code splitting, CDN caching, and zero render-blocking dependencies.',
  },
  {
    id: 'ai-automation',
    title: 'AI Automation',
    category: 'Intelligent Process Automation',
    tagline: 'Intelligent workflows designed to reduce repetitive tasks and connect business processes.',
    description:
      'We design and deploy practical automation pipelines that connect existing business databases, email queues, and third-party APIs with modern AI models. Our focus is operational utility: saving hours of manual data handling each week.',
    capabilities: [
      'Node-based automated decision logic and routing',
      'Automated document parsing, extraction, and structured classification',
      'Custom webhook listeners and synchronous API connectors',
      'Secure LLM integration with strict prompt schemas and validation',
      'Audit logging and automated error-handling fallbacks',
    ],
    technologies: ['Google GenAI SDK', 'Node.js / Express', 'Python / FastServer', 'REST & Webhooks', 'Structured JSON-LD'],
    deliverables: [
      'Configured automation pipelines with failover handling',
      'API routing documentation and environment setup',
      'Telemetry tracking for pipeline throughput and latencies',
      'Operational runbook and staff workflow documentation',
    ],
    architectureOverview:
      'Event-driven queue architecture with schema-enforced validation, asynchronous workers, and secure tokenized authentication.',
  },
  {
    id: 'ecommerce',
    title: 'E-commerce Development',
    category: 'High-Conversion Digital Commerce',
    tagline: 'Online stores with clean shopping experiences, product discovery and checkout integrations.',
    description:
      'We create high-converting online storefronts that balance luxurious visual presentation with frictionless shopping carts. Built with modern headless patterns, secure payment gateways, and real-time inventory synchronization.',
    capabilities: [
      'High-performance product catalog with multi-facet filtering',
      'Streamlined single-page checkout and mobile-first cart experiences',
      'Stripe, PayPal, and multi-currency payment integration',
      'Automated inventory status and order dispatch webhooks',
      'Custom transactional email templates and customer account portals',
    ],
    technologies: ['React / Next.js', 'Stripe API', 'Shopify Storefront API / Medusa', 'Tailwind CSS', 'Cloudflare Workers'],
    deliverables: [
      'Fully responsive custom e-commerce storefront',
      'Secured payment gateway and webhook verification',
      'Product catalog ingestion schema and inventory admin',
      'Checkout abandonment mitigation and analytics tagging',
    ],
    architectureOverview:
      'Headless decoupled storefront consuming serverless commerce endpoints with optimistic cart state updates.',
  },
  {
    id: 'admin-panels',
    title: 'Custom Admin Panels',
    category: 'Mission Control & Operations Dashboards',
    tagline: 'Purpose-built dashboards for managing business operations, content and workflows.',
    description:
      'Off-the-shelf admin templates are often cluttered or rigid. We construct custom operations consoles tailored strictly to your business data structures, role permissions, and day-to-day managerial workflows.',
    capabilities: [
      'Granular Role-Based Access Control (RBAC) and user tiers',
      'Real-time operational metrics and interactive data tables',
      'Searchable, sortable CRUD interfaces with batch actions',
      'Audit logging, system state monitors, and export utilities (CSV/JSON)',
      'Secure authentication and session management',
    ],
    technologies: ['React 19', 'TypeScript', 'Tailwind CSS', 'Express Backend', 'PostgreSQL / SQLite', 'Lucide Data Viz'],
    deliverables: [
      'Custom administrative web dashboard application',
      'Role-based permission matrix and security audit',
      'Exportable reporting and data visualization components',
      'Database schema migration scripts and API endpoints',
    ],
    architectureOverview:
      'Protected SPA communicating with authenticated REST/GraphQL API with JWT/Session tokens and granular resource permissions.',
  },
  {
    id: 'cybersecurity',
    title: 'Cybersecurity & Hardening',
    category: 'Lawful & Authorized Security Reviews',
    tagline: 'Vulnerability assessments, authentication audits, and configuration hardening for explicitly authorized systems.',
    description:
      'We conduct comprehensive, strictly authorized security reviews for web applications, APIs, and cloud services. From authentication validation to dependency auditing, backup resilience, and configuration hardening, we deliver structured remediation roadmaps with zero disruption to active operations.',
    capabilities: [
      'Website and web application architecture security reviews',
      'Secure authentication, session tokens, and access-control reviews',
      'Vulnerability assessments for explicitly authorized client systems',
      'Security configuration and server hardening (TLS, CSP, Rate Limits)',
      'Dependency, supply chain, and configuration reviews',
      'Backup, recovery, and incident-readiness planning',
      'Structured technical recommendations and remediation reports',
    ],
    technologies: ['OWASP ASVS & Top 10', 'CSP & Security Headers', 'HMAC / JWT Verification', 'Dependency Auditing', 'Least-Privilege RBAC'],
    deliverables: [
      'Written Scope & Explicit Authorization Agreement',
      'Executive Summary & Vulnerability Severity Matrix',
      'Prioritized remediation roadmap with code-level fixes',
      'Post-remediation verification checklist',
    ],
    architectureOverview:
      'Strictly authorized, non-destructive assessment protocol respecting written scope boundaries, verifying authentication controls, input validation, and data protection at rest and in transit.',
  },
];

interface ServicesProps {
  onSelectService: (serviceTitle: string) => void;
  onApplyScopeEstimate: (estimate: ScopeEstimate) => void;
}

export const Services: React.FC<ServicesProps> = ({ onSelectService, onApplyScopeEstimate }) => {
  const [activeModal, setActiveModal] = useState<ServiceDetail | null>(null);

  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'web-dev':
        return <Globe className="w-6 h-6 text-[#FF5A1F]" />;
      case 'ai-automation':
        return <Cpu className="w-6 h-6 text-[#244BFF]" />;
      case 'ecommerce':
        return <ShoppingBag className="w-6 h-6 text-[#FF5A1F]" />;
      case 'admin-panels':
        return <LayoutDashboard className="w-6 h-6 text-[#244BFF]" />;
      case 'cybersecurity':
        return <ShieldCheck className="w-6 h-6 text-emerald-400" />;
      default:
        return <Globe className="w-6 h-6 text-[#FF5A1F]" />;
    }
  };

  return (
    <section id="services" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16 sm:mb-20">
          <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
            Core Studio Services
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-5 [text-wrap:balance]">
            Ideas Into Intelligent Digital Solutions.
          </h2>
          <p className="text-base sm:text-lg text-white/70 leading-relaxed">
            Everything you need to create, launch and grow your digital presence. Built with precision
            engineering, clean aesthetics, and measurable business value.
          </p>
        </div>

        {/* 4 Interactive Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {SERVICES_DATA.map((service, index) => (
            <div
              key={service.id}
              className="group relative rounded-2xl p-8 glass-surface glass-surface-hover flex flex-col justify-between overflow-hidden cursor-pointer transition-all duration-300"
              onClick={() => setActiveModal(service)}
            >
              {/* Neon Orange Corner Highlight */}
              <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden pointer-events-none">
                <div className="absolute top-0 right-0 w-[2px] h-8 bg-[#FF5A1F] transition-all duration-300 group-hover:h-12" />
                <div className="absolute top-0 right-0 h-[2px] w-8 bg-[#FF5A1F] transition-all duration-300 group-hover:w-12" />
              </div>

              {/* Royal Blue Ambient Glow (on hover) */}
              <div
                className="absolute -bottom-16 -right-16 w-40 h-40 rounded-full bg-[#244BFF]/0 group-hover:bg-[#244BFF]/20 blur-3xl transition-all duration-500 pointer-events-none"
                aria-hidden="true"
              />

              {/* Top Row: Icon & Editorial Index */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:border-[#FF5A1F]/40 transition-colors">
                    {getServiceIcon(service.id)}
                  </div>
                  <span className="text-xs font-mono text-white/40 tracking-wider">
                    0{index + 1}
                  </span>
                </div>

                <div className="text-xs font-mono text-white/50 uppercase tracking-wider mb-2">
                  {service.category}
                </div>

                <h3 className="text-xl sm:text-2xl font-bold font-heading text-white group-hover:text-white mb-3 transition-colors">
                  {service.title}
                </h3>

                <p className="text-sm sm:text-base text-white/70 leading-relaxed mb-6">
                  {service.tagline}
                </p>

                {/* Micro Key Feature Bullets */}
                <ul className="space-y-2 mb-8">
                  {service.capabilities.slice(0, 3).map((cap, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-white/60">
                      <span className="text-[#FF5A1F] mt-0.5">·</span>
                      <span>{cap}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Bottom Card Action: Orange CTA Arrow */}
              <div className="pt-6 border-t border-white/10 flex items-center justify-between text-sm font-semibold">
                <span className="text-white/80 group-hover:text-white transition-colors">
                  Explore Scope & Architecture
                </span>
                <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#FF5A1F] group-hover:bg-[#FF5A1F] group-hover:text-white group-hover:translate-x-1 transition-all">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Scope & Sprint Estimation Tool */}
        <ScopeEstimator onApplyEstimate={onApplyScopeEstimate} />
      </div>

      {/* Technical Detail Modal */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#080D25] border border-white/15 p-6 sm:p-8 shadow-2xl">
            {/* Close Button */}
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Content */}
            <div className="mb-6">
              <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-1">
                {activeModal.category}
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold font-heading text-white">
                {activeModal.title}
              </h3>
              <p className="text-sm text-white/75 mt-2 leading-relaxed">
                {activeModal.description}
              </p>
            </div>

            {/* Architecture Overview */}
            <div className="mb-6 p-4 rounded-xl bg-white/[0.03] border border-white/10">
              <div className="flex items-center gap-2 text-xs font-mono text-[#244BFF] uppercase tracking-wider mb-1.5">
                <Terminal className="w-3.5 h-3.5" />
                <span>Architecture Pattern</span>
              </div>
              <p className="text-xs sm:text-sm text-white/80 leading-relaxed font-mono">
                {activeModal.architectureOverview}
              </p>
            </div>

            {/* Two Column Specs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
              {/* Capabilities */}
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-white/60 mb-3 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#FF5A1F]" />
                  Core Capabilities
                </h4>
                <ul className="space-y-2">
                  {activeModal.capabilities.map((cap, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-white/80">
                      <Check className="w-3.5 h-3.5 text-[#FF5A1F] shrink-0 mt-0.5" />
                      <span>{cap}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Deliverables */}
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-white/60 mb-3 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#244BFF]" />
                  Client Deliverables
                </h4>
                <ul className="space-y-2">
                  {activeModal.deliverables.map((del, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-white/80">
                      <Check className="w-3.5 h-3.5 text-[#244BFF] shrink-0 mt-0.5" />
                      <span>{del}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Tech Stack Pills/Tags */}
            <div className="mb-8 pt-4 border-t border-white/10">
              <div className="text-xs font-mono text-white/50 mb-2">Primary Technologies</div>
              <div className="flex flex-wrap gap-2">
                {activeModal.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2.5 py-1 text-xs font-mono bg-white/5 text-white/80 rounded border border-white/10"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Action inside modal */}
            <div className="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="px-4 py-2.5 text-xs font-medium text-white/70 hover:text-white rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  const title = activeModal.title;
                  setActiveModal(null);
                  onSelectService(title);
                }}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] rounded-lg shadow-lg shadow-[#FF5A1F]/30 hover:shadow-[#FF5A1F]/50 transition-all cursor-pointer"
              >
                <span>Request {activeModal.title}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
