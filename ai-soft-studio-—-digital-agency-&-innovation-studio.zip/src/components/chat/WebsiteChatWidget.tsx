import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send, Bot, Sparkles, Check, RefreshCw, ShieldCheck, ArrowRight } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export const WebsiteChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init_1',
      role: 'model',
      text: "Hello! I am the AI Studio Consultant for AI SOFT STUDIO. How can I assist you with your digital project today? Feel free to ask about our service packages, technology stacks, or delivery timelines.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState<string>(() => `chat_${Date.now()}`);
  const [aiStatus, setAiStatus] = useState<{ available: boolean; model: string } | null>(null);

  // In-chat inquiry capture form state
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadName, setLeadName] = useState('');
  const [leadEmail, setLeadEmail] = useState('');
  const [leadService, setLeadService] = useState('Website Development');
  const [leadBrief, setLeadBrief] = useState('');
  const [leadConsent, setLeadConsent] = useState(true);
  const [leadSubmitting, setLeadSubmitting] = useState(false);
  const [leadSuccess, setLeadSuccess] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    fetch('/api/chat/status')
      .then((res) => res.json())
      .then((data) => {
        setAiStatus({ available: data.aiAvailable, model: data.model });
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userText = inputValue.trim();
    setInputValue('');

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, message: userText }),
      });

      const data = await res.json();
      if (res.ok && data.reply) {
        setMessages((prev) => [
          ...prev,
          {
            id: `reply_${Date.now()}`,
            role: 'model',
            text: data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'model',
          text: "I apologize, but I am currently unable to process your request. You can also submit an enquiry directly via the contact form on this page.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName || !leadEmail || !leadBrief || !leadConsent) return;

    setLeadSubmitting(true);
    try {
      const res = await fetch('/api/chat/capture-inquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: leadName,
          email: leadEmail,
          service: leadService,
          projectDescription: leadBrief,
          consent: leadConsent,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setLeadSuccess(data.enquiryId);
        setMessages((prev) => [
          ...prev,
          {
            id: `lead_ack_${Date.now()}`,
            role: 'model',
            text: `Thank you, ${leadName}! Your inquiry (${data.enquiryId}) has been registered with our senior engineering team. We will review your requirements and respond within 24 hours.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
        setTimeout(() => setShowLeadForm(false), 2000);
      }
    } catch {
      // error handled
    } finally {
      setLeadSubmitting(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating Launcher Button */}
      {!isOpen && (
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="group relative flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white shadow-[0_4px_25px_rgba(255,90,31,0.5)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          aria-label="Open AI Assistant"
        >
          <div className="relative">
            <Bot className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-[#080D25] animate-pulse" />
          </div>
          <span className="text-xs font-semibold tracking-wide hidden sm:inline">Ask AI Studio</span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="w-[360px] sm:w-[400px] h-[550px] max-h-[85vh] rounded-2xl bg-[#080D25]/95 border border-white/15 backdrop-blur-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-white/5 to-white/[0.02] border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#FF5A1F]/20 border border-[#FF5A1F]/40 flex items-center justify-center text-[#FF5A1F]">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold font-heading text-white flex items-center gap-1.5">
                  <span>AI Studio Consultant</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                    ONLINE
                  </span>
                </div>
                <div className="text-[10px] text-white/50 font-mono">
                  {aiStatus?.available ? 'Grounded on Studio Knowledge' : 'Knowledge Base Fallback'}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-colors cursor-pointer"
              aria-label="Close chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Action Strip */}
          <div className="px-3 py-2 bg-black/40 border-b border-white/5 flex items-center justify-between text-[11px] font-mono">
            <span className="text-white/40">Direct Actions:</span>
            <button
              type="button"
              onClick={() => setShowLeadForm(!showLeadForm)}
              className="text-[#FF5A1F] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>{showLeadForm ? 'Back to Chat' : 'Register Project Scope'}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {/* Chat Messages or Lead Form */}
          {showLeadForm ? (
            /* Lead Capture Form */
            <div className="flex-1 overflow-y-auto p-4 text-xs">
              <div className="mb-3 text-white/80 font-mono text-[11px]">
                Submit your project specifications directly to the Inquiry CRM:
              </div>

              {leadSuccess ? (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-center my-8">
                  <Check className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
                  <div className="font-bold">Inquiry {leadSuccess} Registered!</div>
                  <div className="text-[11px] text-white/60 mt-1">Our engineering team will review it promptly.</div>
                </div>
              ) : (
                <form onSubmit={handleLeadSubmit} className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-mono text-white/60 mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      value={leadName}
                      onChange={(e) => setLeadName(e.target.value)}
                      placeholder="e.g. Jordan Lee"
                      className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF5A1F]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-white/60 mb-1">Work Email *</label>
                    <input
                      type="email"
                      required
                      value={leadEmail}
                      onChange={(e) => setLeadEmail(e.target.value)}
                      placeholder="jordan@company.com"
                      className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF5A1F]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-white/60 mb-1">Service Required</label>
                    <select
                      value={leadService}
                      onChange={(e) => setLeadService(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white focus:outline-none focus:border-[#FF5A1F]"
                    >
                      <option value="Website Development">Website Development</option>
                      <option value="AI Automation">AI Automation</option>
                      <option value="E-commerce Development">E-commerce Development</option>
                      <option value="Custom Admin Panels">Custom Admin Panels</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-white/60 mb-1">Project Brief *</label>
                    <textarea
                      rows={3}
                      required
                      value={leadBrief}
                      onChange={(e) => setLeadBrief(e.target.value)}
                      placeholder="Brief overview of what you want to build..."
                      className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF5A1F] resize-none"
                    />
                  </div>

                  <div className="flex items-start gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="consentCheck"
                      checked={leadConsent}
                      onChange={(e) => setLeadConsent(e.target.checked)}
                      className="mt-0.5 rounded border-white/20 accent-[#FF5A1F]"
                    />
                    <label htmlFor="consentCheck" className="text-[10px] text-white/50 leading-tight">
                      I consent to AI SOFT STUDIO storing this inquiry in the CRM and contacting me regarding my project scope.
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={leadSubmitting || !leadConsent}
                    className="w-full py-2.5 rounded-lg bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white font-semibold text-xs disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#FF5A1F]/20 mt-2"
                  >
                    {leadSubmitting ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <>
                        <span>Submit to CRM</span>
                        <Send className="w-3 h-3" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          ) : (
            /* Message Thread */
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white rounded-br-none shadow-md shadow-[#FF5A1F]/20'
                        : 'bg-white/5 border border-white/10 text-white/85 rounded-bl-none'
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{msg.text}</div>
                  </div>
                  <span className="text-[9px] font-mono text-white/30 mt-1 px-1">{msg.timestamp}</span>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-center gap-2 text-white/50 text-xs font-mono py-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#FF5A1F]" />
                  <span>AI Studio is thinking...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}

          {/* Input Box */}
          {!showLeadForm && (
            <form onSubmit={handleSendMessage} className="p-3 border-t border-white/10 bg-black/30 flex items-center gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about services, pricing, or tech..."
                disabled={isLoading}
                className="flex-1 px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder:text-white/30 focus:outline-none focus:border-[#FF5A1F]"
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim()}
                className="w-9 h-9 rounded-xl bg-[#FF5A1F] hover:bg-[#FF7A00] text-white flex items-center justify-center disabled:opacity-40 transition-colors cursor-pointer shrink-0 shadow-md shadow-[#FF5A1F]/30"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
};
