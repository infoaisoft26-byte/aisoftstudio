import React, { useState, useMemo } from 'react';
import {
  Sliders,
  Check,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Zap
} from 'lucide-react';

export interface ScopeEstimate {
  service: string;
  scaleLabel: string;
  selectedFeatures: string[];
  pace: string;
  estimatedWeeks: string;
  complexityTier: string;
  summary: string;
}

interface ScopeEstimatorProps {
  onApplyEstimate: (estimate: ScopeEstimate) => void;
}

interface ServiceOption {
  id: string;
  title: string;
  scaleOptions: { id: string; label: string; description: string; points: number }[];
}

const SERVICE_CONFIG: ServiceOption[] = [
  {
    id: 'Website Development',
    title: 'Website Development',
    scaleOptions: [
      { id: 'web-1', label: '1–5 Core Pages', description: 'Essential digital flagship or focused portfolio', points: 1 },
      { id: 'web-2', label: '6–12 Custom Layouts', description: 'Comprehensive agency or multi-service site', points: 2 },
      { id: 'web-3', label: '15+ Dynamic Pages', description: 'Large-scale web presence with dynamic templates', points: 3 },
    ],
  },
  {
    id: 'AI Automation',
    title: 'AI Automation',
    scaleOptions: [
      { id: 'ai-1', label: '1–2 Focused Pipelines', description: 'Document extraction or single API route automation', points: 1 },
      { id: 'ai-2', label: '3–5 Multi-Branch Flows', description: 'Neural classification, CRM sync & webhook triggers', points: 2 },
      { id: 'ai-3', label: 'Enterprise Suite (6+ Flows)', description: 'End-to-end multi-agent orchestration & monitoring', points: 3 },
    ],
  },
  {
    id: 'E-commerce Development',
    title: 'E-commerce Development',
    scaleOptions: [
      { id: 'ecom-1', label: 'Boutique Store (< 25 SKUs)', description: 'Curated luxury catalog with 1-click checkout', points: 1 },
      { id: 'ecom-2', label: 'Mid-Tier Store (25–150 SKUs)', description: 'Multi-facet filtering, customer portal, promo codes', points: 2 },
      { id: 'ecom-3', label: 'Large Catalog (150+ SKUs)', description: 'Multi-currency, inventory sync & wholesale tiers', points: 3 },
    ],
  },
  {
    id: 'Custom Admin Panels',
    title: 'Custom Admin Panels',
    scaleOptions: [
      { id: 'adm-1', label: '1–3 Core Views', description: 'Focused operations dashboard with essential CRUD', points: 1 },
      { id: 'adm-2', label: '4–7 Department Modules', description: 'Multi-team management with RBAC & telemetry', points: 2 },
      { id: 'adm-3', label: 'Enterprise Console (8+ Modules)', description: 'Mission-control with audit trails & live analytics', points: 3 },
    ],
  },
];

const AVAILABLE_FEATURES = [
  { id: 'cms', label: 'Headless CMS Architecture', points: 1 },
  { id: 'ai_docs', label: 'AI Document Parsing & Extraction', points: 2 },
  { id: 'stripe', label: 'Stripe & Multi-Currency Checkout', points: 2 },
  { id: 'rbac', label: 'Role-Based Access Control (RBAC)', points: 2 },
  { id: 'motion', label: 'Custom 3D Canvas & Micro-Animations', points: 1 },
  { id: 'telemetry', label: 'Real-Time Webhooks & Telemetry Log', points: 1 },
];

export const ScopeEstimator: React.FC<ScopeEstimatorProps> = ({ onApplyEstimate }) => {
  const [selectedService, setSelectedService] = useState<string>('Website Development');
  const [selectedScaleIndex, setSelectedScaleIndex] = useState<number>(1);
  const [selectedFeatureIds, setSelectedFeatureIds] = useState<string[]>([
    'cms',
    'motion',
  ]);
  const [pace, setPace] = useState<'Standard' | 'Accelerated'>('Standard');

  const currentServiceConfig = useMemo(() => {
    return SERVICE_CONFIG.find((s) => s.id === selectedService) || SERVICE_CONFIG[0];
  }, [selectedService]);

  const activeScale = currentServiceConfig.scaleOptions[selectedScaleIndex] || currentServiceConfig.scaleOptions[0];

  const toggleFeature = (id: string) => {
    if (selectedFeatureIds.includes(id)) {
      setSelectedFeatureIds(selectedFeatureIds.filter((f) => f !== id));
    } else {
      setSelectedFeatureIds([...selectedFeatureIds, id]);
    }
  };

  // Calculate estimated complexity & timeline
  const calculation = useMemo(() => {
    let score = activeScale.points;
    selectedFeatureIds.forEach((fId) => {
      const feat = AVAILABLE_FEATURES.find((f) => f.id === fId);
      if (feat) score += feat.points;
    });

    let weeksRange = '2–3 Weeks';
    let tier = 'Focused Production Sprint';

    if (score <= 3) {
      weeksRange = pace === 'Accelerated' ? '2–3 Weeks' : '3–4 Weeks';
      tier = 'Focused Production Sprint';
    } else if (score <= 6) {
      weeksRange = pace === 'Accelerated' ? '3–5 Weeks' : '5–7 Weeks';
      tier = 'Multi-Module Platform Build';
    } else {
      weeksRange = pace === 'Accelerated' ? '5–7 Weeks' : '8–10 Weeks';
      tier = 'Enterprise Platform Architecture';
    }

    const featureNames = selectedFeatureIds.map(
      (id) => AVAILABLE_FEATURES.find((f) => f.id === id)?.label || id
    );

    const summaryText = `[Project Scope Estimate]: Service: ${selectedService} | Scale: ${activeScale.label} | Complexity Tier: ${tier} | Pace: ${pace} (${weeksRange}) | Selected Add-ons: ${featureNames.join(', ') || 'Core foundation'}.`;

    return {
      weeksRange,
      tier,
      featureNames,
      summaryText,
    };
  }, [activeScale, selectedFeatureIds, pace, selectedService]);

  const handleApply = () => {
    onApplyEstimate({
      service: selectedService,
      scaleLabel: activeScale.label,
      selectedFeatures: calculation.featureNames,
      pace: pace === 'Accelerated' ? 'Urgent (< 1 Mo)' : '1–3 Months',
      estimatedWeeks: calculation.weeksRange,
      complexityTier: calculation.tier,
      summary: calculation.summaryText,
    });
  };

  return (
    <div className="mt-20 pt-16 border-t border-white/10">
      <div className="max-w-4xl mx-auto">
        {/* Estimator Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
            <Sliders className="w-3.5 h-3.5" />
            <span>Interactive Scope & Sprint Estimator</span>
          </div>
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold font-heading text-white tracking-tight [text-wrap:balance]">
            Calculate Your Estimated Project Scope
          </h3>
          <p className="text-sm sm:text-base text-white/70 max-w-xl mx-auto mt-3 leading-relaxed">
            Configure your technical requirements below to evaluate sprint timelines, engineering milestones,
            and architecture deliverables before contacting our team.
          </p>
        </div>

        {/* Interactive Estimator Canvas */}
        <div className="glass-surface rounded-2xl p-6 sm:p-10 border border-white/10 shadow-2xl relative overflow-hidden">
          {/* Subtle Ambient Radial Highlight */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-[#FF5A1F]/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#244BFF]/5 rounded-full blur-3xl pointer-events-none" />

          {/* Step 1: Select Service Discipline */}
          <div className="mb-8">
            <label className="block text-xs font-mono uppercase tracking-wider text-white/60 mb-3">
              1. Choose Service Focus
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {SERVICE_CONFIG.map((srv) => (
                <button
                  key={srv.id}
                  type="button"
                  onClick={() => {
                    setSelectedService(srv.id);
                    setSelectedScaleIndex(1); // reset to middle option
                  }}
                  className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                    selectedService === srv.id
                      ? 'bg-white/10 border-[#FF5A1F] text-white shadow-[0_0_15px_rgba(255,90,31,0.2)]'
                      : 'bg-white/[0.02] border-white/10 text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="text-xs font-semibold">{srv.title}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Project Footprint / Scale */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-mono uppercase tracking-wider text-white/60">
                2. Project Scale & Footprint
              </label>
              <span className="text-xs font-mono text-[#FF5A1F]">
                {activeScale.label}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {currentServiceConfig.scaleOptions.map((opt, idx) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setSelectedScaleIndex(idx)}
                  className={`p-4 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    selectedScaleIndex === idx
                      ? 'bg-white/10 border-[#244BFF] text-white shadow-[0_0_15px_rgba(36,75,255,0.25)]'
                      : 'bg-white/[0.02] border-white/10 text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="text-sm font-semibold text-white mb-1">{opt.label}</div>
                  <div className="text-xs text-white/50 leading-relaxed">{opt.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 3: Custom Features (Multi-Select) */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-mono uppercase tracking-wider text-white/60">
                3. Custom Architectural Features
              </label>
              <span className="text-xs font-mono text-white/40">
                {selectedFeatureIds.length} Selected
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {AVAILABLE_FEATURES.map((feat) => {
                const isSelected = selectedFeatureIds.includes(feat.id);
                return (
                  <button
                    key={feat.id}
                    type="button"
                    onClick={() => toggleFeature(feat.id)}
                    className={`px-3.5 py-3 rounded-xl text-left border flex items-center justify-between gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white/10 border-[#FF5A1F]/80 text-white'
                        : 'bg-white/[0.02] border-white/10 text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span className="text-xs">{feat.label}</span>
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center shrink-0 border transition-colors ${
                        isSelected
                          ? 'bg-[#FF5A1F] border-[#FF5A1F] text-white'
                          : 'border-white/20 bg-transparent'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 4: Engineering Pace */}
          <div className="mb-10">
            <label className="block text-xs font-mono uppercase tracking-wider text-white/60 mb-3">
              4. Target Engineering Pace
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPace('Standard')}
                className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer flex items-center justify-between ${
                  pace === 'Standard'
                    ? 'bg-white/10 border-[#244BFF] text-white'
                    : 'bg-white/[0.02] border-white/10 text-white/60 hover:text-white'
                }`}
              >
                <div>
                  <div className="text-xs font-semibold text-white">Standard Phased Delivery</div>
                  <div className="text-[11px] text-white/50">Comprehensive discovery, design & build phases</div>
                </div>
                {pace === 'Standard' && <Check className="w-4 h-4 text-[#244BFF]" />}
              </button>

              <button
                type="button"
                onClick={() => setPace('Accelerated')}
                className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer flex items-center justify-between ${
                  pace === 'Accelerated'
                    ? 'bg-white/10 border-[#FF5A1F] text-white'
                    : 'bg-white/[0.02] border-white/10 text-white/60 hover:text-white'
                }`}
              >
                <div>
                  <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <span>Priority Accelerated Sprint</span>
                    <Zap className="w-3.5 h-3.5 text-[#FF5A1F]" />
                  </div>
                  <div className="text-[11px] text-white/50">Dedicated sprint bandwidth for expedited launch</div>
                </div>
                {pace === 'Accelerated' && <Check className="w-4 h-4 text-[#FF5A1F]" />}
              </button>
            </div>
          </div>

          {/* Live Calculated Scope Output Card */}
          <div className="p-6 rounded-xl bg-[#040615] border border-white/10 shadow-inner">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
              {/* Output Metrics */}
              <div className="sm:col-span-7 space-y-3">
                <div className="flex items-center gap-2 text-xs font-mono text-[#FF5A1F]">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>CALCULATED SCOPE ESTIMATE</span>
                </div>

                <div>
                  <div className="text-xs font-mono text-white/50">Estimated Sprint Timeline</div>
                  <div className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-baseline gap-2">
                    <span>{calculation.weeksRange}</span>
                    <span className="text-xs font-mono text-white/40 font-normal">
                      ({pace} Pace)
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-white/70">
                  <span className="flex items-center gap-1.5 font-mono">
                    <Layers className="w-3.5 h-3.5 text-[#244BFF]" />
                    {calculation.tier}
                  </span>
                  <span className="text-white/20">·</span>
                  <span className="flex items-center gap-1.5 font-mono">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#FF5A1F]" />
                    Fixed Milestone Scope
                  </span>
                </div>
              </div>

              {/* Action Button: Link Directly to Contact Form */}
              <div className="sm:col-span-5 flex flex-col justify-center sm:items-end">
                <button
                  type="button"
                  onClick={handleApply}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] rounded-xl shadow-[0_4px_20px_rgba(255,90,31,0.4)] hover:shadow-[0_4px_30px_rgba(255,90,31,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                >
                  <span>Apply Scope to Enquiry</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <span className="text-[10px] font-mono text-white/40 mt-2 text-center sm:text-right">
                  Transfers options directly to enquiry form
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
