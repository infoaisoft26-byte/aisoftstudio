import React from 'react';
import { Layers, MessageSquare, MonitorSmartphone, Zap, Sliders, Check } from 'lucide-react';

const PRINCIPLES = [
  {
    icon: Layers,
    title: 'Custom Solutions, Never Rigid Templates',
    description:
      'We build every digital product from clean foundations designed around your specific business logic, user journeys, and brand identity—eschewing bloated one-size-fits-all marketplace templates.',
    highlight: 'Engineered specifically for your operational realities.',
  },
  {
    icon: MessageSquare,
    title: 'Clear Communication & Explicit Project Scope',
    description:
      'No convoluted agency layers or hidden surprises. You work directly with senior software engineers who provide explicit milestones, weekly staging demos, and transparent delivery dates.',
    highlight: 'Direct senior-level engineering access throughout.',
  },
  {
    icon: MonitorSmartphone,
    title: 'Responsive & Modern Fluid Interfaces',
    description:
      'Every layout is meticulously designed and tested across small mobile viewports (360px), tablets, standard laptops, and 4K ultra-wides, guaranteeing zero broken elements or unexpected horizontal overflow.',
    highlight: 'Tested against real mobile devices and browsers.',
  },
  {
    icon: Zap,
    title: 'Performance-Conscious Implementation',
    description:
      'Sub-second first-contentful paint, disciplined bundle splitting, minimal DOM complexity, and GPU-composited animations. We respect user device memory and bandwidth.',
    highlight: 'Lighthouse-optimized and lightweight by design.',
  },
  {
    icon: Sliders,
    title: 'Practical Automation Where It Actually Counts',
    description:
      'We incorporate automation only where it tangibly reduces administrative hours, eliminates human data entry errors, or accelerates client turnaround—never adding artificial complexity.',
    highlight: 'Measurable time savings and reliable error handling.',
  },
];

export const WhyUs: React.FC = () => {
  return (
    <section id="about" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16 sm:mb-20">
          <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
            Studio Standards & Philosophy
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-5 [text-wrap:balance]">
            Built Around Your Goals.
          </h2>
          <p className="text-base sm:text-lg text-white/70 leading-relaxed">
            We partner with ambitious businesses that demand technical integrity, thoughtful visual design,
            and software that performs reliably in the real world.
          </p>
        </div>

        {/* Asymmetric Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 lg:gap-8 items-stretch">
          {/* Featured Large Card: Custom Solutions (Span 7) */}
          <div className="md:col-span-7 glass-surface rounded-2xl p-8 sm:p-10 border border-white/10 relative overflow-hidden flex flex-col justify-between group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF5A1F]/10 rounded-full blur-2xl pointer-events-none" />
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#FF5A1F]/10 border border-[#FF5A1F]/30 flex items-center justify-center text-[#FF5A1F] mb-6">
                <Layers className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-bold font-heading text-white mb-4">
                {PRINCIPLES[0].title}
              </h3>
              <p className="text-sm sm:text-base text-white/75 leading-relaxed mb-6">
                {PRINCIPLES[0].description}
              </p>
            </div>
            <div className="pt-6 border-t border-white/10 flex items-center gap-2 text-xs font-mono text-[#FF5A1F]">
              <Check className="w-4 h-4" />
              <span>{PRINCIPLES[0].highlight}</span>
            </div>
          </div>

          {/* Card 2: Clear Communication (Span 5) */}
          <div className="md:col-span-5 glass-surface rounded-2xl p-8 border border-white/10 flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#244BFF]/10 border border-[#244BFF]/30 flex items-center justify-center text-[#244BFF] mb-6">
                <MessageSquare className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold font-heading text-white mb-3">
                {PRINCIPLES[1].title}
              </h3>
              <p className="text-sm text-white/70 leading-relaxed mb-6">
                {PRINCIPLES[1].description}
              </p>
            </div>
            <div className="pt-6 border-t border-white/10 flex items-center gap-2 text-xs font-mono text-[#244BFF]">
              <Check className="w-4 h-4" />
              <span>{PRINCIPLES[1].highlight}</span>
            </div>
          </div>

          {/* Card 3: Responsive Interfaces (Span 4) */}
          <div className="md:col-span-4 glass-surface rounded-2xl p-7 border border-white/10 flex flex-col justify-between group">
            <div>
              <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#FF5A1F] mb-5">
                <MonitorSmartphone className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold font-heading text-white mb-2.5">
                {PRINCIPLES[2].title}
              </h3>
              <p className="text-xs sm:text-sm text-white/70 leading-relaxed mb-4">
                {PRINCIPLES[2].description}
              </p>
            </div>
            <div className="pt-4 border-t border-white/10 text-xs font-mono text-white/50">
              {PRINCIPLES[2].highlight}
            </div>
          </div>

          {/* Card 4: Performance Conscious (Span 4) */}
          <div className="md:col-span-4 glass-surface rounded-2xl p-7 border border-white/10 flex flex-col justify-between group">
            <div>
              <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#244BFF] mb-5">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold font-heading text-white mb-2.5">
                {PRINCIPLES[3].title}
              </h3>
              <p className="text-xs sm:text-sm text-white/70 leading-relaxed mb-4">
                {PRINCIPLES[3].description}
              </p>
            </div>
            <div className="pt-4 border-t border-white/10 text-xs font-mono text-white/50">
              {PRINCIPLES[3].highlight}
            </div>
          </div>

          {/* Card 5: Practical Automation (Span 4) */}
          <div className="md:col-span-4 glass-surface rounded-2xl p-7 border border-white/10 flex flex-col justify-between group">
            <div>
              <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#FF5A1F] mb-5">
                <Sliders className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold font-heading text-white mb-2.5">
                {PRINCIPLES[4].title}
              </h3>
              <p className="text-xs sm:text-sm text-white/70 leading-relaxed mb-4">
                {PRINCIPLES[4].description}
              </p>
            </div>
            <div className="pt-4 border-t border-white/10 text-xs font-mono text-white/50">
              {PRINCIPLES[4].highlight}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
