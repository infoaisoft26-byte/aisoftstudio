import React from 'react';
import { AlertCircle, CheckCircle2, Zap, ShieldCheck, Cpu, TrendingUp } from 'lucide-react';

const CHALLENGES = [
  {
    problem: 'Bloated, slow templates that hurt conversion and search rankings',
    solution: 'Bespoke high-performance web architecture',
    details: 'Zero-junk modular engineering that loads in under 700ms with hardware-accelerated animations and strict Core Web Vitals compliance.',
    icon: Zap,
    accent: 'text-[#FF5A1F]',
  },
  {
    problem: 'Hours lost each week to manual data entry, emails, and disconnected tools',
    solution: 'Intelligent AI process automation',
    details: 'Schema-validated LLM pipelines and automated API webhooks that parse incoming briefs, update databases, and notify staff automatically.',
    icon: Cpu,
    accent: 'text-[#244BFF]',
  },
  {
    problem: 'Unknown vulnerability risks and configuration weaknesses in web systems',
    solution: 'Lawful, authorized security reviews and hardening',
    details: 'Zero-trust authentication reviews, OWASP vulnerability assessments with explicit written client scope, and concrete code-level remediation steps.',
    icon: ShieldCheck,
    accent: 'text-emerald-400',
  },
  {
    problem: 'Off-the-shelf software with rigid limitations that slow business operations',
    solution: 'Custom administration consoles & portals',
    details: 'Tailor-made dashboards with granular role-based permissions (RBAC), realtime telemetry, audit trails, and streamlined team workflows.',
    icon: TrendingUp,
    accent: 'text-purple-400',
  },
];

export const BusinessSolutions: React.FC = () => {
  return (
    <section className="relative py-24 sm:py-32 border-t border-white/5 bg-[#060A1F]/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16 sm:mb-20">
          <div className="text-xs font-mono uppercase tracking-widest text-[#FF5A1F] mb-3">
            Problems We Solve
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading tracking-tight text-white mb-5 [text-wrap:balance]">
            From Operational Friction To Digital Advantage.
          </h2>
          <p className="text-base sm:text-lg text-white/70 leading-relaxed">
            We partner with ambitious businesses to eliminate bottlenecks, fortify systems, and engineer digital assets built for measurable performance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {CHALLENGES.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="relative rounded-2xl bg-white/[0.03] hover:bg-white/[0.05] border border-white/10 p-6 sm:p-8 transition-all duration-300 group hover:border-white/20"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className={`p-3 rounded-xl bg-white/5 border border-white/10 shrink-0 ${item.accent}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-xs font-mono text-red-400/90 mb-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>The Challenge</span>
                    </div>
                    <h3 className="text-sm sm:text-base font-semibold text-white/90">
                      {item.problem}
                    </h3>
                  </div>
                </div>

                <div className="pl-4 sm:pl-16 pt-3 border-t border-white/5 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>Our Solution: {item.solution}</span>
                  </div>
                  <p className="text-xs sm:text-sm text-white/60 leading-relaxed">
                    {item.details}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
