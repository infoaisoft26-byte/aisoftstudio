import React, { useState, useEffect } from 'react';
import {
  Inbox,
  FolderGit2,
  DollarSign,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Sparkles,
  Layers,
  Activity
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Inquiry, Project, Invoice, Payment, AuditLog } from '../../server/db/types';

interface DashboardOverviewProps {
  onNavigateTab: (tab: any) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ onNavigateTab }) => {
  const { token } = useAuth();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };

      const [inqRes, prjRes, invRes, payRes, logRes] = await Promise.all([
        fetch('/api/inquiries', { headers }),
        fetch('/api/projects', { headers }),
        fetch('/api/finance/invoices', { headers }),
        fetch('/api/finance/payments', { headers }),
        fetch('/api/auth/audit-logs', { headers }),
      ]);

      if (inqRes.ok) {
        const d = await inqRes.json();
        setInquiries(d.inquiries || []);
      }
      if (prjRes.ok) {
        const d = await prjRes.json();
        setProjects(d.projects || []);
      }
      if (invRes.ok) {
        const d = await invRes.json();
        setInvoices(d.invoices || []);
      }
      if (payRes.ok) {
        const d = await payRes.json();
        setPayments(d.payments || []);
      }
      if (logRes.ok) {
        const d = await logRes.json();
        setAuditLogs(d.logs || []);
      }
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [token]);

  // Derived real computations
  const totalVerifiedRevenue = payments
    .filter((p) => p.status === 'verified')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalOutstandingBalance = invoices.reduce((sum, inv) => sum + inv.balanceDue, 0);

  const newInquiriesCount = inquiries.filter((i) => i.status === 'New').length;
  const activeProjectsCount = projects.filter((p) => p.status === 'In Progress' || p.status === 'Planning').length;

  // Real Alerts
  const alerts: { id: string; type: 'warning' | 'info'; text: string; action?: () => void }[] = [];

  if (newInquiriesCount > 0) {
    alerts.push({
      id: 'alert_inq',
      type: 'warning',
      text: `${newInquiriesCount} new incoming project enquiry waiting for review.`,
      action: () => onNavigateTab('inquiries'),
    });
  }

  const overdueInvoices = invoices.filter((i) => i.status === 'Overdue' || (i.balanceDue > 0 && new Date(i.dueDate) < new Date()));
  if (overdueInvoices.length > 0) {
    alerts.push({
      id: 'alert_inv',
      type: 'warning',
      text: `${overdueInvoices.length} invoice(s) are past due or require payment follow-up.`,
      action: () => onNavigateTab('finances'),
    });
  }

  if (alerts.length === 0) {
    alerts.push({
      id: 'alert_ok',
      type: 'info',
      text: 'All system workflows, inquiries, and milestones are on track.',
    });
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            Executive Operations Overview
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Real-time telemetry, project development pipelines, and verified financial state.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchDashboardData}
          disabled={loading}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 hover:text-white transition-colors cursor-pointer self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#FF5A1F]' : ''}`} />
          <span>Refresh Real-time Telemetry</span>
        </button>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* KPI 1: Inquiries */}
        <div
          onClick={() => onNavigateTab('inquiries')}
          className="glass-surface p-6 rounded-2xl border border-white/10 hover:border-[#FF5A1F]/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#FF5A1F]/15 border border-[#FF5A1F]/30 flex items-center justify-center text-[#FF5A1F]">
              <Inbox className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-white/40 group-hover:text-white transition-colors flex items-center gap-1">
              CRM Pipeline <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
          <div className="text-3xl font-bold font-heading text-white tracking-tight">
            {inquiries.length}
          </div>
          <div className="text-xs text-white/60 mt-1 flex items-center gap-2 font-mono">
            <span className="text-[#FF5A1F]">{newInquiriesCount} New</span>
            <span>·</span>
            <span>{inquiries.filter((i) => i.status === 'In Progress').length} Active</span>
          </div>
        </div>

        {/* KPI 2: Active Projects */}
        <div
          onClick={() => onNavigateTab('projects')}
          className="glass-surface p-6 rounded-2xl border border-white/10 hover:border-[#244BFF]/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#244BFF]/15 border border-[#244BFF]/30 flex items-center justify-center text-[#244BFF]">
              <FolderGit2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-white/40 group-hover:text-white transition-colors flex items-center gap-1">
              Development <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
          <div className="text-3xl font-bold font-heading text-white tracking-tight">
            {projects.length}
          </div>
          <div className="text-xs text-white/60 mt-1 flex items-center gap-2 font-mono">
            <span className="text-[#244BFF]">{activeProjectsCount} In Flight</span>
            <span>·</span>
            <span>{projects.filter((p) => p.status === 'Completed').length} Shipped</span>
          </div>
        </div>

        {/* KPI 3: Verified Revenue */}
        <div
          onClick={() => onNavigateTab('finances')}
          className="glass-surface p-6 rounded-2xl border border-white/10 hover:border-emerald-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-white/40 group-hover:text-white transition-colors flex items-center gap-1">
              Verified <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
          <div className="text-3xl font-bold font-heading text-white tracking-tight">
            ${totalVerifiedRevenue.toLocaleString()}
          </div>
          <div className="text-xs text-white/60 mt-1 font-mono">
            {payments.length} Verified Transaction(s)
          </div>
        </div>

        {/* KPI 4: Outstanding Balance */}
        <div
          onClick={() => onNavigateTab('finances')}
          className="glass-surface p-6 rounded-2xl border border-white/10 hover:border-amber-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-white/40 group-hover:text-white transition-colors flex items-center gap-1">
              Receivables <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
          <div className="text-3xl font-bold font-heading text-white tracking-tight">
            ${totalOutstandingBalance.toLocaleString()}
          </div>
          <div className="text-xs text-white/60 mt-1 font-mono">
            {invoices.filter((i) => i.balanceDue > 0).length} Unsettled Invoice(s)
          </div>
        </div>
      </div>

      {/* System Alerts Strip */}
      <div className="space-y-2.5">
        <div className="text-xs font-mono uppercase tracking-wider text-white/50 flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-[#FF5A1F]" />
          <span>Active Operations Alerts</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {alerts.map((alt) => (
            <div
              key={alt.id}
              onClick={alt.action}
              className={`p-4 rounded-xl border flex items-center justify-between gap-3 text-xs ${
                alt.type === 'warning'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
              } ${alt.action ? 'cursor-pointer hover:opacity-90' : ''}`}
            >
              <div className="flex items-center gap-2.5">
                {alt.type === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                )}
                <span>{alt.text}</span>
              </div>
              {alt.action && <ArrowUpRight className="w-3.5 h-3.5 opacity-60 shrink-0" />}
            </div>
          ))}
        </div>
      </div>

      {/* Two Column Layout: Inquiries Pipeline + Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Recent Inquiries Pipeline */}
        <div className="lg:col-span-7 glass-surface rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div>
                <h3 className="font-bold font-heading text-base text-white">Inquiry Pipeline</h3>
                <p className="text-xs text-white/50">Latest prospective client submissions</p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('inquiries')}
                className="text-xs font-mono text-[#FF5A1F] hover:underline"
              >
                View All CRM ({inquiries.length})
              </button>
            </div>

            {inquiries.length === 0 ? (
              <div className="py-12 text-center text-xs font-mono text-white/40">
                No inquiries in pipeline yet. Submissions from the public website, chatbot, or Meta will appear here.
              </div>
            ) : (
              <div className="space-y-3">
                {inquiries.slice(0, 5).map((inq) => (
                  <div
                    key={inq.id}
                    onClick={() => onNavigateTab('inquiries')}
                    className="p-3.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{inq.name}</span>
                        {inq.businessName && (
                          <span className="text-[11px] text-white/50">· {inq.businessName}</span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-white/40 mt-0.5">
                        {inq.service} · {new Date(inq.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                        inq.status === 'New'
                          ? 'bg-[#FF5A1F]/15 text-[#FF5A1F] border-[#FF5A1F]/30'
                          : inq.status === 'In Progress'
                          ? 'bg-[#244BFF]/15 text-[#244BFF] border-[#244BFF]/30'
                          : 'bg-white/10 text-white/70 border-white/20'
                      }`}
                    >
                      {inq.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Real-time Audit Activity */}
        <div className="lg:col-span-5 glass-surface rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div>
                <h3 className="font-bold font-heading text-base text-white">System Audit Stream</h3>
                <p className="text-xs text-white/50">Cryptographic audit log of studio actions</p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('users')}
                className="text-xs font-mono text-[#244BFF] hover:underline"
              >
                Full Audit Trail
              </button>
            </div>

            {auditLogs.length === 0 ? (
              <div className="py-12 text-center text-xs font-mono text-white/40">
                No activity recorded yet.
              </div>
            ) : (
              <div className="space-y-3">
                {auditLogs.slice(0, 5).map((log) => (
                  <div key={log.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-xs">
                    <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                      <span className="text-[#FF5A1F]">{log.action}</span>
                      <span className="text-white/30">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-white/80 line-clamp-2">{log.details}</div>
                    <div className="text-[10px] text-white/40 font-mono mt-1">By: {log.userName}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
