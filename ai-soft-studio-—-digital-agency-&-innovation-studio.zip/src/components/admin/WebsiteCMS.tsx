import React, { useState, useEffect } from 'react';
import {
  Globe2,
  CheckCircle2,
  History,
  Send,
  Save,
  RotateCcw,
  RefreshCw,
  Plus,
  Trash2,
  Sliders,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { CMSContent } from '../../server/db/types';

export const WebsiteCMS: React.FC = () => {
  const { token, user } = useAuth();
  const [content, setContent] = useState<CMSContent | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [historyCount, setHistoryCount] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Form edit states
  const [headline, setHeadline] = useState('');
  const [subtext, setSubtext] = useState('');
  const [topLabel, setTopLabel] = useState('');
  const [announcementEnabled, setAnnouncementEnabled] = useState(false);
  const [announcementText, setAnnouncementText] = useState('');
  const [faqs, setFaqs] = useState<{ question: string; answer: string; category: string }[]>([]);

  // New FAQ form
  const [newQ, setNewQ] = useState('');
  const [newA, setNewA] = useState('');

  const fetchCMS = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/cms/draft', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        const c: CMSContent = data.content;
        setContent(c);
        setHistoryCount(data.historyCount || 0);
        setHeadline(c.hero.headline);
        setSubtext(c.hero.subtext);
        setTopLabel(c.hero.topLabel);
        setAnnouncementEnabled(c.announcement.enabled);
        setAnnouncementText(c.announcement.text);
        setFaqs(c.faqs || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCMS();
  }, [token]);

  const handleSaveDraft = async () => {
    if (!content) return;
    setStatusMessage('Saving draft...');
    try {
      const res = await fetch('/api/cms/draft', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          hero: {
            ...content.hero,
            topLabel,
            headline,
            subtext,
          },
          announcement: {
            ...content.announcement,
            enabled: announcementEnabled,
            text: announcementText,
          },
          faqs,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setContent(data.content);
        setStatusMessage('Draft changes saved successfully.');
        setTimeout(() => setStatusMessage(null), 3000);
      }
    } catch (err) {
      console.error(err);
      setStatusMessage('Error saving draft.');
    }
  };

  const handlePublish = async () => {
    setStatusMessage('Publishing changes to live public site...');
    try {
      const res = await fetch('/api/cms/publish', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setContent(data.content);
        setStatusMessage('Successfully published live! Changes are now visible to public visitors.');
        setTimeout(() => setStatusMessage(null), 4000);
        fetchCMS();
      }
    } catch (err) {
      console.error(err);
      setStatusMessage('Error publishing changes.');
    }
  };

  const handleRollback = async () => {
    if (!window.confirm('Are you sure you want to rollback to the previous content revision?')) return;
    try {
      const res = await fetch('/api/cms/rollback', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        fetchCMS();
        setStatusMessage('Rollback successful.');
        setTimeout(() => setStatusMessage(null), 3000);
      } else {
        alert(data.error || 'Rollback failed');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddFaq = () => {
    if (!newQ.trim() || !newA.trim()) return;
    setFaqs([...faqs, { question: newQ.trim(), answer: newA.trim(), category: 'General' }]);
    setNewQ('');
    setNewA('');
  };

  const handleRemoveFaq = (index: number) => {
    setFaqs(faqs.filter((_, i) => i !== index));
  };

  const isSuperAdmin = user?.role === 'super_admin';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            Website Content Management (CMS)
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Edit live site copy, announcement banners, FAQs, and manage safe Draft/Publish/Rollback cycles.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {isSuperAdmin && historyCount > 0 && (
            <button
              type="button"
              onClick={handleRollback}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-white text-xs font-mono cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Rollback Revision ({historyCount})</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleSaveDraft}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white text-xs font-mono cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Draft</span>
          </button>

          <button
            type="button"
            onClick={handlePublish}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publish to Live Site</span>
          </button>
        </div>
      </div>

      {/* Status Notice */}
      {statusMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Publication State Pill */}
      <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 flex items-center justify-between text-xs font-mono text-white/60">
        <div className="flex items-center gap-2">
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              content?.status === 'published' ? 'bg-emerald-400' : 'bg-amber-400'
            }`}
          />
          <span className="font-bold text-white">Current Mode: {content?.status?.toUpperCase()}</span>
          <span>· Last edited by {content?.editedBy} ({new Date(content?.lastEditedAt || '').toLocaleString()})</span>
        </div>
        <span className="text-[11px] text-white/40">Rollback revisions available: {historyCount}</span>
      </div>

      {/* Editor Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Hero Copy & Taglines (Span 7) */}
        <div className="lg:col-span-7 glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-[#FF5A1F]" />
            <span>Hero Headline & Positioning Copy</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">Small Top Kicker Label</label>
              <input
                type="text"
                value={topLabel}
                onChange={(e) => setTopLabel(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">Main Editorial Headline</label>
              <textarea
                rows={2}
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs resize-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">Supporting Value Proposition Copy</label>
              <textarea
                rows={3}
                value={subtext}
                onChange={(e) => setSubtext(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs resize-none leading-relaxed"
              />
            </div>
          </div>
        </div>

        {/* Right: Announcement Banner (Span 5) */}
        <div className="lg:col-span-5 glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#244BFF]" />
            <span>Studio Announcement Banner</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="bannerCheck"
                checked={announcementEnabled}
                onChange={(e) => setAnnouncementEnabled(e.target.checked)}
                className="w-4 h-4 rounded border-white/20 accent-[#FF5A1F]"
              />
              <label htmlFor="bannerCheck" className="text-xs text-white font-medium cursor-pointer">
                Display Announcement Banner on Public Header
              </label>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">Banner Announcement Text</label>
              <textarea
                rows={3}
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                placeholder="e.g. Q4 2026 Engineering Sprints now open..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs resize-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions (FAQs) Management */}
      <div className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
        <h3 className="text-sm font-bold font-heading text-white">
          Knowledge Base & Website FAQs ({faqs.length})
        </h3>
        <p className="text-xs text-white/50">
          These FAQs are displayed on the public site and directly ground the AI Studio Chatbot.
        </p>

        {/* FAQ Items */}
        <div className="space-y-3">
          {faqs.map((f, i) => (
            <div key={i} className="p-4 rounded-xl bg-white/[0.02] border border-white/5 text-xs flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="font-semibold text-white">{f.question}</div>
                <div className="text-white/70 leading-relaxed">{f.answer}</div>
              </div>
              <button
                type="button"
                onClick={() => handleRemoveFaq(i)}
                className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 shrink-0"
                title="Remove FAQ"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Add FAQ form */}
        <div className="pt-4 border-t border-white/5 grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs">
          <input
            type="text"
            placeholder="New FAQ Question..."
            value={newQ}
            onChange={(e) => setNewQ(e.target.value)}
            className="sm:col-span-5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
          />
          <input
            type="text"
            placeholder="Detailed Answer..."
            value={newA}
            onChange={(e) => setNewA(e.target.value)}
            className="sm:col-span-5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
          />
          <button
            type="button"
            onClick={handleAddFaq}
            className="sm:col-span-2 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs"
          >
            Add FAQ
          </button>
        </div>
      </div>
    </div>
  );
};
