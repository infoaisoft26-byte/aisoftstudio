import React, { useState, useEffect } from 'react';
import {
  Bell,
  Mail,
  Smartphone,
  Save,
  CheckCircle2,
  RefreshCw,
  Code,
  Edit2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { NotificationTemplate } from '../../server/db/types';

export const NotificationsHub: React.FC = () => {
  const { token } = useAuth();
  const [templates, setTemplates] = useState<NotificationTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTemplate, setSelectedTemplate] = useState<NotificationTemplate | null>(null);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [active, setActive] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const fetchTemplates = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/conversations/templates', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setTemplates(data.templates || []);
        if (data.templates?.length > 0 && !selectedTemplate) {
          const first = data.templates[0];
          setSelectedTemplate(first);
          setSubject(first.subject);
          setBody(first.body);
          setActive(first.active);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, [token]);

  const handleSelect = (tmpl: NotificationTemplate) => {
    setSelectedTemplate(tmpl);
    setSubject(tmpl.subject);
    setBody(tmpl.body);
    setActive(tmpl.active);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTemplate) return;

    setSaving(true);
    try {
      const res = await fetch(`/api/conversations/templates/${selectedTemplate.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ subject, body, active }),
      });

      if (res.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        fetchTemplates();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <Bell className="w-7 h-7 text-[#FF5A1F]" />
            <span>Notifications & Email Templates</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Manage automated customer notifications, proposal dispatches, and payment receipt templates.
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
            <CheckCircle2 className="w-4 h-4" />
            <span>Template updated</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Template List */}
        <div className="lg:col-span-4 space-y-3">
          <div className="text-xs font-mono uppercase tracking-wider text-white/40 mb-2">
            Automated Trigger Templates ({templates.length})
          </div>

          {templates.map((tmpl) => (
            <div
              key={tmpl.id}
              onClick={() => handleSelect(tmpl)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                selectedTemplate?.id === tmpl.id
                  ? 'bg-white/[0.08] border-[#FF5A1F]/50 shadow-lg'
                  : 'bg-white/[0.02] hover:bg-white/[0.04] border-white/10'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-white text-xs">{tmpl.name}</span>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    tmpl.active
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : 'bg-white/5 text-white/40 border-white/10'
                  }`}
                >
                  {tmpl.active ? 'Active' : 'Disabled'}
                </span>
              </div>
              <div className="text-[11px] font-mono text-white/50 truncate">
                Trigger: {tmpl.trigger}
              </div>
            </div>
          ))}
        </div>

        {/* Template Editor */}
        <div className="lg:col-span-8">
          {selectedTemplate ? (
            <form onSubmit={handleSave} className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div>
                  <h2 className="text-base font-bold text-white">{selectedTemplate.name}</h2>
                  <span className="text-[11px] font-mono text-white/40">Event: {selectedTemplate.trigger}</span>
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-xs text-white/70 flex items-center gap-2 cursor-pointer font-mono">
                    <input
                      type="checkbox"
                      checked={active}
                      onChange={(e) => setActive(e.target.checked)}
                      className="w-3.5 h-3.5 rounded bg-white/5 border-white/20 text-[#FF5A1F]"
                    />
                    <span>Active Trigger</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-white/60 mb-1">Subject Line</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-[#FF5A1F]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-white/60 mb-1">Email Body Content</label>
                <textarea
                  rows={8}
                  required
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white font-mono leading-relaxed focus:outline-none focus:border-[#FF5A1F]"
                />
              </div>

              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-1 text-xs">
                <span className="text-[10px] font-mono uppercase text-white/40 block">Available Template Tags:</span>
                <div className="flex flex-wrap gap-1.5 font-mono text-[11px] text-white/70">
                  {selectedTemplate.variables.map((v) => (
                    <span key={v} className="px-2 py-0.5 rounded bg-white/5 border border-white/5 text-[#FF5A1F]">
                      {`{{${v}}}`}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={saving}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{saving ? 'Saving...' : 'Save Template Changes'}</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="glass-surface p-12 rounded-2xl border border-white/10 text-center text-xs text-white/40">
              Select a template to customize text and trigger variables.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
