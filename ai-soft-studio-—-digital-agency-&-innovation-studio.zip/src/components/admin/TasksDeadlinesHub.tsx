import React, { useState, useEffect } from 'react';
import {
  CheckSquare,
  Clock,
  Plus,
  RefreshCw,
  Search,
  Filter,
  User,
  Calendar,
  AlertCircle,
  CheckCircle2,
  X,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Task, Project } from '../../server/db/types';

export const TasksDeadlinesHub: React.FC = () => {
  const { token, user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [filterPriority, setFilterPriority] = useState<string>('All');

  // New task modal
  const [showNewModal, setShowNewModal] = useState(false);
  const [newProjectId, setNewProjectId] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPriority, setNewPriority] = useState<Task['priority']>('Medium');
  const [newDueDate, setNewDueDate] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Selected task note
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [noteText, setNoteText] = useState('');
  const [addingNote, setAddingNote] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [tRes, pRes] = await Promise.all([
        fetch('/api/projects/tasks', { headers }),
        fetch('/api/projects', { headers }),
      ]);
      if (tRes.ok) {
        const d = await tRes.json();
        setTasks(d.tasks || []);
        if (selectedTask) {
          const updated = (d.tasks || []).find((t: Task) => t.id === selectedTask.id);
          if (updated) setSelectedTask(updated);
        }
      }
      if (pRes.ok) {
        const d = await pRes.json();
        setProjects(d.projects || []);
        if (d.projects?.length > 0 && !newProjectId) {
          setNewProjectId(d.projects[0].id);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectId || !newTitle.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch(`/api/projects/${newProjectId}/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: newTitle,
          description: newDescription,
          priority: newPriority,
          dueDate: newDueDate || undefined,
        }),
      });

      if (res.ok) {
        setShowNewModal(false);
        setNewTitle('');
        setNewDescription('');
        setNewDueDate('');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateStatus = async (taskId: string, newStatus: Task['status']) => {
    try {
      const res = await fetch(`/api/projects/tasks/${taskId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !noteText.trim()) return;

    setAddingNote(true);
    try {
      const res = await fetch(`/api/projects/tasks/${selectedTask.id}/notes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ text: noteText }),
      });
      if (res.ok) {
        setNoteText('');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAddingNote(false);
    }
  };

  const filteredTasks = tasks.filter((t) => {
    if (filterStatus !== 'All' && t.status !== filterStatus) return false;
    if (filterPriority !== 'All' && t.priority !== filterPriority) return false;
    return true;
  });

  const getPriorityBadge = (p: Task['priority']) => {
    switch (p) {
      case 'Urgent':
        return 'bg-red-500/20 text-red-400 border-red-500/40';
      case 'High':
        return 'bg-orange-500/20 text-orange-400 border-orange-500/40';
      case 'Medium':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <CheckSquare className="w-7 h-7 text-emerald-400" />
            <span>Tasks and Deadlines</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Track engineering sprints, developer assignments, priority issues, and deliverables deadlines.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchData}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          {(user?.role === 'super_admin' || user?.role === 'staff' || user?.role === 'developer') && (
            <button
              type="button"
              onClick={() => setShowNewModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Task</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-surface p-4 rounded-2xl border border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-white/40 font-mono">Status:</span>
          {['All', 'To Do', 'In Progress', 'Review', 'Done'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-lg font-mono transition-colors cursor-pointer ${
                filterStatus === st
                  ? 'bg-[#FF5A1F] text-white font-semibold'
                  : 'bg-white/5 text-white/60 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-white/40 font-mono">Priority:</span>
          {['All', 'Urgent', 'High', 'Medium', 'Low'].map((pr) => (
            <button
              key={pr}
              type="button"
              onClick={() => setFilterPriority(pr)}
              className={`px-3 py-1.5 rounded-lg font-mono transition-colors cursor-pointer ${
                filterPriority === pr
                  ? 'bg-[#244BFF] text-white font-semibold'
                  : 'bg-white/5 text-white/60 hover:text-white'
              }`}
            >
              {pr}
            </button>
          ))}
        </div>
      </div>

      {/* Tasks Table / Empty State */}
      {filteredTasks.length === 0 ? (
        <div className="glass-surface p-12 rounded-2xl border border-white/10 text-center">
          <CheckSquare className="w-10 h-10 text-white/30 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">No Tasks Logged</h3>
          <p className="text-xs text-white/50 max-w-sm mx-auto mt-1">
            Zero tasks currently match your filters. Create a task for an active project to track milestone progress.
          </p>
        </div>
      ) : (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/[0.02] border-b border-white/10 font-mono text-[11px] text-white/40">
              <tr>
                <th className="p-4">Task Details</th>
                <th className="p-4">Priority</th>
                <th className="p-4">Assigned Engineer</th>
                <th className="p-4">Due Date</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredTasks.map((t) => (
                <tr key={t.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="p-4">
                    <div className="font-semibold text-white">{t.title}</div>
                    {t.description && (
                      <div className="text-[11px] text-white/50 truncate max-w-xs mt-0.5">
                        {t.description}
                      </div>
                    )}
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-0.5 rounded font-mono text-[10px] border ${getPriorityBadge(t.priority)}`}>
                      {t.priority}
                    </span>
                  </td>
                  <td className="p-4 font-mono text-white/80">
                    {t.assignedToName || 'Unassigned'}
                  </td>
                  <td className="p-4 font-mono text-white/60">
                    {t.dueDate || 'No deadline'}
                  </td>
                  <td className="p-4">
                    <select
                      value={t.status}
                      onChange={(e) => handleUpdateStatus(t.id, e.target.value as any)}
                      className="px-2.5 py-1 rounded-lg bg-[#070b24] border border-white/15 text-white font-mono text-[11px] focus:outline-none"
                    >
                      <option value="To Do">To Do</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Review">Review</option>
                      <option value="Done">Done</option>
                    </select>
                  </td>
                  <td className="p-4 text-right">
                    <button
                      type="button"
                      onClick={() => setSelectedTask(t)}
                      className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-[11px] transition-colors cursor-pointer"
                    >
                      Notes ({t.progressNotes?.length || 0})
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Selected Task Notes Drawer */}
      {selectedTask && (
        <div className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <div className="text-xs font-mono text-[#FF5A1F]">Task Progress & Activity</div>
              <h3 className="text-base font-bold text-white mt-0.5">{selectedTask.title}</h3>
            </div>
            <button onClick={() => setSelectedTask(null)} className="text-white/60 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {(!selectedTask.progressNotes || selectedTask.progressNotes.length === 0) ? (
              <div className="text-xs text-white/40 py-2">No progress notes submitted yet.</div>
            ) : (
              selectedTask.progressNotes.map((n) => (
                <div key={n.id} className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs">
                  <div className="flex items-center justify-between text-[10px] font-mono text-white/40 mb-1">
                    <span>{n.authorName}</span>
                    <span>{new Date(n.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="text-white/80 leading-relaxed">{n.text}</p>
                </div>
              ))
            )}
          </div>

          <form onSubmit={handleAddNote} className="flex gap-2">
            <input
              type="text"
              required
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="Submit progress note or commit reference..."
              className="flex-1 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white"
            />
            <button
              type="submit"
              disabled={addingNote}
              className="px-4 py-2 rounded-xl bg-[#244BFF] hover:bg-blue-600 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
            >
              {addingNote ? 'Adding...' : 'Post Note'}
            </button>
          </form>
        </div>
      )}

      {/* New Task Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl bg-[#080D25] border border-white/20 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white font-heading">Create Project Task</h3>
              <button onClick={() => setShowNewModal(false)} className="text-white/60 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3 text-xs">
              <div>
                <label className="block text-white/60 font-mono mb-1">Target Project *</label>
                <select
                  value={newProjectId}
                  onChange={(e) => setNewProjectId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0f2e] border border-white/10 text-white"
                >
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Implement Webhook Signature Verification"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/60 font-mono mb-1">Priority</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0a0f2e] border border-white/10 text-white"
                  >
                    <option value="Urgent">Urgent</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white/60 font-mono mb-1">Due Date</label>
                  <input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Description</label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Detailed acceptance criteria..."
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-white/70 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white font-semibold cursor-pointer"
                >
                  {submitting ? 'Creating...' : 'Create Task'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
