import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  FileCheck2,
  Lock,
  AlertTriangle,
  Plus,
  RefreshCw,
  Search,
  CheckCircle2,
  X,
  FileText,
  User,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { SecurityAssessment, SecurityFinding } from '../../server/db/types';

export const CybersecurityHub: React.FC = () => {
  const { token, user } = useAuth();
  const [assessments, setAssessments] = useState<SecurityAssessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAssessment, setSelectedAssessment] = useState<SecurityAssessment | null>(null);

  // New assessment modal
  const [showNewModal, setShowNewModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTarget, setNewTarget] = useState('');
  const [newType, setNewType] = useState<SecurityAssessment['assessmentType']>('Web Application Review');
  const [newAuthorizedBy, setNewAuthorizedBy] = useState('');
  const [newAuthDocRef, setNewAuthDocRef] = useState('');
  const [newScope, setNewScope] = useState('');
  const [submittingNew, setSubmittingNew] = useState(false);

  // Add finding modal
  const [showFindingModal, setShowFindingModal] = useState(false);
  const [findingTitle, setFindingTitle] = useState('');
  const [findingSeverity, setFindingSeverity] = useState<SecurityFinding['severity']>('Medium');
  const [findingCategory, setFindingCategory] = useState('Authentication & Access');
  const [findingEndpoint, setFindingEndpoint] = useState('');
  const [findingDescription, setFindingDescription] = useState('');
  const [findingImpact, setFindingImpact] = useState('');
  const [findingRemediation, setFindingRemediation] = useState('');
  const [submittingFinding, setSubmittingFinding] = useState(false);

  const fetchAssessments = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/cybersecurity', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAssessments(data.assessments || []);
        if (selectedAssessment) {
          const updated = (data.assessments || []).find((a: SecurityAssessment) => a.id === selectedAssessment.id);
          if (updated) setSelectedAssessment(updated);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAssessments();
  }, [token]);

  const handleCreateAssessment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newTarget || !newAuthorizedBy || !newScope) return;

    setSubmittingNew(true);
    try {
      const res = await fetch('/api/cybersecurity', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: newTitle,
          targetSystem: newTarget,
          assessmentType: newType,
          authorizedBy: newAuthorizedBy,
          authorizationDocumentRef: newAuthDocRef,
          scopeDefinition: newScope,
        }),
      });

      if (res.ok) {
        setShowNewModal(false);
        setNewTitle('');
        setNewTarget('');
        setNewAuthorizedBy('');
        setNewAuthDocRef('');
        setNewScope('');
        fetchAssessments();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingNew(false);
    }
  };

  const handleAddFinding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssessment || !findingTitle || !findingDescription || !findingRemediation) return;

    setSubmittingFinding(true);
    try {
      const res = await fetch(`/api/cybersecurity/${selectedAssessment.id}/findings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: findingTitle,
          severity: findingSeverity,
          category: findingCategory,
          targetEndpoint: findingEndpoint,
          description: findingDescription,
          impact: findingImpact,
          remediation: findingRemediation,
        }),
      });

      if (res.ok) {
        setShowFindingModal(false);
        setFindingTitle('');
        setFindingEndpoint('');
        setFindingDescription('');
        setFindingImpact('');
        setFindingRemediation('');
        fetchAssessments();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingFinding(false);
    }
  };

  const getSeverityBadge = (sev: SecurityFinding['severity']) => {
    switch (sev) {
      case 'Critical':
        return 'bg-red-500/20 text-red-400 border-red-500/40';
      case 'High':
        return 'bg-orange-500/20 text-orange-400 border-orange-500/40';
      case 'Medium':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'Low':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      default:
        return 'bg-white/10 text-white/70 border-white/20';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <ShieldCheck className="w-7 h-7 text-emerald-400" />
            <span>Cybersecurity Requests & Reports</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Lawful security assessments, access reviews, and remediation roadmaps for authorized client systems.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchAssessments}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          {(user?.role === 'super_admin' || user?.role === 'staff') && (
            <button
              type="button"
              onClick={() => setShowNewModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Authorized Assessment</span>
            </button>
          )}
        </div>
      </div>

      {/* Compliance & Authorization Banner */}
      <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 flex items-start gap-3 text-xs leading-relaxed text-white/75">
        <Lock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-white">Strict Authorization Mandate:</span> All security reviews require verifiable written authorization from system owners prior to assessment execution. Testing is strictly restricted to agreed scope boundaries without automated unauthorized scans.
        </div>
      </div>

      {/* Assessment List */}
      {assessments.length === 0 ? (
        <div className="glass-surface p-12 rounded-2xl border border-white/10 text-center">
          <ShieldAlert className="w-10 h-10 text-white/30 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">No Security Assessments Logged</h3>
          <p className="text-xs text-white/50 max-w-md mx-auto mt-1">
            Zero security records currently registered. When clients request authorized application reviews or hardening, verified engagement scopes appear here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {assessments.map((a) => (
            <div
              key={a.id}
              onClick={() => setSelectedAssessment(a)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer group ${
                selectedAssessment?.id === a.id
                  ? 'bg-emerald-500/10 border-emerald-500/50 shadow-lg shadow-emerald-500/10'
                  : 'bg-white/[0.02] hover:bg-white/[0.05] border-white/10'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono text-emerald-400 font-bold">{a.id}</span>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    a.authorizationStatus === 'Authorization Verified'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  }`}
                >
                  {a.authorizationStatus}
                </span>
              </div>

              <h3 className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors">
                {a.title}
              </h3>
              <p className="text-xs text-white/50 font-mono mt-1 truncate">
                Target: {a.targetSystem}
              </p>

              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-white/60">
                <span>{a.findings.length} findings logged</span>
                <span className="font-mono text-white/40">{new Date(a.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Selected Assessment Drawer */}
      {selectedAssessment && (
        <div className="glass-surface p-6 sm:p-8 rounded-2xl border border-white/10 space-y-6 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
                <span>{selectedAssessment.id}</span>
                <span>·</span>
                <span>{selectedAssessment.assessmentType}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-heading text-white mt-1">
                {selectedAssessment.title}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowFindingModal(true)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Log Vulnerability Finding</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedAssessment(null)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Scope & Authorization Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <span className="text-white/40 block text-[10px] uppercase">Target Environment</span>
              <span className="text-white font-semibold mt-1 block">{selectedAssessment.targetSystem}</span>
            </div>
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <span className="text-white/40 block text-[10px] uppercase">Authorized Contact</span>
              <span className="text-white font-semibold mt-1 block">{selectedAssessment.authorizedBy}</span>
            </div>
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <span className="text-white/40 block text-[10px] uppercase">Authorization Agreement</span>
              <span className="text-emerald-400 font-semibold mt-1 block truncate">
                {selectedAssessment.authorizationDocumentRef}
              </span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 text-xs">
            <div className="text-[10px] font-mono text-white/40 uppercase mb-1">Defined Scope Boundaries</div>
            <p className="text-white/80 leading-relaxed font-mono whitespace-pre-wrap">
              {selectedAssessment.scopeDefinition}
            </p>
          </div>

          {/* Findings Table */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center justify-between">
              <span>Technical Findings & Remediation Matrix ({selectedAssessment.findings.length})</span>
            </h3>

            {selectedAssessment.findings.length === 0 ? (
              <div className="p-8 rounded-xl bg-white/[0.01] border border-white/5 text-center text-xs text-white/40">
                No findings currently logged for this assessment.
              </div>
            ) : (
              <div className="space-y-3">
                {selectedAssessment.findings.map((f) => (
                  <div key={f.id} className="p-4 rounded-xl bg-white/[0.02] border border-white/10 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded font-mono text-[10px] border ${getSeverityBadge(f.severity)}`}>
                          {f.severity}
                        </span>
                        <span className="font-semibold text-white">{f.title}</span>
                      </div>
                      <span className="text-[10px] font-mono text-white/40">{f.category}</span>
                    </div>

                    <p className="text-white/70 leading-relaxed">{f.description}</p>

                    <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20 space-y-1">
                      <div className="font-mono text-emerald-400 text-[11px] font-semibold">Remediation Roadmap:</div>
                      <div className="text-white/80 font-mono text-[11px]">{f.remediation}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* New Assessment Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl bg-[#080D25] border border-white/20 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white font-heading">New Lawful Security Assessment</h3>
              <button onClick={() => setShowNewModal(false)} className="text-white/60 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAssessment} className="space-y-3 text-xs">
              <div>
                <label className="block text-white/60 font-mono mb-1">Assessment Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Q4 Web Portal Vulnerability & Access Review"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Target System / Application *</label>
                <input
                  type="text"
                  required
                  value={newTarget}
                  onChange={(e) => setNewTarget(e.target.value)}
                  placeholder="https://app.clientdomain.com or API Gateway"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Assessment Type *</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0f2e] border border-white/10 text-white"
                >
                  <option value="Web Application Review">Web Application Review</option>
                  <option value="Access Control & Auth Review">Access Control & Auth Review</option>
                  <option value="Vulnerability Assessment">Vulnerability Assessment</option>
                  <option value="Hardening & Config Review">Hardening & Config Review</option>
                  <option value="Incident Readiness & Backup Review">Incident Readiness & Backup Review</option>
                </select>
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Authorized Contact (Owner/Admin) *</label>
                <input
                  type="text"
                  required
                  value={newAuthorizedBy}
                  onChange={(e) => setNewAuthorizedBy(e.target.value)}
                  placeholder="client@company.com"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Written Authorization Reference / NDA</label>
                <input
                  type="text"
                  value={newAuthDocRef}
                  onChange={(e) => setNewAuthDocRef(e.target.value)}
                  placeholder="e.g. Signed Written Scope Statement #SEC-AUTH-2026-01"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Explicit Scope Boundaries *</label>
                <textarea
                  rows={3}
                  required
                  value={newScope}
                  onChange={(e) => setNewScope(e.target.value)}
                  placeholder="Explicitly permitted hostnames, endpoints, IP ranges and out-of-bounds restrictions..."
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-white/70 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingNew}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer"
                >
                  {submittingNew ? 'Creating...' : 'Register Scope'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Log Finding Modal */}
      {showFindingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl bg-[#080D25] border border-white/20 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white font-heading">Log Vulnerability Finding</h3>
              <button onClick={() => setShowFindingModal(false)} className="text-white/60 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddFinding} className="space-y-3 text-xs">
              <div>
                <label className="block text-white/60 font-mono mb-1">Finding Title *</label>
                <input
                  type="text"
                  required
                  value={findingTitle}
                  onChange={(e) => setFindingTitle(e.target.value)}
                  placeholder="e.g. Missing Content Security Policy (CSP) Frame Ancestors"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/60 font-mono mb-1">Severity *</label>
                  <select
                    value={findingSeverity}
                    onChange={(e) => setFindingSeverity(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0a0f2e] border border-white/10 text-white"
                  >
                    <option value="Critical">Critical</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                    <option value="Info">Info</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white/60 font-mono mb-1">Category</label>
                  <input
                    type="text"
                    value={findingCategory}
                    onChange={(e) => setFindingCategory(e.target.value)}
                    placeholder="Configuration / Auth / Headers"
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Target Endpoint / Component</label>
                <input
                  type="text"
                  value={findingEndpoint}
                  onChange={(e) => setFindingEndpoint(e.target.value)}
                  placeholder="/api/auth/session or HTTPS Gateway"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Description *</label>
                <textarea
                  rows={2}
                  required
                  value={findingDescription}
                  onChange={(e) => setFindingDescription(e.target.value)}
                  placeholder="Technical description of the observation..."
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-white/60 font-mono mb-1">Remediation Roadmap *</label>
                <textarea
                  rows={2}
                  required
                  value={findingRemediation}
                  onChange={(e) => setFindingRemediation(e.target.value)}
                  placeholder="Specific configuration or code changes recommended..."
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowFindingModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-white/70 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingFinding}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer"
                >
                  {submittingFinding ? 'Saving...' : 'Add Finding'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
