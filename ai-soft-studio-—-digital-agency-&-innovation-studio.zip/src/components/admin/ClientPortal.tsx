import React, { useState, useEffect } from 'react';
import {
  FolderGit2,
  CheckCircle2,
  Clock,
  Receipt,
  FileCode,
  ExternalLink,
  MessageSquare,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Send,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Project, Invoice, Payment, Milestone } from '../../server/db/types';

export const ClientPortal: React.FC = () => {
  const { token, user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [approvingMs, setApprovingMs] = useState<string | null>(null);

  // New Brief submission state
  const [briefService, setBriefService] = useState('Website Development');
  const [briefText, setBriefText] = useState('');
  const [briefSubmitting, setBriefSubmitting] = useState(false);
  const [briefSuccess, setBriefSuccess] = useState<string | null>(null);

  const fetchClientData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [pRes, iRes, payRes] = await Promise.all([
        fetch('/api/projects', { headers }),
        fetch('/api/finance/invoices', { headers }),
        fetch('/api/finance/payments', { headers }),
      ]);

      if (pRes.ok) {
        const d = await pRes.json();
        setProjects(d.projects || []);
      }
      if (iRes.ok) {
        const d = await iRes.json();
        setInvoices(d.invoices || []);
      }
      if (payRes.ok) {
        const d = await payRes.json();
        setPayments(d.payments || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClientData();
  }, [token]);

  const handleApproveMilestone = async (projectId: string, milestoneId: string) => {
    setApprovingMs(milestoneId);
    try {
      const res = await fetch(`/api/projects/${projectId}/milestones/${milestoneId}/approve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchClientData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setApprovingMs(null);
    }
  };

  const handleSubmitBrief = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!briefText.trim()) return;

    setBriefSubmitting(true);
    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: user?.name,
          email: user?.email,
          businessName: user?.businessName,
          service: briefService,
          projectDescription: briefText,
          source: 'direct',
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setBriefSuccess(`Your project brief (${d.enquiryId}) has been registered directly with your lead engineer.`);
        setBriefText('');
        setTimeout(() => setBriefSuccess(null), 5000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setBriefSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className="glass-surface p-6 sm:p-8 rounded-2xl border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#FF5A1F]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-2xl">
          <div className="text-xs font-mono text-[#FF5A1F] uppercase mb-1">
            Secure Client Workspace
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white">
            Welcome, {user?.name}
          </h1>
          <p className="text-xs sm:text-sm text-white/70 mt-2 leading-relaxed">
            Monitor real-time engineering milestones, inspect verified project deliverables, review billing statements, and approve completed phases.
          </p>
        </div>
      </div>

      {/* Client Projects Section */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold font-heading text-white flex items-center gap-2">
          <FolderGit2 className="w-5 h-5 text-[#FF5A1F]" />
          <span>Active Engagements & Sprints ({projects.length})</span>
        </h2>

        {projects.length === 0 ? (
          <div className="glass-surface p-10 rounded-2xl border border-white/10 text-center text-xs font-mono text-white/50">
            No active project engagements registered yet. Submit a project brief below to initiate a new sprint.
          </div>
        ) : (
          projects.map((project) => (
            <div key={project.id} className="glass-surface p-6 rounded-2xl border border-white/10 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
                <div>
                  <div className="text-xs font-mono text-[#FF5A1F] font-bold">{project.id} · {project.service}</div>
                  <h3 className="text-xl font-bold font-heading text-white mt-0.5">{project.name}</h3>
                  <div className="text-xs text-white/60 font-mono mt-0.5">
                    Target Launch: {project.deadline} · Agreed Scope: ${project.budget.toLocaleString()}
                  </div>
                </div>

                {/* Progress Metric */}
                <div className="text-right">
                  <div className="text-2xl font-bold font-mono text-white">{project.progress}%</div>
                  <div className="text-[11px] font-mono text-white/40">Sprint Completion</div>
                </div>
              </div>

              {/* Milestones & Deliverables */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* Milestones (Span 7) */}
                <div className="md:col-span-7 space-y-3">
                  <div className="text-xs font-mono uppercase tracking-wider text-white/60">
                    Phased Milestones & Client Sign-off
                  </div>
                  <div className="space-y-2.5">
                    {project.milestones.map((ms) => (
                      <div
                        key={ms.id}
                        className="p-3.5 rounded-xl bg-white/[0.02] border border-white/5 text-xs flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-semibold text-white flex items-center gap-2">
                            <span>{ms.title}</span>
                            {ms.approvedByClient && (
                              <span className="text-[10px] text-emerald-400 font-mono">Approved ✓</span>
                            )}
                          </div>
                          <div className="text-white/60 text-[11px] mt-0.5">{ms.description}</div>
                          <div className="text-[10px] font-mono text-white/40 mt-1">Due: {ms.dueDate}</div>
                        </div>

                        {!ms.approvedByClient && (
                          <button
                            type="button"
                            disabled={approvingMs === ms.id}
                            onClick={() => handleApproveMilestone(project.id, ms.id)}
                            className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono font-semibold shrink-0 cursor-pointer"
                          >
                            {approvingMs === ms.id ? 'Approving...' : 'Approve Milestone'}
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Deliverables / Links (Span 5) */}
                <div className="md:col-span-5 space-y-3">
                  <div className="text-xs font-mono uppercase tracking-wider text-white/60">
                    Verified Deliverables ({project.deliverables.length})
                  </div>
                  {project.deliverables.length === 0 ? (
                    <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 text-xs font-mono text-white/40">
                      Deliverables will appear here upon completion of milestones.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {project.deliverables.map((deliv) => (
                        <div
                          key={deliv.id}
                          className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-xs flex items-center justify-between"
                        >
                          <div>
                            <div className="font-medium text-white">{deliv.title}</div>
                            <div className="text-[10px] font-mono text-white/40">{deliv.fileType}</div>
                          </div>
                          <a
                            href={deliv.url}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-[#FF5A1F]"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Invoices & Billing Overview */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold font-heading text-white flex items-center gap-2">
          <Receipt className="w-5 h-5 text-[#244BFF]" />
          <span>Billing Statements & Receipts ({invoices.length})</span>
        </h2>

        {invoices.length === 0 ? (
          <div className="glass-surface p-8 rounded-2xl border border-white/10 text-center text-xs font-mono text-white/50">
            No invoices currently issued for your account.
          </div>
        ) : (
          <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                <tr>
                  <th className="p-4">Invoice ID</th>
                  <th className="p-4">Amount</th>
                  <th className="p-4">Paid</th>
                  <th className="p-4">Balance Due</th>
                  <th className="p-4">Due Date</th>
                  <th className="p-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {invoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="p-4 font-mono text-[#FF5A1F] font-bold">{inv.id}</td>
                    <td className="p-4 font-mono font-bold text-white">${inv.total.toLocaleString()}</td>
                    <td className="p-4 font-mono text-emerald-400">${inv.amountPaid.toLocaleString()}</td>
                    <td className="p-4 font-mono text-amber-400 font-bold">${inv.balanceDue.toLocaleString()}</td>
                    <td className="p-4 font-mono text-white/50">{inv.dueDate}</td>
                    <td className="p-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                          inv.status === 'Paid'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Direct Channel: Submit New Scope / Project Brief */}
      <div className="glass-surface p-6 sm:p-8 rounded-2xl border border-white/10 space-y-4">
        <h3 className="text-base font-bold font-heading text-white flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-[#FF5A1F]" />
          <span>Submit Project Brief or New Feature Request</span>
        </h3>
        <p className="text-xs text-white/60">
          Need an additional module, integration, or new project? Submit your brief directly to your assigned engineering team:
        </p>

        {briefSuccess && (
          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
            {briefSuccess}
          </div>
        )}

        <form onSubmit={handleSubmitBrief} className="space-y-4 text-xs">
          <div>
            <label className="block text-[11px] font-mono text-white/60 mb-1">Target Service</label>
            <select
              value={briefService}
              onChange={(e) => setBriefService(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#080D25] border border-white/10 text-white"
            >
              <option value="Website Development">Website Development</option>
              <option value="AI Automation">AI Automation</option>
              <option value="E-commerce Development">E-commerce Development</option>
              <option value="Custom Admin Panels">Custom Admin Panels</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-white/60 mb-1">Scope Brief & Requirements *</label>
            <textarea
              rows={4}
              required
              value={briefText}
              onChange={(e) => setBriefText(e.target.value)}
              placeholder="Describe the new features, architecture adjustments, or timelines needed..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={briefSubmitting || !briefText.trim()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white font-semibold text-xs disabled:opacity-40 shadow-lg shadow-[#FF5A1F]/20 cursor-pointer"
          >
            {briefSubmitting ? 'Submitting...' : 'Send Brief to Studio Team'}
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
