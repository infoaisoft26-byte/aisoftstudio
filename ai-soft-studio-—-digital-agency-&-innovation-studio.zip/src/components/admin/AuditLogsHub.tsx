import React, { useState, useEffect } from 'react';
import {
  History,
  Shield,
  Search,
  RefreshCw,
  Filter,
  User,
  Clock,
  Terminal,
  FileCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AuditLog } from '../../server/db/types';

export const AuditLogsHub: React.FC = () => {
  const { token } = useAuth();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('All');

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/audit-logs', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setLogs(data.logs || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [token]);

  const filteredLogs = logs.filter((l) => {
    if (actionFilter !== 'All' && !l.action.toLowerCase().includes(actionFilter.toLowerCase())) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        l.action.toLowerCase().includes(q) ||
        l.userName.toLowerCase().includes(q) ||
        l.details.toLowerCase().includes(q) ||
        (l.resource && l.resource.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <History className="w-7 h-7 text-[#FF5A1F]" />
            <span>Security & System Audit Logs</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Immutable system audit records recording staff logins, permission changes, inquiry routing, and payment verification.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchLogs}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Logs</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-surface p-4 rounded-2xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search action, user, or details..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 font-mono focus:outline-none focus:border-[#FF5A1F]"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto">
          {['All', 'LOGIN', 'INQUIRY', 'PAYMENT', 'PROJECT', 'SECURITY'].map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActionFilter(cat)}
              className={`px-3 py-1.5 rounded-lg font-mono transition-colors whitespace-nowrap cursor-pointer ${
                actionFilter === cat
                  ? 'bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white'
                  : 'bg-white/5 text-white/60 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Logs Table */}
      <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="p-12 text-center text-xs text-white/40">
            No audit logs found matching your criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/10 font-mono text-[11px] text-white/40">
                <tr>
                  <th className="p-4">Timestamp</th>
                  <th className="p-4">Action</th>
                  <th className="p-4">User</th>
                  <th className="p-4">Resource</th>
                  <th className="p-4">Details</th>
                  <th className="p-4">IP Address</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-[11px]">
                {filteredLogs.map((l) => (
                  <tr key={l.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="p-4 text-white/50 whitespace-nowrap">
                      {new Date(l.timestamp).toLocaleString()}
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded bg-white/5 text-[#FF5A1F] font-bold border border-white/5">
                        {l.action}
                      </span>
                    </td>
                    <td className="p-4 text-white/80">
                      <div>{l.userName}</div>
                      <div className="text-[10px] text-white/40">{l.userRole}</div>
                    </td>
                    <td className="p-4 text-white/60">{l.resource}</td>
                    <td className="p-4 text-white/70 max-w-sm truncate" title={l.details}>
                      {l.details}
                    </td>
                    <td className="p-4 text-white/40">{l.ip || '127.0.0.1'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
