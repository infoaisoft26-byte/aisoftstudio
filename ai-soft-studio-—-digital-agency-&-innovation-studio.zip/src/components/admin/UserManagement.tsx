import React, { useState, useEffect } from 'react';
import {
  Users,
  Shield,
  UserCheck,
  Code2,
  Plus,
  RefreshCw,
  History,
  Lock,
  Mail,
  CheckCircle2,
  XCircle,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole, AuditLog } from '../../server/db/types';

export const UserManagement: React.FC = () => {
  const { token, user } = useAuth();
  const [activeTab, setActiveTab] = useState<'users' | 'audit_logs'>('users');
  const [userList, setUserList] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Create User Modal
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>('staff');
  const [newUserBusiness, setNewUserBusiness] = useState('');
  const [creatingUser, setCreatingUser] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [uRes, aRes] = await Promise.all([
        fetch('/api/auth/users', { headers }),
        fetch('/api/auth/audit-logs', { headers }),
      ]);

      if (uRes.ok) {
        const d = await uRes.json();
        setUserList(d.users || []);
      }
      if (aRes.ok) {
        const d = await aRes.json();
        setAuditLogs(d.logs || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingUser(true);
    setCreateError(null);

    try {
      const res = await fetch('/api/auth/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: newUserName,
          email: newUserEmail,
          password: newUserPassword,
          role: newUserRole,
          businessName: newUserBusiness,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setShowAddUser(false);
        setNewUserName('');
        setNewUserEmail('');
        setNewUserPassword('');
        setNewUserBusiness('');
        fetchData();
      } else {
        setCreateError(data.error || 'Failed to create user');
      }
    } catch (err: any) {
      setCreateError(err.message);
    } finally {
      setCreatingUser(false);
    }
  };

  const handleToggleStatus = async (userId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    try {
      const res = await fetch(`/api/auth/users/${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        fetchData();
      } else {
        const d = await res.json();
        alert(d.error || 'Failed to update user status');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'super_admin':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#FF5A1F]/15 text-[#FF5A1F] border border-[#FF5A1F]/30">Super Admin</span>;
      case 'staff':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#244BFF]/15 text-[#244BFF] border border-[#244BFF]/30">Staff</span>;
      case 'developer':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">Developer</span>;
      case 'client':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/15 text-purple-300 border border-purple-500/30">Client</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/10 text-white/70">Unknown</span>;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            User Accounts & Security Audit
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Role-Based Access Control (RBAC), developer roster, client credentials, and cryptographic audit log.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddUser(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create User Account</span>
          </button>

          <button
            type="button"
            onClick={fetchData}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#FF5A1F]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 text-xs font-mono">
        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'users' ? 'bg-[#FF5A1F] text-white font-bold' : 'text-white/60 hover:text-white'
          }`}
        >
          User Accounts Directory ({userList.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('audit_logs')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'audit_logs' ? 'bg-[#FF5A1F] text-white font-bold' : 'text-white/60 hover:text-white'
          }`}
        >
          Security Audit Logs ({auditLogs.length})
        </button>
      </div>

      {/* Tab 1: Users Directory */}
      {activeTab === 'users' && (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                <tr>
                  <th className="p-4">User</th>
                  <th className="p-4">Role</th>
                  <th className="p-4">Business / Org</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Last Activity</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {userList.map((u) => (
                  <tr key={u.id} className="hover:bg-white/[0.02]">
                    <td className="p-4">
                      <div className="font-semibold text-white">{u.name}</div>
                      <div className="text-[11px] font-mono text-white/40">{u.email}</div>
                    </td>
                    <td className="p-4">{getRoleBadge(u.role)}</td>
                    <td className="p-4 text-white/70">{u.businessName || 'AI SOFT STUDIO Internal'}</td>
                    <td className="p-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                          u.status === 'active'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : 'bg-red-500/15 text-red-400 border-red-500/30'
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>
                    <td className="p-4 font-mono text-white/40 text-[11px]">
                      {u.lastLogin ? new Date(u.lastLogin).toLocaleDateString() : 'Never'}
                    </td>
                    <td className="p-4 text-right">
                      {u.id !== user?.id && (
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(u.id, u.status)}
                          className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-[11px] font-mono text-white/70 hover:text-white"
                        >
                          {u.status === 'active' ? 'Deactivate' : 'Activate'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Security Audit Logs */}
      {activeTab === 'audit_logs' && (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden space-y-4 p-6">
          <div className="text-xs text-white/60 font-mono">
            Immutable chronological audit record of authentication, project promotions, payments, and administrative actions:
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                <tr>
                  <th className="p-3">Action Event</th>
                  <th className="p-3">Actor</th>
                  <th className="p-3">Resource</th>
                  <th className="p-3">Details</th>
                  <th className="p-3">IP Address</th>
                  <th className="p-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/[0.02]">
                    <td className="p-3 font-mono text-[#FF5A1F] font-bold">{log.action}</td>
                    <td className="p-3 text-white">
                      <div>{log.userName}</div>
                      <div className="text-[10px] text-white/40 font-mono">{log.userRole}</div>
                    </td>
                    <td className="p-3 font-mono text-white/70 uppercase text-[11px]">{log.resource}</td>
                    <td className="p-3 text-white/80 max-w-sm truncate">{log.details}</td>
                    <td className="p-3 font-mono text-white/40">{log.ip || '127.0.0.1'}</td>
                    <td className="p-3 font-mono text-white/40">{new Date(log.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="max-w-md w-full p-6 rounded-2xl bg-[#080D25] border border-white/20 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold font-heading text-white">Create New User Account</h3>
              <button
                type="button"
                onClick={() => setShowAddUser(false)}
                className="p-1 rounded bg-white/5 text-white/60 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {createError && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs">
                {createError}
              </div>
            )}

            <form onSubmit={handleCreateUser} className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="e.g. Jordan Mercer"
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  placeholder="jordan@company.com"
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Password *</label>
                <input
                  type="password"
                  required
                  value={newUserPassword}
                  onChange={(e) => setNewUserPassword(e.target.value)}
                  placeholder="Strong temporary password..."
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Role Permission *</label>
                <select
                  value={newUserRole}
                  onChange={(e: any) => setNewUserRole(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white"
                >
                  <option value="staff">Operations Staff (Inquiries, Projects, Quotes)</option>
                  <option value="developer">Developer (Assigned Projects, Tasks, Deliverables)</option>
                  <option value="client">Client (Own Projects, Milestone Approvals, Invoices)</option>
                  <option value="super_admin">Super Admin (Full Platform Control)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Business Name (Optional)</label>
                <input
                  type="text"
                  value={newUserBusiness}
                  onChange={(e) => setNewUserBusiness(e.target.value)}
                  placeholder="e.g. Mercer Technologies"
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddUser(false)}
                  className="px-4 py-2 rounded-lg bg-white/5 text-white/70 text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creatingUser}
                  className="px-4 py-2 rounded-lg bg-[#FF5A1F] text-white font-semibold text-xs disabled:opacity-40"
                >
                  {creatingUser ? 'Creating...' : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
