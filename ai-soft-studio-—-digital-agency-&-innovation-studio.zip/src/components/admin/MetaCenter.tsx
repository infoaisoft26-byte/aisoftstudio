import React, { useState, useEffect } from 'react';
import {
  Share2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  ShieldCheck,
  Key,
  Globe,
  MessageCircle,
  Instagram,
  Send,
  Sliders,
  Terminal
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const MetaCenter: React.FC = () => {
  const { token, user } = useAuth();
  const [metaStatus, setMetaStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);
  const [copiedEndpoint, setCopiedEndpoint] = useState(false);

  // Configuration edit form
  const [appId, setAppId] = useState('');
  const [appSecret, setAppSecret] = useState('');
  const [verifyToken, setVerifyToken] = useState('aisoft_meta_verify_2026');
  const [savingConfig, setSavingConfig] = useState(false);
  const [configMessage, setConfigMessage] = useState<string | null>(null);

  // Lead Simulator state
  const [simName, setSimName] = useState('Meta Lead Inbound');
  const [simEmail, setSimEmail] = useState('lead@metatest.com');
  const [simPlatform, setSimPlatform] = useState('facebook_leadgen');
  const [simService, setSimService] = useState('AI Automation');
  const [simulating, setSimulating] = useState(false);
  const [simResult, setSimResult] = useState<string | null>(null);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/meta/status', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setMetaStatus(data.status);
        if (data.status.webhookVerifyToken) {
          setVerifyToken(data.status.webhookVerifyToken);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, [token]);

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    setConfigMessage(null);
    try {
      const res = await fetch('/api/meta/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          appId,
          appSecret,
          webhookVerifyToken: verifyToken,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setConfigMessage('Configuration updated. Server secret secured.');
        setAppSecret('');
        fetchStatus();
      } else {
        setConfigMessage(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setConfigMessage(`Error: ${err.message}`);
    } finally {
      setSavingConfig(false);
    }
  };

  const handleVerifyHandshake = async () => {
    setVerifying(true);
    try {
      const res = await fetch('/api/meta/verify-connection', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        fetchStatus();
      } else {
        alert(data.error || 'Verification failed');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setVerifying(false);
    }
  };

  const handleSimulateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    setSimulating(true);
    setSimResult(null);
    try {
      const res = await fetch('/api/meta/simulate-lead-event', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          leadName: simName,
          leadEmail: simEmail,
          platform: simPlatform,
          serviceRequired: simService,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setSimResult(`Ingestion verified: ${data.message}`);
        fetchStatus();
      }
    } catch (err: any) {
      setSimResult(`Error: ${err.message}`);
    } finally {
      setSimulating(false);
    }
  };

  const copyCallbackUrl = () => {
    const fullUrl = `${window.location.origin}/api/webhooks/meta`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedEndpoint(true);
    setTimeout(() => setCopiedEndpoint(false), 2000);
  };

  const isVerified = metaStatus?.isVerified;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            Meta Developer Integration Center
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Official Graph API webhooks, Lead Ads routing, WhatsApp Business, and Messenger automation.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchStatus}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#FF5A1F]' : ''}`} />
          <span>Refresh State</span>
        </button>
      </div>

      {/* Verified Status Banner */}
      <div
        className={`p-6 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
          isVerified
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
            : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
        }`}
      >
        <div className="flex items-center gap-3.5">
          <div
            className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${
              isVerified
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                : 'bg-amber-500/20 border-amber-500/40 text-amber-400'
            }`}
          >
            {isVerified ? <CheckCircle2 className="w-6 h-6" /> : <AlertTriangle className="w-6 h-6" />}
          </div>
          <div>
            <div className="text-sm font-bold font-heading text-white flex items-center gap-2">
              <span>Connection Status:</span>
              <span className="font-mono">{isVerified ? 'VERIFIED & ACTIVE' : 'AWAITING APP CREDENTIALS'}</span>
            </div>
            <div className="text-xs opacity-80 mt-0.5">
              {isVerified
                ? `Meta Webhook listener active with valid App ID and verification token handshake.`
                : `Supply your Meta App ID and App Secret to verify live Graph API connectivity.`}
            </div>
          </div>
        </div>

        <button
          type="button"
          disabled={verifying}
          onClick={handleVerifyHandshake}
          className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition-all cursor-pointer ${
            isVerified
              ? 'bg-emerald-500 text-white hover:bg-emerald-600'
              : 'bg-amber-500 text-black hover:bg-amber-400'
          }`}
        >
          {verifying ? 'Checking...' : isVerified ? 'Re-verify Handshake' : 'Verify App Credentials'}
        </button>
      </div>

      {/* Webhook Callback Endpoint Box */}
      <div className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
        <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
          <Terminal className="w-4 h-4 text-[#244BFF]" />
          <span>Official Meta Webhook Callback Configuration</span>
        </h3>
        <p className="text-xs text-white/60 leading-relaxed">
          Configure these parameters in the <strong>Meta App Dashboard</strong> under <em>Webhooks → Page / Leadgen</em>:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-white/40 text-[10px] block mb-1">CALLBACK URL</span>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[#FF5A1F] truncate">{window.location.origin}/api/webhooks/meta</span>
              <button
                type="button"
                onClick={copyCallbackUrl}
                className="p-1.5 rounded bg-white/10 hover:bg-white/20 text-white shrink-0"
                title="Copy URL"
              >
                {copiedEndpoint ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-white/40 text-[10px] block mb-1">VERIFY TOKEN</span>
            <div className="text-white font-semibold">
              {metaStatus?.webhookVerifyToken || 'aisoft_meta_verify_2026'}
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Grid: Credentials Form vs Test Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Secure Credentials Configuration */}
        <div className="lg:col-span-6 glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
            <Key className="w-4 h-4 text-[#FF5A1F]" />
            <span>Server-side Meta App Credentials</span>
          </h3>
          <p className="text-xs text-white/60">
            Secrets are encrypted and handled exclusively by backend proxy routes.
          </p>

          {configMessage && (
            <div className="p-3 rounded-lg bg-white/5 border border-white/10 text-xs text-white/80">
              {configMessage}
            </div>
          )}

          <form onSubmit={handleSaveConfig} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">Meta App ID</label>
              <input
                type="text"
                placeholder={metaStatus?.appId || 'e.g. 109283748291029'}
                value={appId}
                onChange={(e) => setAppId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">
                Meta App Secret {metaStatus?.hasAppSecret && '(Configured on Server ✓)'}
              </label>
              <input
                type="password"
                placeholder={metaStatus?.hasAppSecret ? '••••••••••••••••••••••••' : 'Enter Meta App Secret'}
                value={appSecret}
                onChange={(e) => setAppSecret(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-white/60 mb-1">Custom Webhook Verify Token</label>
              <input
                type="text"
                value={verifyToken}
                onChange={(e) => setVerifyToken(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={savingConfig}
              className="w-full py-2.5 rounded-xl bg-[#244BFF] hover:bg-blue-600 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {savingConfig ? 'Saving...' : 'Save Meta Configuration'}
            </button>
          </form>
        </div>

        {/* Right: Live Webhook Ingestion Simulator */}
        <div className="lg:col-span-6 glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
            <Share2 className="w-4 h-4 text-emerald-400" />
            <span>Test Inbound Webhook Event Simulator</span>
          </h3>
          <p className="text-xs text-white/60">
            Verify lead ingestion into Inquiry CRM without waiting for live Facebook ad campaigns:
          </p>

          {simResult && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
              {simResult}
            </div>
          )}

          <form onSubmit={handleSimulateEvent} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Lead Name</label>
                <input
                  type="text"
                  value={simName}
                  onChange={(e) => setSimName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Work Email</label>
                <input
                  type="email"
                  value={simEmail}
                  onChange={(e) => setSimEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Source Platform</label>
                <select
                  value={simPlatform}
                  onChange={(e) => setSimPlatform(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white"
                >
                  <option value="facebook_leadgen">Facebook Lead Ads</option>
                  <option value="whatsapp">WhatsApp Business API</option>
                  <option value="messenger">Facebook Messenger</option>
                  <option value="instagram">Instagram Professional DM</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-mono text-white/60 mb-1">Service Required</label>
                <select
                  value={simService}
                  onChange={(e) => setSimService(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white"
                >
                  <option value="Website Development">Website Development</option>
                  <option value="AI Automation">AI Automation</option>
                  <option value="E-commerce Development">E-commerce Development</option>
                  <option value="Custom Admin Panels">Custom Admin Panels</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={simulating}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white font-semibold text-xs shadow-lg shadow-[#FF5A1F]/20 transition-all cursor-pointer"
            >
              {simulating ? 'Simulating Webhook Event...' : 'Trigger Simulated Webhook Event'}
            </button>
          </form>
        </div>
      </div>

      {/* Recent Meta Event Log Table */}
      <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden space-y-3 p-6">
        <h3 className="text-sm font-bold font-heading text-white">
          Meta Webhook Event Telemetry ({(metaStatus?.recentLogs || []).length})
        </h3>
        <p className="text-xs text-white/50">
          Cryptographically validated webhook triggers, lead payload extractions, and status.
        </p>

        {(!metaStatus?.recentLogs || metaStatus.recentLogs.length === 0) ? (
          <div className="text-center py-8 text-xs font-mono text-white/40">
            No webhook events received yet. Run a simulated event above to test the ingestion stream.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                <tr>
                  <th className="p-3">Event Ref</th>
                  <th className="p-3">Source Channel</th>
                  <th className="p-3">Event Type</th>
                  <th className="p-3">Details / Outcome</th>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {metaStatus.recentLogs.map((log: any) => (
                  <tr key={log.id} className="hover:bg-white/[0.02]">
                    <td className="p-3 font-mono text-[#FF5A1F]">{log.id}</td>
                    <td className="p-3 capitalize font-mono text-white/80">{log.source}</td>
                    <td className="p-3 font-mono text-white/60">{log.eventType}</td>
                    <td className="p-3 text-white/80 max-w-xs truncate">{log.details}</td>
                    <td className="p-3 font-mono text-white/40">{new Date(log.timestamp).toLocaleTimeString()}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
