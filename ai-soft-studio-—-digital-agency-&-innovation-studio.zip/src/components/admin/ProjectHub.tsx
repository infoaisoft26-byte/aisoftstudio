import React, { useState, useEffect } from 'react';
import {
  FolderGit2,
  Plus,
  Calendar,
  CheckCircle2,
  Clock,
  Layers,
  FileCode,
  ExternalLink,
  User,
  ArrowRight,
  X,
  RefreshCw,
  Send,
  Upload,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Project, Task, Milestone, Deliverable } from '../../server/db/types';

export const ProjectHub: React.FC = () => {
  const { token, user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [projectTasks, setProjectTasks] = useState<Task[]>([]);

  // Task creation state
  const [taskTitle, setTaskTitle] = useState('');
  const [taskPriority, setTaskPriority] = useState<'Low' | 'Medium' | 'High' | 'Urgent'>('Medium');
  const [creatingTask, setCreatingTask] = useState(false);

  // Deliverable upload state
  const [delivTitle, setDelivTitle] = useState('');
  const [delivUrl, setDelivUrl] = useState('');
  const [uploadingDeliv, setUploadingDeliv] = useState(false);

  // Milestone creation state
  const [msTitle, setMsTitle] = useState('');
  const [msDueDate, setMsDueDate] = useState('');
  const [creatingMs, setCreatingMs] = useState(false);

  // New Project Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPrjName, setNewPrjName] = useState('');
  const [newPrjService, setNewPrjService] = useState('Website Development');
  const [newPrjClient, setNewPrjClient] = useState('');
  const [newPrjBudget, setNewPrjBudget] = useState('5000');
  const [newPrjDeadline, setNewPrjDeadline] = useState('');
  const [submittingPrj, setSubmittingPrj] = useState(false);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/projects', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setProjects(data.projects || []);
        if (selectedProject) {
          const updated = (data.projects || []).find((p: Project) => p.id === selectedProject.id);
          if (updated) setSelectedProject(updated);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchProjectTasks = async (projectId: string) => {
    try {
      const res = await fetch(`/api/projects/${projectId}/tasks`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setProjectTasks(data.tasks || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, [token]);

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    fetchProjectTasks(project.id);
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPrjName) return;

    setSubmittingPrj(true);
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: newPrjName,
          service: newPrjService,
          clientName: newPrjClient || 'Direct Studio Client',
          budget: newPrjBudget,
          deadline: newPrjDeadline,
        }),
      });

      if (res.ok) {
        setShowCreateModal(false);
        setNewPrjName('');
        fetchProjects();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingPrj(false);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !taskTitle.trim()) return;

    setCreatingTask(true);
    try {
      const res = await fetch(`/api/projects/${selectedProject.id}/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: taskTitle.trim(),
          priority: taskPriority,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setProjectTasks((prev) => [data.task, ...prev]);
        setTaskTitle('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCreatingTask(false);
    }
  };

  const handleUpdateTaskStatus = async (taskId: string, newStatus: any) => {
    try {
      const res = await fetch(`/api/projects/tasks/${taskId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        const data = await res.json();
        setProjectTasks((prev) => prev.map((t) => (t.id === taskId ? data.task : t)));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddDeliverable = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !delivTitle.trim() || !delivUrl.trim()) return;

    setUploadingDeliv(true);
    try {
      const res = await fetch(`/api/projects/${selectedProject.id}/deliverables`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: delivTitle.trim(),
          url: delivUrl.trim(),
          fileType: 'Repository / Staging Build',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const updated = {
          ...selectedProject,
          deliverables: [data.deliverable, ...selectedProject.deliverables],
        };
        setSelectedProject(updated);
        setProjects((prev) => prev.map((p) => (p.id === selectedProject.id ? updated : p)));
        setDelivTitle('');
        setDelivUrl('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUploadingDeliv(false);
    }
  };

  const handleAddMilestone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !msTitle.trim() || !msDueDate) return;

    setCreatingMs(true);
    try {
      const res = await fetch(`/api/projects/${selectedProject.id}/milestones`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: msTitle.trim(),
          dueDate: msDueDate,
          deliverables: ['Production Milestone Deliverables'],
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const updated = {
          ...selectedProject,
          milestones: [...selectedProject.milestones, data.milestone],
        };
        setSelectedProject(updated);
        setProjects((prev) => prev.map((p) => (p.id === selectedProject.id ? updated : p)));
        setMsTitle('');
        setMsDueDate('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCreatingMs(false);
    }
  };

  const isStaffOrAdmin = user?.role === 'super_admin' || user?.role === 'staff';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            {user?.role === 'developer' ? 'Assigned Engineering Projects' : 'Project Development & Tracking'}
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Sprint timelines, milestones, task boards, deliverables, and verified client sign-offs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isStaffOrAdmin && (
            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Project</span>
            </button>
          )}

          <button
            type="button"
            onClick={fetchProjects}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 cursor-pointer"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#FF5A1F]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Projects List or Empty State */}
      {projects.length === 0 ? (
        <div className="glass-surface p-12 rounded-2xl border border-white/10 text-center">
          <FolderGit2 className="w-10 h-10 text-white/30 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">No Projects Active</h3>
          <p className="text-xs text-white/50 max-w-sm mx-auto mt-1">
            {user?.role === 'developer'
              ? 'You do not have any active project assignments at this time.'
              : 'Convert incoming inquiries from the CRM or create a new project above.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              onClick={() => handleSelectProject(project)}
              className="glass-surface p-6 rounded-2xl border border-white/10 hover:border-[#244BFF]/40 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between font-mono text-[11px] mb-3">
                  <span className="text-[#FF5A1F] font-bold">{project.id}</span>
                  <span
                    className={`px-2 py-0.5 rounded border ${
                      project.status === 'Completed'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : project.status === 'In Progress'
                        ? 'bg-[#244BFF]/10 text-[#244BFF] border-[#244BFF]/20'
                        : 'bg-white/5 text-white/60 border-white/10'
                    }`}
                  >
                    {project.status}
                  </span>
                </div>

                <h3 className="text-lg font-bold font-heading text-white group-hover:text-white mb-1">
                  {project.name}
                </h3>
                <div className="text-xs text-white/50 mb-4">{project.clientName}</div>

                {/* Progress Bar */}
                <div className="space-y-1.5 mb-4">
                  <div className="flex justify-between text-[11px] font-mono text-white/60">
                    <span>Milestone Progress</span>
                    <span className="text-white font-bold">{project.progress}%</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#FF5A1F] to-[#244BFF] transition-all duration-500"
                      style={{ width: `${project.progress}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Bottom Specs */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs font-mono text-white/50">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-white/40" />
                  {project.deadline}
                </span>
                <span className="text-white/80 font-bold">${project.budget.toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Project Deep Dive Workspace Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-2xl bg-[#080D25] border border-white/15 p-6 sm:p-8 shadow-2xl space-y-6">
            {/* Modal Header */}
            <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <div className="text-xs font-mono text-[#FF5A1F] font-bold">
                  {selectedProject.id} · {selectedProject.service}
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold font-heading text-white mt-1">
                  {selectedProject.name}
                </h2>
                <div className="text-xs text-white/60 font-mono mt-0.5">
                  Client: {selectedProject.clientName} ({selectedProject.clientEmail}) · Target Launch: {selectedProject.deadline}
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Grid: Milestones vs Task Board */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Milestones (Span 6) */}
              <div className="lg:col-span-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#FF5A1F]" />
                    <span>Project Milestones ({selectedProject.milestones.length})</span>
                  </h3>
                </div>

                <div className="space-y-3 max-h-72 overflow-y-auto">
                  {selectedProject.milestones.map((ms) => (
                    <div
                      key={ms.id}
                      className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 text-xs flex flex-col justify-between"
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <span className="font-semibold text-white">{ms.title}</span>
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded border shrink-0 ${
                            ms.status === 'Completed'
                              ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                              : 'bg-white/5 text-white/60 border-white/10'
                          }`}
                        >
                          {ms.status}
                        </span>
                      </div>
                      <p className="text-white/60 text-[11px] mb-2">{ms.description}</p>
                      <div className="flex items-center justify-between text-[10px] font-mono text-white/40 pt-2 border-t border-white/5">
                        <span>Due: {ms.dueDate}</span>
                        <span>Client Approved: {ms.approvedByClient ? 'Yes ✓' : 'Pending'}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add Milestone Form (Admin/Staff only) */}
                {isStaffOrAdmin && (
                  <form onSubmit={handleAddMilestone} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-xs space-y-2">
                    <span className="font-mono text-[10px] text-white/50 block">Add Milestone</span>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Milestone title..."
                        value={msTitle}
                        onChange={(e) => setMsTitle(e.target.value)}
                        className="flex-1 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
                      />
                      <input
                        type="date"
                        value={msDueDate}
                        onChange={(e) => setMsDueDate(e.target.value)}
                        className="px-2 py-1.5 rounded-lg bg-[#080D25] border border-white/10 text-white text-xs"
                      />
                      <button
                        type="submit"
                        disabled={creatingMs || !msTitle.trim() || !msDueDate}
                        className="px-3 py-1.5 rounded-lg bg-[#FF5A1F] text-white font-semibold text-xs disabled:opacity-40"
                      >
                        Add
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Right Column: Sprint Task Board (Span 6) */}
              <div className="lg:col-span-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[#244BFF]" />
                    <span>Sprint Tasks ({projectTasks.length})</span>
                  </h3>
                </div>

                {/* Create Task Form */}
                <form onSubmit={handleCreateTask} className="flex gap-2">
                  <input
                    type="text"
                    value={taskTitle}
                    onChange={(e) => setTaskTitle(e.target.value)}
                    placeholder="New sprint task description..."
                    className="flex-1 px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder:text-white/30"
                  />
                  <select
                    value={taskPriority}
                    onChange={(e: any) => setTaskPriority(e.target.value)}
                    className="px-2.5 py-2 rounded-xl bg-[#080D25] border border-white/10 text-xs text-white"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                  <button
                    type="submit"
                    disabled={creatingTask || !taskTitle.trim()}
                    className="px-4 py-2 rounded-xl bg-[#244BFF] hover:bg-blue-600 text-white font-semibold text-xs disabled:opacity-40"
                  >
                    Add
                  </button>
                </form>

                {/* Task List */}
                <div className="space-y-2.5 max-h-72 overflow-y-auto">
                  {projectTasks.length === 0 ? (
                    <div className="text-xs font-mono text-white/40 py-4 text-center">
                      No sprint tasks created yet.
                    </div>
                  ) : (
                    projectTasks.map((task) => (
                      <div
                        key={task.id}
                        className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-medium text-white">{task.title}</div>
                          <div className="text-[10px] font-mono text-white/40 mt-0.5">
                            Priority: <span className="text-[#FF5A1F]">{task.priority}</span> · Assigned: {task.assignedToName || 'Team'}
                          </div>
                        </div>

                        {/* Status Toggle */}
                        <select
                          value={task.status}
                          onChange={(e) => handleUpdateTaskStatus(task.id, e.target.value)}
                          className="px-2 py-1 rounded bg-[#080D25] border border-white/10 text-[11px] font-mono text-white"
                        >
                          <option value="To Do">To Do</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Review">Review</option>
                          <option value="Done">Done</option>
                        </select>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Deliverables Section */}
            <div className="pt-4 border-t border-white/10 space-y-4">
              <h3 className="text-sm font-bold font-heading text-white flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-400" />
                <span>Verified Deliverables & Repositories ({selectedProject.deliverables.length})</span>
              </h3>

              {/* Upload / Link Form */}
              <form onSubmit={handleAddDeliverable} className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
                <input
                  type="text"
                  placeholder="Deliverable title (e.g. Staging Build V1.2)..."
                  value={delivTitle}
                  onChange={(e) => setDelivTitle(e.target.value)}
                  className="sm:col-span-5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
                <input
                  type="url"
                  placeholder="URL link (e.g. https://staging.client.com)..."
                  value={delivUrl}
                  onChange={(e) => setDelivUrl(e.target.value)}
                  className="sm:col-span-5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
                />
                <button
                  type="submit"
                  disabled={uploadingDeliv || !delivTitle.trim() || !delivUrl.trim()}
                  className="sm:col-span-2 py-2 px-3 rounded-xl bg-emerald-500/80 hover:bg-emerald-500 text-white font-semibold text-xs disabled:opacity-40"
                >
                  Upload Link
                </button>
              </form>

              {/* Deliverable Items */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedProject.deliverables.length === 0 ? (
                  <div className="text-xs font-mono text-white/40 col-span-2 py-2">
                    No deliverables uploaded yet.
                  </div>
                ) : (
                  selectedProject.deliverables.map((deliv) => (
                    <div
                      key={deliv.id}
                      className="p-3 rounded-xl bg-white/[0.03] border border-white/10 text-xs flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-white">{deliv.title}</div>
                        <div className="text-[10px] font-mono text-white/40 mt-0.5">
                          Uploaded by {deliv.uploadedByName} · {new Date(deliv.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <a
                        href={deliv.url}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-[#FF5A1F] transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Project Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="max-w-md w-full p-6 rounded-2xl bg-[#080D25] border border-white/20 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold font-heading text-white">Create New Project</h3>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Project Name *</label>
              <input
                type="text"
                required
                value={newPrjName}
                onChange={(e) => setNewPrjName(e.target.value)}
                placeholder="e.g. Aura Digital Flagship"
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Service Discipline</label>
              <select
                value={newPrjService}
                onChange={(e) => setNewPrjService(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white text-xs"
              >
                <option value="Website Development">Website Development</option>
                <option value="AI Automation">AI Automation</option>
                <option value="E-commerce Development">E-commerce Development</option>
                <option value="Custom Admin Panels">Custom Admin Panels</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Client Name</label>
              <input
                type="text"
                value={newPrjClient}
                onChange={(e) => setNewPrjClient(e.target.value)}
                placeholder="e.g. Elena Rostova"
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-white/60 mb-1">Budget ($)</label>
                <input
                  type="number"
                  value={newPrjBudget}
                  onChange={(e) => setNewPrjBudget(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-white/60 mb-1">Deadline</label>
                <input
                  type="date"
                  value={newPrjDeadline}
                  onChange={(e) => setNewPrjDeadline(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 rounded-lg bg-white/5 text-white/70 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={submittingPrj || !newPrjName.trim()}
                onClick={handleCreateProject}
                className="px-4 py-2 rounded-lg bg-[#FF5A1F] text-white font-semibold text-xs"
              >
                {submittingPrj ? 'Creating...' : 'Create Project'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
