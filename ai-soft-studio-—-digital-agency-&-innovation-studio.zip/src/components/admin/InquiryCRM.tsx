import React, { useState, useEffect } from 'react';
import {
  Inbox,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ArrowRight,
  MessageSquare,
  User,
  Calendar,
  Tag,
  Briefcase,
  X,
  Plus,
  RefreshCw,
  Send,
  Share2,
  Download,
  Phone,
  Mail
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Inquiry, InquiryStatus } from '../../server/db/types';

interface InquiryCRMProps {
  onProjectCreated?: () => void;
}

const STATUS_LIST: InquiryStatus[] = [
  'New',
  'Contacted',
  'Qualified',
  'Proposal Sent',
  'Awaiting Decision',
  'Won',
  'Lost',
  'Closed',
];

export const InquiryCRM: React.FC<InquiryCRMProps> = ({ onProjectCreated }) => {
  const { token, user } = useAuth();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedInquiry, setSelectedInquiry] = useState<Inquiry | null>(null);

  // Note form state
  const [noteText, setNoteText] = useState('');
  const [submittingNote, setSubmittingNote] = useState(false);

  // Convert to project modal state
  const [showConvertModal, setShowConvertModal] = useState(false);
  const [convertBudget, setConvertBudget] = useState('5000');
  const [convertDeadline, setConvertDeadline] = useState('');
  const [converting, setConverting] = useState(false);

  const fetchInquiries = async () => {
    setLoading(true);
    try {
      let url = '/api/inquiries?';
      if (statusFilter !== 'All') url += `status=${encodeURIComponent(statusFilter)}&`;
      if (search.trim()) url += `search=${encodeURIComponent(search.trim())}&`;

      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setInquiries(data.inquiries || []);
        // Update selected if open
        if (selectedInquiry) {
          const updated = (data.inquiries || []).find((i: Inquiry) => i.id === selectedInquiry.id);
          if (updated) setSelectedInquiry(updated);
        }
      }
    } catch (err) {
      console.error('Failed to load inquiries:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInquiries();
  }, [token, statusFilter]);

  const handleUpdateStatus = async (id: string, newStatus: InquiryStatus) => {
    try {
      const res = await fetch(`/api/inquiries/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedInquiry(data.inquiry);
        setInquiries((prev) => prev.map((i) => (i.id === id ? data.inquiry : i)));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInquiry || !noteText.trim()) return;

    setSubmittingNote(true);
    try {
      const res = await fetch(`/api/inquiries/${selectedInquiry.id}/notes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ text: noteText.trim() }),
      });
      if (res.ok) {
        const data = await res.json();
        const updated = { ...selectedInquiry, notes: data.notes };
        setSelectedInquiry(updated);
        setInquiries((prev) => prev.map((i) => (i.id === selectedInquiry.id ? updated : i)));
        setNoteText('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingNote(false);
    }
  };

  const handleConvertToProject = async () => {
    if (!selectedInquiry) return;
    setConverting(true);
    try {
      const res = await fetch(`/api/inquiries/${selectedInquiry.id}/convert-to-project`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          budget: convertBudget,
          deadline: convertDeadline,
        }),
      });

      if (res.ok) {
        setShowConvertModal(false);
        fetchInquiries();
        if (onProjectCreated) onProjectCreated();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setConverting(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Title & Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            Inquiry CRM
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Capture, follow up, and convert prospect inquiries from Web, Chat, and Meta Developer webhooks.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={fetchInquiries}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#FF5A1F]' : ''}`} />
            <span>Refresh</span>
          </button>
          <a
            href="/api/inquiries/export/csv"
            target="_blank"
            rel="noopener noreferrer"
            download
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </a>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-surface p-4 rounded-2xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchInquiries()}
            placeholder="Search by name, email, ref ID..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-[#FF5A1F]"
          />
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          {['All', ...STATUS_LIST].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white shadow-md shadow-[#FF5A1F]/20'
                  : 'bg-white/5 text-white/60 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Inquiries Table / Empty State */}
      {inquiries.length === 0 ? (
        <div className="glass-surface p-12 rounded-2xl border border-white/10 text-center">
          <Inbox className="w-10 h-10 text-white/30 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">No Inquiries Found</h3>
          <p className="text-xs text-white/50 max-w-sm mx-auto mt-1">
            There are currently no inquiries matching this filter. Submissions from the public contact form or Meta Webhook will appear here in real time.
          </p>
        </div>
      ) : (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                <tr>
                  <th className="p-4">Ref ID / Client</th>
                  <th className="p-4">Requested Service</th>
                  <th className="p-4">Source</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Date</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {inquiries.map((inq) => (
                  <tr
                    key={inq.id}
                    onClick={() => setSelectedInquiry(inq)}
                    className="hover:bg-white/[0.03] transition-colors cursor-pointer group"
                  >
                    <td className="p-4">
                      <div className="font-mono text-[#FF5A1F] font-bold">{inq.id}</div>
                      <div className="text-white font-medium text-xs mt-0.5">{inq.name}</div>
                      <div className="text-white/40 text-[11px] font-mono">{inq.email}</div>
                    </td>
                    <td className="p-4">
                      <div className="text-white font-medium">{inq.service}</div>
                      {inq.businessName && (
                        <div className="text-[11px] text-white/50">{inq.businessName}</div>
                      )}
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 font-mono text-[10px] text-white/70">
                        {inq.source.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-4">
                      <span
                        className={`px-2.5 py-1 rounded-md text-[11px] font-mono border ${
                          inq.status === 'New'
                            ? 'bg-[#FF5A1F]/15 text-[#FF5A1F] border-[#FF5A1F]/30'
                            : inq.status === 'In Progress'
                            ? 'bg-[#244BFF]/15 text-[#244BFF] border-[#244BFF]/30'
                            : inq.status === 'Completed'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : 'bg-white/10 text-white/70 border-white/15'
                        }`}
                      >
                        {inq.status}
                      </span>
                    </td>
                    <td className="p-4 font-mono text-white/50 text-[11px]">
                      {new Date(inq.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-4 text-right">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedInquiry(inq);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 group-hover:text-white transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Inquiry Detail Drawer / Modal */}
      {selectedInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-2xl bg-[#080D25] border border-white/15 p-6 sm:p-8 shadow-2xl">
            {/* Close */}
            <button
              onClick={() => setSelectedInquiry(null)}
              className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-xs font-mono text-[#FF5A1F] font-bold">
                  {selectedInquiry.id} · Source: {selectedInquiry.source}
                </div>
                <h2 className="text-2xl font-bold font-heading text-white mt-1">
                  {selectedInquiry.name}
                </h2>
                <div className="text-xs text-white/60 font-mono mt-0.5">
                  {selectedInquiry.email} {selectedInquiry.phone && `· ${selectedInquiry.phone}`}
                  {selectedInquiry.businessName && `· ${selectedInquiry.businessName}`}
                </div>
              </div>

              {/* Status Selector */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-white/40">Status:</span>
                <select
                  value={selectedInquiry.status}
                  onChange={(e) => handleUpdateStatus(selectedInquiry.id, e.target.value as InquiryStatus)}
                  className="px-3 py-1.5 rounded-lg bg-[#050818] border border-white/20 text-xs font-mono text-white focus:outline-none focus:border-[#FF5A1F]"
                >
                  {STATUS_LIST.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Project Brief Card */}
            <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 mb-6">
              <div className="text-xs font-mono text-[#244BFF] uppercase tracking-wider mb-2">
                Project Scope & Requirements
              </div>
              <div className="text-xs sm:text-sm text-white/85 leading-relaxed whitespace-pre-wrap">
                {selectedInquiry.projectDescription}
              </div>
              <div className="mt-3 pt-3 border-t border-white/5 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono text-white/50">
                {selectedInquiry.timeline && (
                  <div>
                    <span className="block text-white/30 text-[10px] uppercase">Timeline</span>
                    <span className="text-white/80">{selectedInquiry.timeline}</span>
                  </div>
                )}
                {(selectedInquiry.budgetRange || selectedInquiry.estimatedBudget) && (
                  <div>
                    <span className="block text-white/30 text-[10px] uppercase">Budget</span>
                    <span className="text-white/80">{selectedInquiry.budgetRange || selectedInquiry.estimatedBudget}</span>
                  </div>
                )}
                {selectedInquiry.preferredContactMethod && (
                  <div>
                    <span className="block text-white/30 text-[10px] uppercase">Channel</span>
                    <span className="text-white/80">{selectedInquiry.preferredContactMethod}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Convert to Project Action */}
            <div className="p-4 rounded-xl bg-[#244BFF]/10 border border-[#244BFF]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-[#244BFF]" />
                  <span>Promote Lead to Active Project</span>
                </div>
                <div className="text-[11px] text-white/60 mt-0.5">
                  Generates project repository, creates default development milestones, and provisions client portal access.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowConvertModal(true)}
                className="px-4 py-2 rounded-lg bg-[#244BFF] hover:bg-blue-600 text-white font-semibold text-xs whitespace-nowrap transition-colors cursor-pointer"
              >
                Convert to Project
              </button>
            </div>

            {/* Internal Staff Notes */}
            <div className="space-y-4 pt-4 border-t border-white/10">
              <h3 className="text-xs font-mono uppercase tracking-wider text-white/60">
                Staff Activity & Internal Notes ({selectedInquiry.notes.length})
              </h3>

              {/* Add Note Input */}
              <form onSubmit={handleAddNote} className="flex gap-2">
                <input
                  type="text"
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  placeholder="Add private staff note (e.g. Called client, shared scope deck)..."
                  className="flex-1 px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-[#FF5A1F]"
                />
                <button
                  type="submit"
                  disabled={submittingNote || !noteText.trim()}
                  className="px-4 py-2 rounded-xl bg-[#FF5A1F] text-white font-semibold text-xs disabled:opacity-50 cursor-pointer"
                >
                  Add Note
                </button>
              </form>

              {/* Notes Timeline */}
              <div className="space-y-2.5 max-h-56 overflow-y-auto">
                {selectedInquiry.notes.length === 0 ? (
                  <div className="text-xs font-mono text-white/40 py-2">No notes added yet.</div>
                ) : (
                  selectedInquiry.notes.map((note) => (
                    <div key={note.id} className="p-3 rounded-lg bg-white/[0.02] border border-white/5 text-xs">
                      <div className="flex items-center justify-between font-mono text-[10px] text-white/40 mb-1">
                        <span className="text-[#FF5A1F] font-semibold">{note.authorName}</span>
                        <span>{new Date(note.createdAt).toLocaleString()}</span>
                      </div>
                      <div className="text-white/80">{note.text}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Convert to Project Confirmation Modal */}
      {showConvertModal && selectedInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="max-w-md w-full p-6 rounded-2xl bg-[#080D25] border border-white/20 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold font-heading text-white">Promote to Project</h3>
            <p className="text-xs text-white/70">
              Convert <span className="text-[#FF5A1F]">{selectedInquiry.id}</span> ({selectedInquiry.name}) into an active project in the Development Hub.
            </p>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Agreed Project Budget ($ USD)</label>
              <input
                type="number"
                value={convertBudget}
                onChange={(e) => setConvertBudget(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Target Launch Deadline</label>
              <input
                type="date"
                value={convertDeadline}
                onChange={(e) => setConvertDeadline(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConvertModal(false)}
                className="px-4 py-2 rounded-lg bg-white/5 text-white/70 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={converting}
                onClick={handleConvertToProject}
                className="px-4 py-2 rounded-lg bg-[#244BFF] hover:bg-blue-600 text-white font-semibold text-xs"
              >
                {converting ? 'Promoting...' : 'Confirm & Create Project'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
