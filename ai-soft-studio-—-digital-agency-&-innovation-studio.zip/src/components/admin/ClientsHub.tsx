import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Mail,
  Phone,
  Briefcase,
  DollarSign,
  Receipt,
  RefreshCw,
  ExternalLink,
  Plus
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { User, Project, Invoice } from '../../server/db/types';

export const ClientsHub: React.FC = () => {
  const { token, user } = useAuth();
  const [clients, setClients] = useState<User[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [uRes, pRes, iRes] = await Promise.all([
        fetch('/api/auth/users', { headers }),
        fetch('/api/projects', { headers }),
        fetch('/api/finance/invoices', { headers }),
      ]);
      if (uRes.ok) {
        const d = await uRes.json();
        const allUsers = d.users || [];
        setClients(allUsers.filter((u: User) => u.role === 'client'));
      }
      if (pRes.ok) {
        const d = await pRes.json();
        setProjects(d.projects || []);
      }
      if (iRes.ok) {
        const d = await iRes.json();
        setInvoices(d.invoices || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  const filteredClients = clients.filter((c) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      (c.businessName && c.businessName.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <Users className="w-7 h-7 text-[#244BFF]" />
            <span>Clients & Directory</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Registered client accounts, active contracts, and engagement contact directory.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchData}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Clients</span>
        </button>
      </div>

      {/* Search */}
      <div className="glass-surface p-4 rounded-2xl border border-white/10 flex items-center justify-between gap-4">
        <div className="relative w-full max-w-sm">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by client name, email, company..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-[#FF5A1F]"
          />
        </div>
        <div className="text-xs font-mono text-white/50">
          Total Clients: <span className="text-white font-bold">{clients.length}</span>
        </div>
      </div>

      {/* Clients Cards / Table */}
      {filteredClients.length === 0 ? (
        <div className="glass-surface p-12 rounded-2xl border border-white/10 text-center text-xs text-white/40">
          <Users className="w-10 h-10 text-white/20 mx-auto mb-3" />
          <p>No client records found. Leads converted into projects automatically generate client accounts.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredClients.map((client) => {
            const clientProjects = projects.filter((p) => p.clientId === client.id || p.clientEmail.toLowerCase() === client.email.toLowerCase());
            const clientInvoices = invoices.filter((inv) => inv.clientId === client.id || inv.clientEmail.toLowerCase() === client.email.toLowerCase());
            const balanceDue = clientInvoices.reduce((acc, inv) => acc + inv.balanceDue, 0);

            return (
              <div
                key={client.id}
                className="glass-surface p-5 rounded-2xl border border-white/10 hover:border-white/20 transition-all space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-white text-base">{client.name}</h3>
                    <div className="text-xs text-[#FF5A1F] font-mono mt-0.5">
                      {client.businessName || 'Independent Client'}
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {client.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs font-mono text-white/60">
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-white/40" />
                    <a href={`mailto:${client.email}`} className="hover:text-white truncate">
                      {client.email}
                    </a>
                  </div>
                  {client.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-white/40" />
                      <a href={`tel:${client.phone}`} className="hover:text-white">
                        {client.phone}
                      </a>
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-white/5 grid grid-cols-2 gap-2 text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-white/40 block">Projects</span>
                    <span className="text-white font-bold">{clientProjects.length}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-white/40 block">Open Invoices</span>
                    <span className={balanceDue > 0 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                      ${balanceDue.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
