import React, { useState } from 'react';
import {
  LayoutDashboard,
  Inbox,
  FolderGit2,
  Receipt,
  Share2,
  Globe2,
  Users,
  LogOut,
  ArrowLeft,
  Shield,
  Code2,
  UserCheck,
  History,
  Menu,
  X,
  Bell,
  Sliders,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldCheck,
  MessageSquare,
  Bot,
  CheckSquare,
  BarChart3,
  Layers,
  FileText
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../server/db/types';

export type AdminTab =
  | 'overview'
  | 'inquiries'
  | 'clients'
  | 'services_packages'
  | 'quotations'
  | 'invoices_payments'
  | 'projects'
  | 'team'
  | 'tasks'
  | 'conversations'
  | 'chatbot'
  | 'meta'
  | 'cms'
  | 'cybersecurity'
  | 'notifications'
  | 'analytics'
  | 'audit_logs'
  | 'settings'
  | 'client_portal';

interface AdminLayoutProps {
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
  onBackToPublic: () => void;
  children: React.ReactNode;
}

interface NavItem {
  id: AdminTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: UserRole[];
}

interface NavGroup {
  groupName: string;
  items: NavItem[];
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  activeTab,
  onTabChange,
  onBackToPublic,
  children,
}) => {
  const { user, logout, quickSwitchRole } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showRoleSwitcher, setShowRoleSwitcher] = useState(false);

  const getRoleBadge = (role?: UserRole) => {
    switch (role) {
      case 'super_admin':
        return { label: 'Super Admin', color: 'bg-[#FF5A1F]/15 text-[#FF5A1F] border-[#FF5A1F]/30', icon: Shield };
      case 'staff':
        return { label: 'Operations Staff', color: 'bg-[#244BFF]/15 text-[#244BFF] border-[#244BFF]/30', icon: UserCheck };
      case 'developer':
        return { label: 'Engineer / Dev', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: Code2 };
      case 'client':
        return { label: 'Client Portal', color: 'bg-purple-500/15 text-purple-300 border-purple-500/30', icon: UserCheck };
      default:
        return { label: 'Guest', color: 'bg-white/10 text-white/70 border-white/20', icon: Shield };
    }
  };

  const roleInfo = getRoleBadge(user?.role);
  const RoleIcon = roleInfo.icon;

  // 18 Comprehensive Sidebar Sections grouped for maximum ergonomics
  const navGroups: NavGroup[] = [
    {
      groupName: 'Core & CRM',
      items: [
        { id: 'overview', label: '1. Overview Dashboard', icon: LayoutDashboard, roles: ['super_admin', 'staff'] },
        { id: 'inquiries', label: '2. Leads and Inquiries', icon: Inbox, roles: ['super_admin', 'staff'] },
        { id: 'clients', label: '3. Clients and Contacts', icon: Users, roles: ['super_admin', 'staff'] },
        { id: 'conversations', label: '10. Customer Conversations', icon: MessageSquare, roles: ['super_admin', 'staff'] },
      ],
    },
    {
      groupName: 'Services & Billing',
      items: [
        { id: 'services_packages', label: '4. Services and Packages', icon: Layers, roles: ['super_admin', 'staff'] },
        { id: 'quotations', label: '5. Quotations and Proposals', icon: FileText, roles: ['super_admin', 'staff'] },
        { id: 'invoices_payments', label: '6. Invoices and Payments', icon: Receipt, roles: ['super_admin', 'staff'] },
      ],
    },
    {
      groupName: 'Projects & Engineering',
      items: [
        {
          id: 'projects',
          label: user?.role === 'developer' ? '7. Assigned Projects' : '7. Projects and Milestones',
          icon: FolderGit2,
          roles: ['super_admin', 'staff', 'developer'],
        },
        { id: 'tasks', label: '9. Tasks and Deadlines', icon: CheckSquare, roles: ['super_admin', 'staff', 'developer'] },
        { id: 'team', label: '8. Developer & Staff Team', icon: UserCheck, roles: ['super_admin'] },
        {
          id: 'cybersecurity',
          label: '14. Cybersecurity & Reports',
          icon: ShieldCheck,
          roles: ['super_admin', 'staff', 'developer'],
        },
      ],
    },
    {
      groupName: 'Platform & Controls',
      items: [
        { id: 'chatbot', label: '11. AI Chatbot Settings', icon: Bot, roles: ['super_admin', 'staff'] },
        { id: 'meta', label: '12. Meta Integrations', icon: Share2, roles: ['super_admin', 'staff'] },
        { id: 'cms', label: '13. Website CMS Editor', icon: Globe2, roles: ['super_admin', 'staff'] },
        { id: 'notifications', label: '15. Email & Notification Templates', icon: Bell, roles: ['super_admin', 'staff'] },
        { id: 'analytics', label: '16. Analytics and Reports', icon: BarChart3, roles: ['super_admin', 'staff'] },
        { id: 'audit_logs', label: '17. Security Audit Logs', icon: History, roles: ['super_admin'] },
        { id: 'settings', label: '18. Roles & System Settings', icon: Sliders, roles: ['super_admin'] },
      ],
    },
  ];

  // Client role items
  const clientNavItems: NavItem[] = [
    { id: 'client_portal', label: 'Client Project Hub', icon: FolderGit2, roles: ['client'] },
  ];

  return (
    <div className="min-h-screen bg-[#080D25] text-[#F4F6FB] flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="h-16 border-b border-white/10 bg-[#060A1F]/90 backdrop-blur-md sticky top-0 z-40 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-white/70 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A1F] shadow-[0_0_10px_#FF5A1F]" />
            <span className="font-bold font-heading text-lg text-white tracking-tight">
              AI SOFT STUDIO
            </span>
            <span className="hidden sm:inline-block text-xs font-mono text-white/40 border-l border-white/10 pl-2.5">
              Business Management Platform
            </span>
          </div>
        </div>

        {/* Right Header Actions */}
        <div className="flex items-center gap-3">
          {/* Active Role Indicator */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowRoleSwitcher(!showRoleSwitcher)}
              className={`flex items-center gap-2 px-2.5 py-1 rounded-lg border text-xs font-mono ${roleInfo.color} cursor-pointer hover:opacity-90 transition-opacity`}
              title="Click to switch role view in evaluation"
            >
              <RoleIcon className="w-3.5 h-3.5" />
              <span>{roleInfo.label}</span>
              <Sliders className="w-3 h-3 opacity-60 ml-0.5" />
            </button>

            {showRoleSwitcher && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#0a0f2e] border border-white/15 p-2 shadow-2xl z-50 text-xs">
                <div className="px-2.5 py-1.5 text-[10px] font-mono text-white/40 uppercase">
                  Internal Role View
                </div>
                {(['super_admin', 'staff', 'developer', 'client'] as UserRole[]).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => {
                      quickSwitchRole(r);
                      setShowRoleSwitcher(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between transition-colors ${
                      user?.role === r ? 'bg-[#FF5A1F]/20 text-[#FF5A1F] font-bold' : 'text-white/70 hover:bg-white/5'
                    }`}
                  >
                    <span className="capitalize">{r.replace('_', ' ')}</span>
                    {user?.role === r && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* User Name */}
          <div className="hidden md:block text-right">
            <div className="text-xs font-semibold text-white">{user?.name}</div>
            <div className="text-[10px] text-white/40 font-mono">{user?.email}</div>
          </div>

          {/* Back to Public Website */}
          <button
            type="button"
            onClick={onBackToPublic}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-white/80 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Public Site</span>
          </button>

          {/* Logout */}
          <button
            type="button"
            onClick={logout}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-white/60 hover:text-red-400 transition-colors cursor-pointer"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Layout Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="w-64 border-r border-white/10 bg-[#060A1F]/60 backdrop-blur-md hidden md:flex flex-col justify-between p-3.5 shrink-0 overflow-y-auto">
          <nav className="space-y-4">
            {user?.role === 'client' ? (
              <div className="space-y-1">
                <div className="px-3 py-1 text-[10px] font-mono text-white/40 uppercase tracking-wider">
                  Client Portal
                </div>
                {clientNavItems.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onTabChange(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                      activeTab === item.id
                        ? 'bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white shadow-lg shadow-[#FF5A1F]/25 font-semibold'
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <item.icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            ) : (
              navGroups.map((group) => {
                const groupVisibleItems = group.items.filter((item) =>
                  user ? item.roles.includes(user.role) : false
                );
                if (groupVisibleItems.length === 0) return null;

                return (
                  <div key={group.groupName} className="space-y-1">
                    <div className="px-3 py-1 text-[10px] font-mono text-[#FF5A1F]/80 uppercase tracking-wider font-semibold">
                      {group.groupName}
                    </div>
                    {groupVisibleItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => onTabChange(item.id)}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                            isActive
                              ? 'bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white shadow-lg shadow-[#FF5A1F]/25 font-semibold'
                              : 'text-white/60 hover:text-white hover:bg-white/5'
                          }`}
                        >
                          <Icon className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                );
              })
            )}
          </nav>

          {/* System State Indicator */}
          <div className="pt-4 border-t border-white/10 mt-4 p-3 rounded-xl bg-white/[0.02] text-[11px] font-mono">
            <div className="text-white/40 mb-1">SYSTEM STATE</div>
            <div className="flex items-center gap-2 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Production Live</span>
            </div>
            <div className="text-[10px] text-white/40 mt-1">Zero-Trust RBAC Active</div>
          </div>
        </aside>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-[#080D25]/95 backdrop-blur-xl p-6 flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
                <span className="font-bold font-heading text-white">Platform Navigation</span>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 text-white/70"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                {navGroups.map((group) => {
                  const items = group.items.filter((item) => (user ? item.roles.includes(user.role) : false));
                  if (items.length === 0) return null;
                  return (
                    <div key={group.groupName} className="space-y-1">
                      <div className="text-[10px] font-mono text-[#FF5A1F] uppercase font-bold px-2">
                        {group.groupName}
                      </div>
                      {items.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            onTabChange(item.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs ${
                            activeTab === item.id ? 'bg-[#FF5A1F] text-white' : 'text-white/70'
                          }`}
                        >
                          <item.icon className="w-4 h-4" />
                          <span>{item.label}</span>
                        </button>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onBackToPublic();
              }}
              className="w-full mt-6 py-3 rounded-xl bg-white/10 text-white text-center text-xs font-mono"
            >
              Back to Public Website
            </button>
          </div>
        )}

        {/* Dynamic Main Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#080D25]">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
};
