import React, { useState } from 'react';
import {
  Lock,
  Mail,
  Shield,
  ArrowRight,
  X,
  RefreshCw,
  Key,
  Info,
  HelpCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showResetHelp, setShowResetHelp] = useState(false);
  const [showCredentialsHelper, setShowCredentialsHelper] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setLoading(true);
    setError(null);

    const res = await login(email.trim(), password);
    setLoading(false);

    if (res.success) {
      onSuccess();
    } else {
      setError(res.error || 'Authentication failed. Please verify internal credentials.');
    }
  };

  const autofillCredentials = (testEmail: string, testPass: string) => {
    setEmail(testEmail);
    setPassword(testPass);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-2xl bg-[#080D25] border border-white/20 p-6 sm:p-8 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-[#FF5A1F]/30">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold font-heading text-white">
            Authorized Team Access
          </h2>
          <p className="text-xs text-white/60 mt-1">
            Secure login for AI SOFT STUDIO management and engineering staff
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs text-center font-mono">
            {error}
          </div>
        )}

        {/* Credentials Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-[11px] font-mono text-white/60 mb-1">
              Authorized Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="staff@aisoft.studio"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF5A1F]"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-[11px] font-mono text-white/60">
                Password
              </label>
              <button
                type="button"
                onClick={() => setShowResetHelp(!showResetHelp)}
                className="text-[10px] text-[#FF5A1F] hover:underline cursor-pointer"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Key className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••••••"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono focus:outline-none focus:border-[#FF5A1F]"
              />
            </div>
          </div>

          {showResetHelp && (
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-white/70 text-[11px] leading-relaxed">
              <span className="font-semibold text-white">Password Recovery Policy:</span>{' '}
              For zero-trust security compliance, employee and staff password resets must be issued by the Super Admin in the System Settings panel. Contact your studio administrator.
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white font-semibold text-xs shadow-lg shadow-[#FF5A1F]/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 transition-all hover:brightness-110 active:scale-[0.99]"
          >
            {loading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Shield className="w-4 h-4" />
                <span>Verify Credentials & Enter Workspace</span>
              </>
            )}
          </button>
        </form>

        {/* Confidential Notice & Developer Audit Reference */}
        <div className="pt-3 border-t border-white/10">
          <div className="flex items-center justify-between text-[10px] font-mono text-white/40">
            <span>Server-enforced role authorization</span>
            <button
              type="button"
              onClick={() => setShowCredentialsHelper(!showCredentialsHelper)}
              className="text-white/50 hover:text-white inline-flex items-center gap-1 cursor-pointer"
            >
              <HelpCircle className="w-3 h-3" />
              <span>Audit Accounts</span>
            </button>
          </div>

          {showCredentialsHelper && (
            <div className="mt-3 p-3 rounded-xl bg-white/[0.03] border border-white/10 space-y-2 text-[11px] font-mono text-white/70">
              <div className="text-[10px] text-white/40 uppercase">Pre-Configured System Accounts:</div>
              <div
                onClick={() => autofillCredentials('admin@aisoft.studio', 'StudioAdmin2026!')}
                className="p-1.5 rounded bg-white/5 hover:bg-white/10 cursor-pointer flex justify-between items-center transition-colors"
              >
                <span>admin@aisoft.studio (Super Admin)</span>
                <span className="text-[10px] text-[#FF5A1F]">Fill</span>
              </div>
              <div
                onClick={() => autofillCredentials('staff@aisoft.studio', 'Staff2026!')}
                className="p-1.5 rounded bg-white/5 hover:bg-white/10 cursor-pointer flex justify-between items-center transition-colors"
              >
                <span>staff@aisoft.studio (Staff / Ops)</span>
                <span className="text-[10px] text-[#244BFF]">Fill</span>
              </div>
              <div
                onClick={() => autofillCredentials('dev@aisoft.studio', 'Developer2026!')}
                className="p-1.5 rounded bg-white/5 hover:bg-white/10 cursor-pointer flex justify-between items-center transition-colors"
              >
                <span>dev@aisoft.studio (Lead Engineer)</span>
                <span className="text-[10px] text-emerald-400">Fill</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
