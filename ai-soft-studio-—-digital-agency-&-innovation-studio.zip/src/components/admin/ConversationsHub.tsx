import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  User,
  Bot,
  RefreshCw,
  Search,
  CheckCircle2,
  Clock,
  ArrowRight,
  Shield,
  Smartphone,
  Mail,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { ConversationThread } from '../../server/db/types';

export const ConversationsHub: React.FC = () => {
  const { token, user } = useAuth();
  const [threads, setThreads] = useState<ConversationThread[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedThread, setSelectedThread] = useState<ConversationThread | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);

  const fetchThreads = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/conversations', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setThreads(data.threads || []);
        if (selectedThread) {
          const updated = (data.threads || []).find((t: ConversationThread) => t.id === selectedThread.id);
          if (updated) setSelectedThread(updated);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchThreads();
  }, [token]);

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedThread || !replyText.trim()) return;

    setSending(true);
    try {
      const res = await fetch(`/api/conversations/${selectedThread.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ text: replyText }),
      });

      if (res.ok) {
        const data = await res.json();
        setSelectedThread(data.thread);
        setReplyText('');
        fetchThreads();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  const getChannelBadge = (ch: ConversationThread['channel']) => {
    switch (ch) {
      case 'meta_whatsapp':
        return { label: 'WhatsApp', icon: Smartphone, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' };
      case 'meta_messenger':
        return { label: 'Messenger', icon: MessageSquare, color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' };
      case 'email':
        return { label: 'Email', icon: Mail, color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' };
      default:
        return { label: 'Web Chat', icon: MessageSquare, color: 'text-[#FF5A1F] bg-[#FF5A1F]/10 border-[#FF5A1F]/20' };
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <MessageSquare className="w-7 h-7 text-[#244BFF]" />
            <span>Customer Conversations</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Omni-channel inbox unifying website chat, Meta WhatsApp, Messenger, and customer emails.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchThreads}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Inbox</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[500px]">
        {/* Left: Threads List */}
        <div className="lg:col-span-5 glass-surface rounded-2xl border border-white/10 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-white/10 font-mono text-xs text-white/50 flex justify-between items-center">
            <span>Conversations ({threads.length})</span>
            <span className="text-[10px] text-white/30">Auto-routed via CRM</span>
          </div>

          <div className="divide-y divide-white/5 overflow-y-auto flex-1">
            {threads.length === 0 ? (
              <div className="p-8 text-center text-xs text-white/40 space-y-2">
                <MessageSquare className="w-8 h-8 text-white/20 mx-auto" />
                <p>No active customer conversation threads.</p>
                <p className="text-[11px] text-white/30">
                  When visitors message through the website chat widget or Meta channels, threads appear here.
                </p>
              </div>
            ) : (
              threads.map((t) => {
                const badge = getChannelBadge(t.channel);
                const isSelected = selectedThread?.id === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => setSelectedThread(t)}
                    className={`p-4 transition-colors cursor-pointer ${
                      isSelected ? 'bg-white/[0.08]' : 'hover:bg-white/[0.03]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-semibold text-white text-xs">{t.customerName}</span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${badge.color}`}>
                        {badge.label}
                      </span>
                    </div>

                    <div className="text-[11px] text-white/60 truncate font-mono">
                      {t.messages.length > 0 ? t.messages[t.messages.length - 1].text : 'No messages'}
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-white/40">
                      <span>{t.customerContact}</span>
                      <span>{new Date(t.lastActivity).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Message Stream & Reply Composer */}
        <div className="lg:col-span-7 glass-surface rounded-2xl border border-white/10 flex flex-col overflow-hidden">
          {selectedThread ? (
            <>
              {/* Thread Header */}
              <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/[0.02]">
                <div>
                  <h3 className="font-bold text-white text-sm">{selectedThread.customerName}</h3>
                  <div className="text-[11px] font-mono text-white/50">{selectedThread.customerContact}</div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono px-2.5 py-1 rounded-full border ${
                      selectedThread.status === 'resolved'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    Status: {selectedThread.status}
                  </span>
                </div>
              </div>

              {/* Message List */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4 max-h-[380px]">
                {selectedThread.messages.map((m) => {
                  const isStaff = m.sender === 'staff';
                  const isBot = m.sender === 'ai_bot';
                  return (
                    <div
                      key={m.id}
                      className={`flex flex-col ${isStaff ? 'items-end' : 'items-start'}`}
                    >
                      <div className="flex items-center gap-1.5 mb-1 text-[10px] font-mono text-white/40">
                        {isBot ? <Bot className="w-3 h-3 text-[#FF5A1F]" /> : <User className="w-3 h-3" />}
                        <span>{m.senderName}</span>
                        <span>·</span>
                        <span>{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <div
                        className={`p-3.5 rounded-2xl max-w-md text-xs leading-relaxed ${
                          isStaff
                            ? 'bg-[#244BFF] text-white rounded-br-none shadow-md'
                            : isBot
                            ? 'bg-white/10 text-white/90 border border-white/10 rounded-bl-none font-mono text-[11px]'
                            : 'bg-white/[0.06] text-white/90 border border-white/10 rounded-bl-none'
                        }`}
                      >
                        {m.text}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Reply Form */}
              <form onSubmit={handleSendReply} className="p-4 border-t border-white/10 bg-white/[0.02] flex gap-2">
                <input
                  type="text"
                  required
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={`Reply directly to ${selectedThread.customerName}...`}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-[#244BFF]"
                />
                <button
                  type="submit"
                  disabled={sending}
                  className="px-5 py-2.5 rounded-xl bg-[#244BFF] hover:bg-blue-600 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {sending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>Reply</span>
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-white/40 text-xs">
              <MessageSquare className="w-10 h-10 text-white/20 mb-3" />
              <p>Select a conversation from the left to inspect messages and reply.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
