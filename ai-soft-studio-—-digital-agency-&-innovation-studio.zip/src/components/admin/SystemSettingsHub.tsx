import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Shield,
  Key,
  Database,
  CheckCircle2,
  AlertTriangle,
  Lock,
  RefreshCw,
  Server,
  FileText
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const SystemSettingsHub: React.FC = () => {
  const { token, user } = useAuth();
  const [razorpayStatus, setRazorpayStatus] = useState<any>(null);
  const [metaStatus, setMetaStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [rRes, mRes] = await Promise.all([
        fetch('/api/finance/razorpay/status', { headers }),
        fetch('/api/meta/status', { headers }),
      ]);
      if (rRes.ok) {
        const d = await rRes.json();
        setRazorpayStatus(d);
      }
      if (mRes.ok) {
        const d = await mRes.json();
        setMetaStatus(d.status);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, [token]);

  const ROLES_MATRIX = [
    {
      role: 'Super Admin',
      description: 'Complete operational and architectural control across all 18 modules, settings, and team accounts.',
      badge: 'bg-[#FF5A1F]/20 text-[#FF5A1F] border-[#FF5A1F]/30',
      permissions: [
        'User and Staff Account Provisioning',
        'System Secret & API Key Configuration',
        'Payment Gateway & Webhook Verification',
        'Full Audit Log & IP Inspector Access',
        'Website CMS & Announcement Publishing',
        'Cybersecurity Scope & Authorization Oversight',
      ],
    },
    {
      role: 'Staff / Operations',
      description: 'Client relationship management, quotation preparation, and lead follow-up execution.',
      badge: 'bg-[#244BFF]/20 text-[#244BFF] border-[#244BFF]/30',
      permissions: [
        'Inquiry CRM Pipeline & Status Routing',
        'Proposal & Quotation Generation',
        'Invoice Creation & Payment Receipt Logging',
        'Omni-Channel Customer Conversations',
        'Project Milestone Status Tracking',
      ],
    },
    {
      role: 'Engineer / Developer',
      description: 'Technical sprint execution, task progress logging, and deliverable commitments.',
      badge: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      permissions: [
        'Assigned Project Workspace Access',
        'Task Status Updates (To Do → Done)',
        'Progress Notes & Commit Reference Logging',
        'Deliverable File & Staging URL Submissions',
        'Vulnerability Findings Logging (Security)',
      ],
    },
    {
      role: 'Client (Restricted)',
      description: 'Isolated read and approval access strictly scoped to own project assets.',
      badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      permissions: [
        'Own Project Milestones & Progress Review',
        'Download Approved Deliverable Assets',
        'Quotation Review & Acceptance',
        'Invoice Review & Razorpay Online Payment',
      ],
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <Sliders className="w-7 h-7 text-[#244BFF]" />
            <span>Roles, Permissions & System Settings</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Zero-trust security policy matrix, integration checklist, and persistent database health monitors.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchStatus}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Checklist</span>
        </button>
      </div>

      {/* Integration Credentials Checklist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Razorpay Gateway Status */}
        <div className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Key className="w-5 h-5 text-emerald-400" />
              <h2 className="text-sm font-bold text-white">Razorpay Payment Gateway</h2>
            </div>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                razorpayStatus?.isConfigured
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
              }`}
            >
              {razorpayStatus?.isConfigured ? 'Keys Configured' : 'Awaiting Environment Keys'}
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            {razorpayStatus?.checklist?.map((item: any) => (
              <div key={item.step} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-start gap-2.5">
                <CheckCircle2
                  className={`w-4 h-4 shrink-0 mt-0.5 ${
                    item.completed ? 'text-emerald-400' : 'text-white/20'
                  }`}
                />
                <div>
                  <div className="text-white font-semibold">{item.title}</div>
                  <div className="text-white/50 text-[11px] font-sans mt-0.5">{item.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Meta Integration Status */}
        <div className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Server className="w-5 h-5 text-[#244BFF]" />
              <h2 className="text-sm font-bold text-white">Meta Developer Platform</h2>
            </div>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                metaStatus?.isVerified
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  : 'bg-white/10 text-white/50 border-white/20'
              }`}
            >
              {metaStatus?.isVerified ? 'Verified Active' : 'Webhook Listener Ready'}
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex justify-between items-center">
              <span className="text-white/50">Webhook Endpoint:</span>
              <span className="text-[#FF5A1F]">{metaStatus?.webhookEndpoint || '/api/webhooks/meta'}</span>
            </div>
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex justify-between items-center">
              <span className="text-white/50">Verify Token:</span>
              <span className="text-white/80">{metaStatus?.webhookVerifyToken || 'aisoft_meta_verify_2026'}</span>
            </div>
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex justify-between items-center">
              <span className="text-white/50">Page Access Token:</span>
              <span className="text-white/80">{metaStatus?.hasPageAccessToken ? 'Present' : 'Not configured'}</span>
            </div>
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex justify-between items-center">
              <span className="text-white/50">WhatsApp Phone ID:</span>
              <span className="text-white/80">{metaStatus?.whatsappPhoneNumberId || 'Not configured'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Role-Based Permissions Matrix */}
      <div className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-[#FF5A1F]" />
          <h2 className="text-base font-bold text-white">Role-Based Access Control (RBAC) Matrix</h2>
        </div>
        <p className="text-xs text-white/60">
          Authorization boundaries are enforced strictly on server route middleware. Changing client-side state never bypasses server checks.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          {ROLES_MATRIX.map((item) => (
            <div key={item.role} className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{item.role}</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${item.badge}`}>
                  Role
                </span>
              </div>

              <p className="text-[11px] text-white/60 leading-relaxed min-h-[40px]">
                {item.description}
              </p>

              <div className="pt-2 border-t border-white/5 space-y-1.5">
                <span className="text-[10px] font-mono text-white/40 uppercase block">Permitted Scope:</span>
                {item.permissions.map((p, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-[11px] text-white/70">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                    <span>{p}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Backup and Data Storage Info */}
      <div className="glass-surface p-6 rounded-2xl border border-white/10 flex items-start gap-4 text-xs leading-relaxed">
        <Database className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-white text-sm mb-1">Backup & Disaster Recovery Procedures</h3>
          <p className="text-white/70">
            Studio data (Inquiries, Projects, Invoices, Verified Payments, Security Assessments, and Audit Logs) is persisted atomically in the server database layer.
            For production deployment, automate periodic snapshots of the data volume and keep <code className="text-[#FF5A1F]">SESSION_SECRET</code>, <code className="text-[#FF5A1F]">RAZORPAY_KEY_SECRET</code>, and <code className="text-[#FF5A1F]">META_APP_SECRET</code> in environment secret managers.
          </p>
        </div>
      </div>
    </div>
  );
};
