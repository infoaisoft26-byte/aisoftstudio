import React, { useState, useEffect } from 'react';
import {
  Receipt,
  DollarSign,
  Plus,
  CheckCircle2,
  Clock,
  CreditCard,
  FileText,
  ShieldCheck,
  RefreshCw,
  Printer,
  X,
  AlertTriangle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Quotation, Invoice, Payment, ServicePackage } from '../../server/db/types';

interface FinanceHubProps {
  initialSubTab?: 'quotations' | 'invoices' | 'payments' | 'packages';
}

export const FinanceHub: React.FC<FinanceHubProps> = ({ initialSubTab = 'quotations' }) => {
  const { token, user } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'quotations' | 'invoices' | 'payments' | 'packages'>(initialSubTab);

  useEffect(() => {
    if (initialSubTab) {
      setActiveSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [packages, setPackages] = useState<ServicePackage[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // New Quotation Modal
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [quoteClientEmail, setQuoteClientEmail] = useState('');
  const [quoteClientName, setQuoteClientName] = useState('');
  const [quoteItems, setQuoteItems] = useState([
    { description: 'Core Platform Architecture & UI', quantity: 1, unitPrice: 3500 },
    { description: 'AI Pipeline & Workflow Integration', quantity: 1, unitPrice: 2000 },
  ]);
  const [quoteTaxRate, setQuoteTaxRate] = useState('0');
  const [submittingQuote, setSubmittingQuote] = useState(false);

  // Verify Payment Modal
  const [showPayModal, setShowPayModal] = useState(false);
  const [selectedInvoiceForPay, setSelectedInvoiceForPay] = useState<Invoice | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<'stripe' | 'bank_transfer' | 'manual'>('bank_transfer');
  const [payRef, setPayRef] = useState('');
  const [submittingPay, setSubmittingPay] = useState(false);

  const fetchFinanceData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [qRes, iRes, pRes, pkgRes] = await Promise.all([
        fetch('/api/finance/quotations', { headers }),
        fetch('/api/finance/invoices', { headers }),
        fetch('/api/finance/payments', { headers }),
        fetch('/api/finance/services', { headers }),
      ]);

      if (qRes.ok) {
        const d = await qRes.json();
        setQuotations(d.quotations || []);
      }
      if (iRes.ok) {
        const d = await iRes.json();
        setInvoices(d.invoices || []);
      }
      if (pRes.ok) {
        const d = await pRes.json();
        setPayments(d.payments || []);
      }
      if (pkgRes.ok) {
        const d = await pkgRes.json();
        setPackages(d.packages || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFinanceData();
  }, [token]);

  const handleCreateQuotation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quoteClientEmail || quoteItems.length === 0) return;

    setSubmittingQuote(true);
    try {
      const res = await fetch('/api/finance/quotations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          clientEmail: quoteClientEmail,
          clientName: quoteClientName || 'Client',
          items: quoteItems,
          taxRate: quoteTaxRate,
        }),
      });

      if (res.ok) {
        setShowQuoteModal(false);
        fetchFinanceData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingQuote(false);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoiceForPay || !payAmount || !payRef.trim()) return;

    setSubmittingPay(true);
    try {
      const res = await fetch('/api/finance/payments/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          invoiceId: selectedInvoiceForPay.id,
          amount: payAmount,
          method: payMethod,
          transactionReference: payRef.trim(),
        }),
      });

      if (res.ok) {
        setShowPayModal(false);
        setSelectedInvoiceForPay(null);
        setPayAmount('');
        setPayRef('');
        fetchFinanceData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingPay(false);
    }
  };

  const isStaffOrAdmin = user?.role === 'super_admin' || user?.role === 'staff';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight">
            Finances, Quotations & Billing
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Verified client invoicing, advance payments, service packages, and transaction ledger.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isStaffOrAdmin && (
            <button
              type="button"
              onClick={() => setShowQuoteModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Quotation</span>
            </button>
          )}

          <button
            type="button"
            onClick={fetchFinanceData}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#FF5A1F]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-1 border-b border-white/10 pb-2 overflow-x-auto text-xs font-mono">
        <button
          type="button"
          onClick={() => setActiveSubTab('quotations')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeSubTab === 'quotations'
              ? 'bg-[#FF5A1F] text-white font-bold'
              : 'text-white/60 hover:text-white'
          }`}
        >
          Quotations ({quotations.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('invoices')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeSubTab === 'invoices'
              ? 'bg-[#FF5A1F] text-white font-bold'
              : 'text-white/60 hover:text-white'
          }`}
        >
          Invoices ({invoices.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('payments')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeSubTab === 'payments'
              ? 'bg-[#FF5A1F] text-white font-bold'
              : 'text-white/60 hover:text-white'
          }`}
        >
          Verified Payments ({payments.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('packages')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeSubTab === 'packages'
              ? 'bg-[#FF5A1F] text-white font-bold'
              : 'text-white/60 hover:text-white'
          }`}
        >
          Official Service Packages ({packages.length})
        </button>
      </div>

      {/* Payment Security Notice */}
      <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 flex items-center justify-between text-xs font-mono text-white/60">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Payment Security Protocol: All transactions verified via cryptographic server webhooks & authorized references.</span>
        </div>
        <span className="text-[10px] text-white/40">Zero card secrets stored in browser</span>
      </div>

      {/* Tab 1: Quotations */}
      {activeSubTab === 'quotations' && (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
          {quotations.length === 0 ? (
            <div className="p-12 text-center text-xs font-mono text-white/40">
              No quotations generated yet. Create an itemized quotation above.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                  <tr>
                    <th className="p-4">Quotation Ref</th>
                    <th className="p-4">Client</th>
                    <th className="p-4">Line Items</th>
                    <th className="p-4">Total Amount</th>
                    <th className="p-4">Valid Until</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {quotations.map((q) => (
                    <tr key={q.id} className="hover:bg-white/[0.02]">
                      <td className="p-4 font-mono text-[#FF5A1F] font-bold">{q.id}</td>
                      <td className="p-4">
                        <div className="font-semibold text-white">{q.clientName}</div>
                        <div className="text-[11px] font-mono text-white/40">{q.clientEmail}</div>
                      </td>
                      <td className="p-4">
                        <div className="text-white/80">{q.items.length} item(s)</div>
                        <div className="text-[10px] text-white/40 font-mono">
                          {q.items.map((it) => it.description).slice(0, 2).join(', ')}
                        </div>
                      </td>
                      <td className="p-4 font-mono font-bold text-white">${q.total.toLocaleString()}</td>
                      <td className="p-4 font-mono text-white/50">{q.validUntil}</td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                            q.status === 'Accepted'
                              ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                              : q.status === 'Sent'
                              ? 'bg-[#244BFF]/15 text-[#244BFF] border-[#244BFF]/30'
                              : 'bg-white/10 text-white/70 border-white/15'
                          }`}
                        >
                          {q.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Invoices */}
      {activeSubTab === 'invoices' && (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
          {invoices.length === 0 ? (
            <div className="p-12 text-center text-xs font-mono text-white/40">
              No invoices generated yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                  <tr>
                    <th className="p-4">Invoice ID</th>
                    <th className="p-4">Client</th>
                    <th className="p-4">Total</th>
                    <th className="p-4">Amount Paid</th>
                    <th className="p-4">Balance Due</th>
                    <th className="p-4">Due Date</th>
                    <th className="p-4">Status</th>
                    {isStaffOrAdmin && <th className="p-4 text-right">Action</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {invoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-white/[0.02]">
                      <td className="p-4 font-mono text-[#FF5A1F] font-bold">{inv.id}</td>
                      <td className="p-4 font-semibold text-white">{inv.clientName}</td>
                      <td className="p-4 font-mono text-white font-bold">${inv.total.toLocaleString()}</td>
                      <td className="p-4 font-mono text-emerald-400">${inv.amountPaid.toLocaleString()}</td>
                      <td className="p-4 font-mono text-amber-400 font-bold">${inv.balanceDue.toLocaleString()}</td>
                      <td className="p-4 font-mono text-white/50">{inv.dueDate}</td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                            inv.status === 'Paid'
                              ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                              : inv.status === 'Partially Paid'
                              ? 'bg-[#244BFF]/15 text-[#244BFF] border-[#244BFF]/30'
                              : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                      {isStaffOrAdmin && (
                        <td className="p-4 text-right">
                          {inv.balanceDue > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedInvoiceForPay(inv);
                                setPayAmount(String(inv.balanceDue));
                                setShowPayModal(true);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 text-xs font-mono"
                            >
                              Verify Payment
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Verified Payments */}
      {activeSubTab === 'payments' && (
        <div className="glass-surface rounded-2xl border border-white/10 overflow-hidden">
          {payments.length === 0 ? (
            <div className="p-12 text-center text-xs font-mono text-white/40">
              No payments recorded yet. Unverified payments are never marked as successful.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.02] border-b border-white/10 text-white/50 font-mono text-[11px]">
                  <tr>
                    <th className="p-4">Payment Ref</th>
                    <th className="p-4">Invoice ID</th>
                    <th className="p-4">Amount</th>
                    <th className="p-4">Method</th>
                    <th className="p-4">Transaction Reference</th>
                    <th className="p-4">Verified At</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {payments.map((p) => (
                    <tr key={p.id} className="hover:bg-white/[0.02]">
                      <td className="p-4 font-mono text-[#FF5A1F] font-bold">{p.id}</td>
                      <td className="p-4 font-mono text-white/70">{p.invoiceId}</td>
                      <td className="p-4 font-mono text-emerald-400 font-bold">${p.amount.toLocaleString()}</td>
                      <td className="p-4 capitalize font-mono text-white/60">{p.method.replace('_', ' ')}</td>
                      <td className="p-4 font-mono text-white/80">{p.transactionReference}</td>
                      <td className="p-4 font-mono text-white/50">{new Date(p.verifiedAt || p.createdAt).toLocaleString()}</td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Service Packages */}
      {activeSubTab === 'packages' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {packages.map((pkg) => (
            <div key={pkg.id} className="glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-[#FF5A1F] uppercase">{pkg.category}</span>
                <span className="text-xl font-bold font-mono text-white">from ${pkg.startingPrice}</span>
              </div>
              <h3 className="text-lg font-bold font-heading text-white">{pkg.title}</h3>
              <p className="text-xs text-white/70">{pkg.description}</p>
              <div className="pt-2 border-t border-white/5">
                <div className="text-[11px] font-mono text-white/40 mb-2">Included Deliverables:</div>
                <ul className="space-y-1.5 text-xs text-white/80">
                  {pkg.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="text-[#FF5A1F]">·</span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Quotation Modal */}
      {showQuoteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="max-w-lg w-full p-6 rounded-2xl bg-[#080D25] border border-white/20 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold font-heading text-white">Generate Custom Quotation</h3>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Client Work Email *</label>
              <input
                type="email"
                required
                value={quoteClientEmail}
                onChange={(e) => setQuoteClientEmail(e.target.value)}
                placeholder="client@company.com"
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Client Name</label>
              <input
                type="text"
                value={quoteClientName}
                onChange={(e) => setQuoteClientName(e.target.value)}
                placeholder="e.g. Elena Rostova"
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs"
              />
            </div>

            {/* Line items preview */}
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-xs font-mono space-y-2">
              <span className="text-white/40 text-[10px]">Line Items (Configured)</span>
              {quoteItems.map((it, idx) => (
                <div key={idx} className="flex justify-between text-white/80">
                  <span>{it.description}</span>
                  <span>${it.unitPrice}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowQuoteModal(false)}
                className="px-4 py-2 rounded-lg bg-white/5 text-white/70 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={submittingQuote || !quoteClientEmail.trim()}
                onClick={handleCreateQuotation}
                className="px-4 py-2 rounded-lg bg-[#FF5A1F] text-white font-semibold text-xs"
              >
                {submittingQuote ? 'Creating...' : 'Issue Quotation'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Verify Payment Modal */}
      {showPayModal && selectedInvoiceForPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="max-w-md w-full p-6 rounded-2xl bg-[#080D25] border border-white/20 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold font-heading text-white">Record & Verify Payment</h3>
            <p className="text-xs text-white/60">
              Recording payment for invoice <span className="text-[#FF5A1F]">{selectedInvoiceForPay.id}</span> ({selectedInvoiceForPay.clientName}).
            </p>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Amount ($ USD) *</label>
              <input
                type="number"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Payment Method</label>
              <select
                value={payMethod}
                onChange={(e: any) => setPayMethod(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#080D25] border border-white/10 text-white text-xs"
              >
                <option value="bank_transfer">Wire / Bank Transfer</option>
                <option value="stripe">Stripe Webhook Verified</option>
                <option value="manual">Manual Studio Deposit</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1">Transaction Reference / Hash *</label>
              <input
                type="text"
                required
                value={payRef}
                onChange={(e) => setPayRef(e.target.value)}
                placeholder="e.g. TXN-WIRE-982341 or ch_3N..."
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-xs font-mono"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPayModal(false)}
                className="px-4 py-2 rounded-lg bg-white/5 text-white/70 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={submittingPay || !payAmount || !payRef.trim()}
                onClick={handleRecordPayment}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-xs font-mono"
              >
                {submittingPay ? 'Verifying...' : 'Confirm Verified Payment'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
