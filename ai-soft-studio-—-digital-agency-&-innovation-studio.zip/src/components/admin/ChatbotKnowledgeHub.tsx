import React, { useState } from 'react';
import {
  Bot,
  Sparkles,
  Save,
  CheckCircle2,
  Key,
  ShieldAlert,
  Send,
  HelpCircle,
  Sliders,
  AlertTriangle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const ChatbotKnowledgeHub: React.FC = () => {
  const { token } = useAuth();
  const [systemInstructions, setSystemInstructions] = useState(
    `You are the AI SOFT STUDIO technical assistant. Answer accurately based strictly on our core service offerings: Website Development, AI Automation, E-commerce Solutions, Custom Admin Panels, and Lawful Cybersecurity & Hardening Reviews.
Key Policies:
1. All client cybersecurity reviews require explicit, written authorization from verified system owners.
2. Direct interested prospects to submit a brief via the project inquiry form.
3. For questions regarding customized enterprise architecture or pricing, invite the visitor to leave their email or phone number for senior staff follow-up.`
  );

  const [escalationTriggers, setEscalationTriggers] = useState(
    'budget > $20k, custom quote, emergency outage, talk to human, security incident'
  );

  const [testInput, setTestInput] = useState('');
  const [testOutput, setTestOutput] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleRunSimulation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testInput.trim()) return;

    setTesting(true);
    setTestOutput(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: testInput }),
      });
      const data = await res.json();
      setTestOutput(data.reply || data.response || 'Assistant responded.');
    } catch (err: any) {
      setTestOutput(`[Simulation Notice]: ${err.message}`);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <Bot className="w-7 h-7 text-[#FF5A1F]" />
            <span>AI Chatbot Knowledge & Settings</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Configure system knowledge boundaries, escalation logic, and AI response policies.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings saved successfully</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Knowledge Configuration */}
        <div className="lg:col-span-7 space-y-6">
          <form onSubmit={handleSaveSettings} className="glass-surface p-6 rounded-2xl border border-white/10 space-y-5">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#FF5A1F]" />
              <span>Core Knowledge & System Persona</span>
            </h2>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1.5">
                System Instructions & Domain Knowledge
              </label>
              <textarea
                rows={7}
                value={systemInstructions}
                onChange={(e) => setSystemInstructions(e.target.value)}
                className="w-full p-3 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white leading-relaxed font-mono focus:outline-none focus:border-[#FF5A1F]"
              />
              <p className="text-[11px] text-white/40 mt-1">
                The chatbot uses these instructions to guide visitors, answer FAQs, and maintain strict anti-hallucination discipline.
              </p>
            </div>

            <div>
              <label className="block text-xs font-mono text-white/60 mb-1.5">
                Human Staff Escalation Keywords (comma-separated)
              </label>
              <input
                type="text"
                value={escalationTriggers}
                onChange={(e) => setEscalationTriggers(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-[#FF5A1F]"
              />
              <p className="text-[11px] text-white/40 mt-1">
                Triggers automatic handoff to staff in the Customer Conversations tab.
              </p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] text-white text-xs font-semibold shadow-lg shadow-[#FF5A1F]/20 cursor-pointer hover:brightness-110"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Knowledge Base</span>
              </button>
            </div>
          </form>

          {/* Model Status Card */}
          <div className="glass-surface p-5 rounded-2xl border border-white/10 flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="font-semibold text-white">Gemini 2.5 Engine Active</div>
                <div className="text-[11px] text-white/50 font-mono">Server-side proxy routing with fallback handlers</div>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-mono text-[11px]">
              Ready
            </span>
          </div>
        </div>

        {/* Right: Interactive Simulator */}
        <div className="lg:col-span-5 glass-surface p-6 rounded-2xl border border-white/10 space-y-4 flex flex-col justify-between">
          <div>
            <div className="text-xs font-mono text-[#244BFF] uppercase tracking-wider mb-1">
              Sandbox Testing
            </div>
            <h2 className="text-sm font-semibold text-white">
              Simulate Chatbot Response
            </h2>
            <p className="text-xs text-white/50 mt-0.5 mb-4">
              Send test questions to evaluate response tone and knowledge boundaries before prospective clients interact.
            </p>

            {testOutput && (
              <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10 text-xs space-y-2 mb-4 animate-in fade-in duration-150">
                <div className="font-mono text-[#FF5A1F] text-[10px] uppercase font-bold">Simulator Output:</div>
                <p className="text-white/90 leading-relaxed whitespace-pre-wrap">{testOutput}</p>
              </div>
            )}
          </div>

          <form onSubmit={handleRunSimulation} className="space-y-3">
            <textarea
              rows={3}
              required
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder="e.g. Can you conduct an unauthorized security assessment on a competitor's website?"
              className="w-full p-3 rounded-xl bg-white/[0.03] border border-white/10 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-[#244BFF]"
            />
            <button
              type="submit"
              disabled={testing}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#244BFF] hover:bg-blue-600 text-white font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{testing ? 'Evaluating...' : 'Run Simulation'}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
