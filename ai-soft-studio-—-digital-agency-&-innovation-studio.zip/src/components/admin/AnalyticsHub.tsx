import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  TrendingUp,
  Receipt,
  FolderGit2,
  Inbox,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Inquiry, Project, Invoice, Payment } from '../../server/db/types';

export const AnalyticsHub: React.FC = () => {
  const { token } = useAuth();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [inqRes, prjRes, invRes, payRes] = await Promise.all([
        fetch('/api/inquiries', { headers }),
        fetch('/api/projects', { headers }),
        fetch('/api/finance/invoices', { headers }),
        fetch('/api/finance/payments', { headers }),
      ]);

      if (inqRes.ok) {
        const d = await inqRes.json();
        setInquiries(d.inquiries || []);
      }
      if (prjRes.ok) {
        const d = await prjRes.json();
        setProjects(d.projects || []);
      }
      if (invRes.ok) {
        const d = await invRes.json();
        setInvoices(d.invoices || []);
      }
      if (payRes.ok) {
        const d = await payRes.json();
        setPayments(d.payments || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  // Real Database Metrics Calculation
  const totalVerifiedRevenue = payments
    .filter((p) => p.status === 'verified')
    .reduce((acc, p) => acc + (Number(p.amount) || 0), 0);

  const totalOutstandingBalance = invoices
    .reduce((acc, inv) => acc + (Number(inv.balanceDue) || 0), 0);

  // Funnel calculations
  const totalLeads = inquiries.length;
  const contactedLeads = inquiries.filter((i) => i.status !== 'New').length;
  const proposalLeads = inquiries.filter((i) => ['Proposal Sent', 'Quotation Sent', 'Won', 'Completed', 'In Progress'].includes(i.status)).length;
  const wonLeads = inquiries.filter((i) => ['Won', 'Completed', 'In Progress'].includes(i.status) || Boolean(i.convertedProjectId)).length;

  const conversionRate = totalLeads > 0 ? Math.round((wonLeads / totalLeads) * 100) : 0;

  // Breakdown by Service
  const serviceCounts: Record<string, number> = {};
  inquiries.forEach((i) => {
    serviceCounts[i.service] = (serviceCounts[i.service] || 0) + 1;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-white tracking-tight flex items-center gap-3">
            <BarChart3 className="w-7 h-7 text-[#244BFF]" />
            <span>Analytics & Intelligence Reports</span>
          </h1>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            Data aggregated strictly from verified database records. Zero synthetic or simulated statistics.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchData}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-white/80 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Analytics</span>
        </button>
      </div>

      {/* Top Level Genuine KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-surface p-5 rounded-2xl border border-white/10">
          <div className="flex items-center justify-between text-white/40 mb-2">
            <span className="text-xs font-mono uppercase">Verified Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-heading">
            ${totalVerifiedRevenue.toLocaleString()}
          </div>
          <div className="text-[11px] font-mono text-emerald-400 mt-1">
            {payments.filter((p) => p.status === 'verified').length} verified transactions
          </div>
        </div>

        <div className="glass-surface p-5 rounded-2xl border border-white/10">
          <div className="flex items-center justify-between text-white/40 mb-2">
            <span className="text-xs font-mono uppercase">Outstanding Invoices</span>
            <Receipt className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-heading">
            ${totalOutstandingBalance.toLocaleString()}
          </div>
          <div className="text-[11px] font-mono text-white/40 mt-1">
            {invoices.filter((i) => i.balanceDue > 0).length} open balances
          </div>
        </div>

        <div className="glass-surface p-5 rounded-2xl border border-white/10">
          <div className="flex items-center justify-between text-white/40 mb-2">
            <span className="text-xs font-mono uppercase">CRM Inquiry Volume</span>
            <Inbox className="w-4 h-4 text-[#FF5A1F]" />
          </div>
          <div className="text-2xl font-bold text-white font-heading">
            {totalLeads}
          </div>
          <div className="text-[11px] font-mono text-white/40 mt-1">
            All channels unified
          </div>
        </div>

        <div className="glass-surface p-5 rounded-2xl border border-white/10">
          <div className="flex items-center justify-between text-white/40 mb-2">
            <span className="text-xs font-mono uppercase">Lead-to-Project Conversion</span>
            <TrendingUp className="w-4 h-4 text-[#244BFF]" />
          </div>
          <div className="text-2xl font-bold text-white font-heading">
            {conversionRate}%
          </div>
          <div className="text-[11px] font-mono text-white/40 mt-1">
            {wonLeads} converted into projects
          </div>
        </div>
      </div>

      {/* Funnel & Service Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Conversion Pipeline Funnel */}
        <div className="lg:col-span-7 glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#FF5A1F]" />
            <span>Lead Conversion Pipeline</span>
          </h2>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs font-mono text-white/70 mb-1">
                <span>1. Inbound Inquiries</span>
                <span className="font-bold text-white">{totalLeads}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-[#FF5A1F] to-[#FF7A00] rounded-full" style={{ width: '100%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono text-white/70 mb-1">
                <span>2. Contacted & Qualified</span>
                <span className="font-bold text-white">{contactedLeads}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full bg-[#244BFF] rounded-full transition-all"
                  style={{ width: `${totalLeads > 0 ? (contactedLeads / totalLeads) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono text-white/70 mb-1">
                <span>3. Formal Proposal Dispatched</span>
                <span className="font-bold text-white">{proposalLeads}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full transition-all"
                  style={{ width: `${totalLeads > 0 ? (proposalLeads / totalLeads) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono text-white/70 mb-1">
                <span>4. Won & Active Engagement</span>
                <span className="font-bold text-emerald-400">{wonLeads}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all"
                  style={{ width: `${totalLeads > 0 ? (wonLeads / totalLeads) * 100 : 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Inbound Demand By Service */}
        <div className="lg:col-span-5 glass-surface p-6 rounded-2xl border border-white/10 space-y-4">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <FolderGit2 className="w-4 h-4 text-[#244BFF]" />
            <span>Demand By Service Track</span>
          </h2>

          {Object.keys(serviceCounts).length === 0 ? (
            <div className="p-8 text-center text-xs text-white/40">No service inquiries logged yet.</div>
          ) : (
            <div className="space-y-3 pt-2">
              {Object.entries(serviceCounts).map(([svc, count]) => (
                <div key={svc} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs">
                  <span className="text-white/80 font-medium">{svc}</span>
                  <span className="font-mono text-[#FF5A1F] font-bold px-2 py-0.5 rounded bg-[#FF5A1F]/10 border border-[#FF5A1F]/20">
                    {count} {count === 1 ? 'inquiry' : 'inquiries'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
