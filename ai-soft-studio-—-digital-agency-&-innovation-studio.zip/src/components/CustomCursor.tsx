import React, { useEffect, useState, useRef } from 'react';

export const CustomCursor: React.FC = () => {
  const [enabled, setEnabled] = useState(false);
  const [visible, setVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isInput, setIsInput] = useState(false);

  const cursorDotRef = useRef<HTMLDivElement | null>(null);
  const cursorRingRef = useRef<HTMLDivElement | null>(null);

  // Position references for smooth interpolation (Lerp)
  const mousePos = useRef({ x: -100, y: -100 });
  const ringPos = useRef({ x: -100, y: -100 });
  const magneticTarget = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    // Only enable on desktop screens with fine pointer (mouse)
    const checkIsDesktop = () => {
      const hasFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
      const isWideEnough = window.innerWidth >= 1024;
      const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      setEnabled(hasFinePointer && isWideEnough && !reducedMotion);
    };

    checkIsDesktop();
    window.addEventListener('resize', checkIsDesktop);

    return () => window.removeEventListener('resize', checkIsDesktop);
  }, []);

  useEffect(() => {
    if (!enabled) return;

    let animId: number;

    const handleMouseMove = (e: MouseEvent) => {
      if (!visible) setVisible(true);
      mousePos.current = { x: e.clientX, y: e.clientY };

      // Check what element is directly under the pointer
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const interactive = target.closest(
        'button, a, input, textarea, select, [role="button"], .cursor-pointer, [data-magnetic]'
      );

      const isInputElement = target.closest('input, textarea, select');
      setIsInput(!!isInputElement);

      if (interactive && !isInputElement) {
        setIsHovered(true);
        // Magnetic pull calculation
        const rect = interactive.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        magneticTarget.current = { x: centerX, y: centerY };
      } else {
        setIsHovered(false);
        magneticTarget.current = null;
      }
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);
    const handleMouseLeave = () => setVisible(false);
    const handleMouseEnter = () => setVisible(true);

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    // Smooth 60fps render loop with magnetic spring damping
    const render = () => {
      let targetX = mousePos.current.x;
      let targetY = mousePos.current.y;

      // If magnetic target exists, blend towards the button center
      if (magneticTarget.current) {
        const pullFactor = 0.32;
        targetX += (magneticTarget.current.x - targetX) * pullFactor;
        targetY += (magneticTarget.current.y - targetY) * pullFactor;
      }

      // Linear interpolation for outer ring lag & fluidity
      const ease = 0.22;
      ringPos.current.x += (targetX - ringPos.current.x) * ease;
      ringPos.current.y += (targetY - ringPos.current.y) * ease;

      if (cursorRingRef.current) {
        cursorRingRef.current.style.transform = `translate3d(${ringPos.current.x}px, ${ringPos.current.y}px, 0)`;
      }

      if (cursorDotRef.current) {
        // Inner dot follows exact mouse position without magnetic offset for pinpoint accuracy
        cursorDotRef.current.style.transform = `translate3d(${mousePos.current.x}px, ${mousePos.current.y}px, 0)`;
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [enabled, visible]);

  if (!enabled) return null;

  return (
    <div
      className={`fixed inset-0 pointer-events-none z-[9999] transition-opacity duration-300 ${
        visible ? 'opacity-100' : 'opacity-0'
      }`}
      aria-hidden="true"
    >
      {/* Outer Magnetic Ring */}
      <div
        ref={cursorRingRef}
        className={`fixed top-0 left-0 -ml-5 -mt-5 rounded-full transition-[width,height,background-color,border-color,box-shadow,transform] duration-200 ease-out will-change-transform ${
          isInput
            ? 'w-6 h-6 -ml-3 -mt-3 border border-white/20 bg-transparent opacity-40'
            : isHovered
            ? 'w-16 h-16 -ml-8 -mt-8 border border-[#FF5A1F] bg-[#FF5A1F]/15 backdrop-blur-[2px] shadow-[0_0_25px_rgba(255,90,31,0.45)]'
            : isClicking
            ? 'w-8 h-8 -ml-4 -mt-4 border-2 border-[#FF7A00] bg-[#FF5A1F]/30'
            : 'w-10 h-10 border border-white/40 bg-white/[0.03]'
        }`}
      />

      {/* Center Pinpoint Dot */}
      <div
        ref={cursorDotRef}
        className={`fixed top-0 left-0 -ml-1 -mt-1 rounded-full will-change-transform transition-[background-color,transform] duration-150 ${
          isInput
            ? 'w-1.5 h-1.5 bg-white/60'
            : isHovered
            ? 'w-2 h-2 -ml-1 -mt-1 bg-[#FF7A00] shadow-[0_0_8px_#FF5A1F]'
            : 'w-2 h-2 bg-[#FF5A1F]'
        }`}
      />
    </div>
  );
};
