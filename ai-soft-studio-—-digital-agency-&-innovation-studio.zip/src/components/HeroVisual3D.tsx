import React, { useEffect, useRef, useState } from 'react';
import { Cpu, Layout, Sparkles, Zap } from 'lucide-react';

export const HeroVisual3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = 600);
    let height = (canvas.height = 600);
    let rotation = 0;
    let curX = 0;
    let curY = 0;

    const render = () => {
      // Damped pointer follow
      curX += (mousePos.x - curX) * 0.05;
      curY += (mousePos.y - curY) * 0.05;

      ctx.clearRect(0, 0, width, height);

      const centerX = width / 2 + curX * 25;
      const centerY = height / 2 + curY * 25;
      const sphereRadius = 120;

      rotation += 0.008;

      // 1. Orbital Ring 1 (Royal Blue inclined)
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(0.35 + curY * 0.2);
      ctx.scale(1, 0.32);
      ctx.beginPath();
      ctx.arc(0, 0, sphereRadius * 1.85, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(36, 75, 255, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Orbital particle 1
      const p1Angle = rotation * 1.5;
      const p1X = Math.cos(p1Angle) * sphereRadius * 1.85;
      const p1Y = Math.sin(p1Angle) * sphereRadius * 1.85;
      ctx.beginPath();
      ctx.arc(p1X, p1Y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#244BFF';
      ctx.shadowColor = '#244BFF';
      ctx.shadowBlur = 15;
      ctx.fill();
      ctx.restore();

      // 2. Orbital Ring 2 (Neon Orange counter-inclined)
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(-0.55 + curX * 0.2);
      ctx.scale(1, 0.38);
      ctx.beginPath();
      ctx.arc(0, 0, sphereRadius * 2.1, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 90, 31, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Orbital particle 2 with light trail
      const p2Angle = -rotation * 1.2;
      const p2X = Math.cos(p2Angle) * sphereRadius * 2.1;
      const p2Y = Math.sin(p2Angle) * sphereRadius * 2.1;
      ctx.beginPath();
      ctx.arc(p2X, p2Y, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#FF5A1F';
      ctx.shadowColor = '#FF7A00';
      ctx.shadowBlur = 18;
      ctx.fill();
      ctx.restore();

      // 3. Orbital Ring 3 (Equatorial fine trail)
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(0.1 + curX * 0.1);
      ctx.scale(1, 0.22);
      ctx.beginPath();
      ctx.arc(0, 0, sphereRadius * 2.4, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.setLineDash([4, 8]);
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      // 4. Central 3D Glass Orb
      // Background glow
      const glowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        sphereRadius * 0.5,
        centerX,
        centerY,
        sphereRadius * 1.6
      );
      glowGrad.addColorStop(0, 'rgba(255, 90, 31, 0.2)');
      glowGrad.addColorStop(0.5, 'rgba(36, 75, 255, 0.15)');
      glowGrad.addColorStop(1, 'rgba(8, 13, 37, 0)');
      ctx.beginPath();
      ctx.arc(centerX, centerY, sphereRadius * 1.6, 0, Math.PI * 2);
      ctx.fillStyle = glowGrad;
      ctx.fill();

      // Glass sphere body
      const sphereGrad = ctx.createRadialGradient(
        centerX - sphereRadius * 0.35 + curX * 15,
        centerY - sphereRadius * 0.35 + curY * 15,
        sphereRadius * 0.1,
        centerX,
        centerY,
        sphereRadius
      );
      sphereGrad.addColorStop(0, '#FF7A00');
      sphereGrad.addColorStop(0.35, '#FF5A1F');
      sphereGrad.addColorStop(0.7, '#141E46');
      sphereGrad.addColorStop(0.95, '#244BFF');
      sphereGrad.addColorStop(1, 'rgba(36, 75, 255, 0.8)');

      ctx.save();
      ctx.beginPath();
      ctx.arc(centerX, centerY, sphereRadius, 0, Math.PI * 2);
      ctx.fillStyle = sphereGrad;
      ctx.shadowColor = 'rgba(255, 90, 31, 0.5)';
      ctx.shadowBlur = 30;
      ctx.fill();
      ctx.restore();

      // Latitude / Longitude 3D wire curves inside sphere
      ctx.save();
      ctx.beginPath();
      ctx.arc(centerX, centerY, sphereRadius, 0, Math.PI * 2);
      ctx.clip();

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.lineWidth = 1;

      // Rotating Meridian lines
      for (let i = -2; i <= 2; i++) {
        const offset = Math.sin(rotation + i * 0.6) * sphereRadius * 0.7;
        ctx.beginPath();
        ctx.ellipse(centerX + offset, centerY, Math.max(2, Math.abs(offset)), sphereRadius, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Parallels
      for (let j = -2; j <= 2; j++) {
        const yOff = (j * sphereRadius) / 3;
        const radAtY = Math.sqrt(Math.max(0, sphereRadius * sphereRadius - yOff * yOff));
        ctx.beginPath();
        ctx.ellipse(centerX, centerY + yOff, radAtY, radAtY * 0.35, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Surface Glass Highlight
      const highlightGrad = ctx.createRadialGradient(
        centerX - sphereRadius * 0.45,
        centerY - sphereRadius * 0.45,
        2,
        centerX - sphereRadius * 0.45,
        centerY - sphereRadius * 0.45,
        sphereRadius * 0.5
      );
      highlightGrad.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
      highlightGrad.addColorStop(0.4, 'rgba(255, 255, 255, 0.15)');
      highlightGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

      ctx.beginPath();
      ctx.arc(centerX - sphereRadius * 0.4, centerY - sphereRadius * 0.4, sphereRadius * 0.45, 0, Math.PI * 2);
      ctx.fillStyle = highlightGrad;
      ctx.fill();

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animId);
  }, [mousePos]);

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-[560px] aspect-square flex items-center justify-center select-none"
    >
      {/* Dynamic 3D Canvas */}
      <canvas
        ref={canvasRef}
        width={600}
        height={600}
        className="w-full h-full object-contain pointer-events-none drop-shadow-[0_20px_50px_rgba(255,90,31,0.25)]"
      />

      {/* Floating Glass Panel 1: Top-Left Automation Node */}
      <div
        className="absolute -top-2 left-0 sm:left-4 glass-surface rounded-xl p-3.5 shadow-2xl transition-transform duration-300 pointer-events-auto"
        style={{
          transform: `translate3d(${mousePos.x * -12}px, ${mousePos.y * -12}px, 0)`,
          borderColor: 'rgba(36, 75, 255, 0.3)',
        }}
      >
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-7 h-7 rounded-lg bg-[#244BFF]/20 flex items-center justify-center text-[#244BFF] border border-[#244BFF]/30">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white tracking-wide">Intelligent Workflow</div>
            <div className="text-[11px] text-white/50">Active Node Orchestration</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-mono text-white/70 bg-[#080D25]/60 px-2.5 py-1 rounded-md border border-white/5">
          <span className="text-[#FF5A1F]">Ingest</span>
          <span className="text-white/30">→</span>
          <span className="text-[#244BFF]">Neural Filter</span>
          <span className="text-white/30">→</span>
          <span className="text-white">Auto-Dispatch</span>
        </div>
      </div>

      {/* Floating Glass Panel 2: Bottom-Right Responsive Layout */}
      <div
        className="absolute -bottom-4 right-0 sm:right-4 glass-surface rounded-xl p-3.5 shadow-2xl transition-transform duration-300 pointer-events-auto"
        style={{
          transform: `translate3d(${mousePos.x * 15}px, ${mousePos.y * 15}px, 0)`,
          borderColor: 'rgba(255, 90, 31, 0.35)',
        }}
      >
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-7 h-7 rounded-lg bg-[#FF5A1F]/20 flex items-center justify-center text-[#FF5A1F] border border-[#FF5A1F]/30">
            <Layout className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white tracking-wide">High-Speed Architecture</div>
            <div className="text-[11px] text-white/50">Production Grade</div>
          </div>
        </div>
        <div className="flex items-center gap-3 text-[11px] text-white/70">
          <span className="flex items-center gap-1 font-mono text-[#FF7A00]">
            <Zap className="w-3 h-3" /> 60fps Native
          </span>
          <span className="text-white/20">·</span>
          <span className="flex items-center gap-1 font-mono text-[#244BFF]">
            <Sparkles className="w-3 h-3" /> Sub-50ms
          </span>
        </div>
      </div>
    </div>
  );
};
