import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import {
  User,
  Inquiry,
  Project,
  Task,
  ServicePackage,
  Quotation,
  Invoice,
  Payment,
  MetaIntegrationConfig,
  AuditLog,
  CMSContent,
  SecurityAssessment,
  ConversationThread,
  NotificationTemplate,
} from './types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../../../data');

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readTable<T>(filename: string, defaultValue: T): T {
  ensureDir();
  const filePath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filePath)) {
    writeTable(filename, defaultValue);
    return defaultValue;
  }
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error reading ${filename}:`, err);
    return defaultValue;
  }
}

function writeTable<T>(filename: string, data: T): boolean {
  ensureDir();
  const filePath = path.join(DATA_DIR, filename);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error(`Error writing ${filename}:`, err);
    return false;
  }
}

// Password hashing utility using built-in crypto
export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const verifyHash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return hash === verifyHash;
}

// Initial Database Seeding
export function initializeDatabase() {
  ensureDir();

  // 1. Users
  const users = readTable<User[]>('users.json', []);
  if (users.length === 0) {
    const adminPass = hashPassword('StudioAdmin2026!');
    const staffPass = hashPassword('Staff2026!');
    const devPass = hashPassword('Developer2026!');
    const clientPass = hashPassword('Client2026!');

    const seedUsers: User[] = [
      {
        id: 'usr_super_admin',
        name: 'Alex Vance (Super Admin)',
        email: 'admin@aisoft.studio',
        passwordHash: adminPass.hash,
        salt: adminPass.salt,
        role: 'super_admin',
        businessName: 'AI SOFT STUDIO',
        phone: '+1 (555) 019-2831',
        status: 'active',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'usr_staff_sarah',
        name: 'Sarah Lin (Operations)',
        email: 'staff@aisoft.studio',
        passwordHash: staffPass.hash,
        salt: staffPass.salt,
        role: 'staff',
        businessName: 'AI SOFT STUDIO',
        phone: '+1 (555) 019-2832',
        status: 'active',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'usr_dev_marcus',
        name: 'Marcus Brody (Lead Engineer)',
        email: 'dev@aisoft.studio',
        passwordHash: devPass.hash,
        salt: devPass.salt,
        role: 'developer',
        businessName: 'AI SOFT STUDIO',
        phone: '+1 (555) 019-2833',
        status: 'active',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'usr_client_forma',
        name: 'Elena Rostova (Client)',
        email: 'client@forma.com',
        passwordHash: clientPass.hash,
        salt: clientPass.salt,
        role: 'client',
        businessName: 'FORMA Architecture Atelier',
        phone: '+1 (555) 019-9481',
        status: 'active',
        createdAt: new Date().toISOString(),
      },
    ];
    writeTable('users.json', seedUsers);
    console.log('[Database] Seeded 4 default role accounts (admin, staff, dev, client)');
  }

  // 2. Service Packages
  const packages = readTable<ServicePackage[]>('service_packages.json', []);
  if (packages.length === 0) {
    const seedPackages: ServicePackage[] = [
      {
        id: 'pkg_web_flagship',
        title: 'Bespoke Digital Flagship',
        category: 'Website Development',
        description: 'Ultra-fast React/Vite web application with bespoke design system, 60fps micro-animations, and full responsive testing.',
        startingPrice: 4800,
        currency: 'USD',
        turnaround: '3–4 Weeks',
        features: [
          'High-performance React 19 architecture',
          'Responsive layouts from mobile (360px) to 4K',
          'Hardware-accelerated animations',
          'SEO metadata & Schema.org JSON-LD',
          'Client documentation & CMS integration',
        ],
        active: true,
      },
      {
        id: 'pkg_ai_automation',
        title: 'Intelligent Process Automation',
        category: 'AI Automation',
        description: 'End-to-end document parsing, automated routing, and LLM reasoning pipelines connected to business APIs.',
        startingPrice: 6500,
        currency: 'USD',
        turnaround: '4–6 Weeks',
        features: [
          'Custom webhook receivers & data validation',
          'Schema-enforced Gemini/LLM document parsing',
          'CRM, Slack & email notification connectors',
          'Queue failover and error recovery',
          'Live operational telemetry dashboard',
        ],
        active: true,
      },
      {
        id: 'pkg_ecom_luxury',
        title: 'Headless E-Commerce Storefront',
        category: 'E-commerce Development',
        description: 'Frictionless boutique online store with dynamic product discovery, one-click cart, and secure Stripe checkout.',
        startingPrice: 5800,
        currency: 'USD',
        turnaround: '4–5 Weeks',
        features: [
          'Headless storefront with sub-second page loads',
          'Stripe Elements & Multi-currency payments',
          'Inventory sync & transactional receipts',
          'Cart abandonment mitigation',
          'Customer account portal',
        ],
        active: true,
      },
      {
        id: 'pkg_admin_console',
        title: 'Custom Operations Admin Console',
        category: 'Custom Admin Panels',
        description: 'Purpose-built operations control room with granular RBAC, tabular numeric sorting, and real-time metric graphs.',
        startingPrice: 7200,
        currency: 'USD',
        turnaround: '5–7 Weeks',
        features: [
          'Role-Based Access Control (RBAC) matrix',
          'Real-time operational charts & tabular data',
          'Searchable CRUD interfaces with CSV export',
          'Full audit logging & user action history',
          'Secure tokenized session authentication',
        ],
        active: true,
      },
    ];
    writeTable('service_packages.json', seedPackages);
  }

  // 3. Meta Integration Initial Config
  const metaConfig = readTable<MetaIntegrationConfig | null>('meta_config.json', null);
  if (!metaConfig) {
    const initialMeta: MetaIntegrationConfig = {
      appId: process.env.META_APP_ID || '',
      appSecret: process.env.META_APP_SECRET || '',
      webhookVerifyToken: process.env.META_WEBHOOK_VERIFY_TOKEN || 'aisoft_meta_verify_2026',
      pageAccessToken: process.env.META_PAGE_ACCESS_TOKEN || '',
      whatsappPhoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
      connectedPages: [],
      connectedInstagram: [],
      isVerified: false,
      eventLogs: [],
    };
    writeTable('meta_config.json', initialMeta);
  }

  // 4. CMS Initial Content
  const cmsContent = readTable<CMSContent | null>('cms_content.json', null);
  if (!cmsContent) {
    const initialCms: CMSContent = {
      status: 'published',
      publishedAt: new Date().toISOString(),
      lastEditedAt: new Date().toISOString(),
      editedBy: 'System Initializer',
      hero: {
        topLabel: 'INDEPENDENT DIGITAL INNOVATION STUDIO',
        headline: 'We Build Digital Experiences That Move Business Forward.',
        subtext: 'From high-performance websites to intelligent automation, we turn ambitious ideas into powerful digital solutions built around your business.',
        primaryCta: 'Explore Our Work',
        secondaryCta: 'Start a Project',
      },
      brand: {
        name: 'AI SOFT STUDIO',
        tagline: 'Your Vision. Our Innovation.',
        supportingLine: 'Design. Develop. Automate. Grow.',
        contactEmail: 'infoaisoft26@gmail.com',
      },
      announcement: {
        enabled: false,
        text: 'Q4 2026 Engineering Sprints now open for custom web platforms and AI automation systems.',
        badge: 'Studio Update',
      },
      faqs: [
        {
          question: 'What is your typical project delivery timeframe?',
          answer: 'Standard projects span 3 to 7 weeks depending on scope complexity. We work in dedicated engineering sprints with weekly live milestone demos.',
          category: 'Process',
        },
        {
          question: 'Do you offer fixed-scope pricing?',
          answer: 'Yes. Following discovery, we provide itemized quotations with milestone schedules and guaranteed scope boundaries.',
          category: 'Pricing',
        },
        {
          question: 'Can you integrate existing business databases and APIs?',
          answer: 'Absolutely. We specialize in custom integrations connecting REST endpoints, webhooks, SQL databases, and AI pipelines.',
          category: 'Technical',
        },
      ],
    };
    writeTable('cms_content.json', initialCms);
  }

  // Ensure empty collections exist
  readTable<Inquiry[]>('inquiries.json', []);
  readTable<Project[]>('projects.json', []);
  readTable<Task[]>('tasks.json', []);
  readTable<Quotation[]>('quotations.json', []);
  readTable<Invoice[]>('invoices.json', []);
  readTable<Payment[]>('payments.json', []);
  readTable<AuditLog[]>('audit_logs.json', []);
}

// Database Accessors
export const db = {
  // Users
  getUsers: (): User[] => readTable<User[]>('users.json', []),
  saveUsers: (users: User[]) => writeTable('users.json', users),
  getUserById: (id: string): User | undefined => {
    return readTable<User[]>('users.json', []).find((u) => u.id === id);
  },
  getUserByEmail: (email: string): User | undefined => {
    return readTable<User[]>('users.json', []).find(
      (u) => u.email.toLowerCase() === email.toLowerCase()
    );
  },

  // Inquiries
  getInquiries: (): Inquiry[] => readTable<Inquiry[]>('inquiries.json', []),
  saveInquiries: (inquiries: Inquiry[]) => writeTable('inquiries.json', inquiries),
  getInquiryById: (id: string): Inquiry | undefined => {
    return readTable<Inquiry[]>('inquiries.json', []).find((i) => i.id === id);
  },

  // Projects
  getProjects: (): Project[] => readTable<Project[]>('projects.json', []),
  saveProjects: (projects: Project[]) => writeTable('projects.json', projects),
  getProjectById: (id: string): Project | undefined => {
    return readTable<Project[]>('projects.json', []).find((p) => p.id === id);
  },

  // Tasks
  getTasks: (): Task[] => readTable<Task[]>('tasks.json', []),
  saveTasks: (tasks: Task[]) => writeTable('tasks.json', tasks),

  // Security Assessments (Lawful & Authorized)
  getSecurityAssessments: (): SecurityAssessment[] => readTable<SecurityAssessment[]>('security_assessments.json', []),
  saveSecurityAssessments: (assessments: SecurityAssessment[]) => writeTable('security_assessments.json', assessments),
  getSecurityAssessmentById: (id: string): SecurityAssessment | undefined => {
    return readTable<SecurityAssessment[]>('security_assessments.json', []).find((s) => s.id === id);
  },

  // Customer Conversations
  getConversations: (): ConversationThread[] => readTable<ConversationThread[]>('conversations.json', []),
  saveConversations: (threads: ConversationThread[]) => writeTable('conversations.json', threads),

  // Notification Templates
  getNotificationTemplates: (): NotificationTemplate[] => readTable<NotificationTemplate[]>('notifications_templates.json', []),
  saveNotificationTemplates: (templates: NotificationTemplate[]) => writeTable('notifications_templates.json', templates),

  // Service Packages
  getServicePackages: (): ServicePackage[] => readTable<ServicePackage[]>('service_packages.json', []),
  saveServicePackages: (packages: ServicePackage[]) => writeTable('service_packages.json', packages),

  // Quotations
  getQuotations: (): Quotation[] => readTable<Quotation[]>('quotations.json', []),
  saveQuotations: (quotations: Quotation[]) => writeTable('quotations.json', quotations),

  // Invoices
  getInvoices: (): Invoice[] => readTable<Invoice[]>('invoices.json', []),
  saveInvoices: (invoices: Invoice[]) => writeTable('invoices.json', invoices),

  // Payments
  getPayments: (): Payment[] => readTable<Payment[]>('payments.json', []),
  savePayments: (payments: Payment[]) => writeTable('payments.json', payments),

  // Meta Integration
  getMetaConfig: (): MetaIntegrationConfig => {
    const config = readTable<MetaIntegrationConfig | null>('meta_config.json', null);
    if (!config) {
      initializeDatabase();
      return readTable<MetaIntegrationConfig>('meta_config.json', {} as MetaIntegrationConfig);
    }
    return config;
  },
  saveMetaConfig: (config: MetaIntegrationConfig) => writeTable('meta_config.json', config),

  // Audit Logs
  getAuditLogs: (): AuditLog[] => readTable<AuditLog[]>('audit_logs.json', []),
  logAudit: (
    user: { id: string; name: string; role: any },
    action: string,
    resource: string,
    details: string,
    resourceId?: string,
    ip?: string
  ) => {
    const logs = readTable<AuditLog[]>('audit_logs.json', []);
    const newLog: AuditLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action,
      resource,
      resourceId,
      details,
      timestamp: new Date().toISOString(),
      ip,
    };
    logs.unshift(newLog);
    // Keep last 500 logs to prevent bloat
    writeTable('audit_logs.json', logs.slice(0, 500));
  },

  // CMS Content
  getCMSContent: (): CMSContent => {
    const content = readTable<CMSContent | null>('cms_content.json', null);
    if (!content) {
      initializeDatabase();
      return readTable<CMSContent>('cms_content.json', {} as CMSContent);
    }
    return content;
  },
  saveCMSContent: (content: CMSContent) => writeTable('cms_content.json', content),
};

// Run initial seed on load
initializeDatabase();
