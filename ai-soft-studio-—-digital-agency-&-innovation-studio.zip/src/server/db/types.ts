export type UserRole = 'super_admin' | 'staff' | 'developer' | 'client';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  salt: string;
  role: UserRole;
  businessName?: string;
  phone?: string;
  status: 'active' | 'inactive';
  createdAt: string;
  lastLogin?: string;
}

export type InquiryStatus =
  | 'New'
  | 'Contacted'
  | 'Qualified'
  | 'Proposal Sent'
  | 'Awaiting Decision'
  | 'Won'
  | 'Lost'
  | 'Closed'
  | 'Quotation Sent'
  | 'Awaiting Payment'
  | 'In Progress'
  | 'Completed';

export type InquirySource =
  | 'website_form'
  | 'scope_estimator'
  | 'ai_chatbot'
  | 'meta_leadgen'
  | 'meta_whatsapp'
  | 'meta_messenger'
  | 'direct';

export interface InquiryNote {
  id: string;
  authorId: string;
  authorName: string;
  text: string;
  createdAt: string;
}

export interface Inquiry {
  id: string;
  name: string;
  email: string;
  phone?: string;
  businessName?: string;
  companyName?: string;
  service: string;
  projectDescription: string;
  timeline?: string;
  estimatedBudget?: string;
  budgetRange?: string;
  preferredContactMethod?: 'Email' | 'Phone' | 'WhatsApp';
  privacyConsent: boolean;
  source: InquirySource;
  status: InquiryStatus;
  assignedTo?: string; // User ID
  assignedToName?: string;
  followUpDate?: string;
  notes: InquiryNote[];
  tags: string[];
  convertedProjectId?: string;
  createdAt: string;
  updatedAt: string;
}

export type ProjectStatus = 'Planning' | 'In Progress' | 'Review' | 'Completed' | 'On Hold';

export interface Milestone {
  id: string;
  projectId: string;
  title: string;
  description: string;
  dueDate: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  deliverables: string[];
  approvedByClient: boolean;
  completedAt?: string;
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  description?: string;
  assignedTo: string; // Developer ID
  assignedToName?: string;
  status: 'To Do' | 'In Progress' | 'Review' | 'Done';
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  dueDate?: string;
  progressNotes: {
    id: string;
    authorId: string;
    authorName: string;
    text: string;
    createdAt: string;
  }[];
  createdAt: string;
  updatedAt: string;
}

export interface Deliverable {
  id: string;
  projectId: string;
  title: string;
  fileType: string;
  url: string;
  uploadedBy: string;
  uploadedByName: string;
  approvedByClient: boolean;
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  inquiryId?: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  assignedDeveloperIds: string[];
  service: string;
  status: ProjectStatus;
  startDate: string;
  deadline: string;
  budget: number;
  progress: number; // 0-100
  description: string;
  repositoryUrl?: string;
  stagingUrl?: string;
  milestones: Milestone[];
  deliverables: Deliverable[];
  internalNotes?: string;
  clientVisibleNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ServicePackage {
  id: string;
  title: string;
  category: string;
  description: string;
  startingPrice: number;
  currency: string;
  turnaround: string;
  features: string[];
  active: boolean;
}

export interface QuotationItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Quotation {
  id: string;
  inquiryId?: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  items: QuotationItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  status: 'Draft' | 'Sent' | 'Accepted' | 'Declined';
  validUntil: string;
  notes?: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  quotationId?: string;
  projectId?: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  items: QuotationItem[];
  subtotal: number;
  tax: number;
  total: number;
  amountPaid: number;
  balanceDue: number;
  dueDate: string;
  status: 'Unpaid' | 'Partially Paid' | 'Paid' | 'Overdue';
  createdAt: string;
}

export interface Payment {
  id: string;
  invoiceId: string;
  clientId: string;
  clientName: string;
  amount: number;
  currency: string;
  method: 'razorpay' | 'bank_transfer' | 'manual';
  status: 'verified' | 'pending' | 'failed';
  transactionReference: string;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  razorpaySignature?: string;
  verifiedAt?: string;
  receiptUrl?: string;
  notes?: string;
  createdAt: string;
}

export interface SecurityFinding {
  id: string;
  title: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Info';
  category: string;
  targetEndpoint: string;
  description: string;
  impact: string;
  remediation: string;
  status: 'Open' | 'Remediated' | 'Mitigated';
  discoveredAt: string;
}

export interface SecurityAssessment {
  id: string;
  title: string;
  targetSystem: string;
  assessmentType:
    | 'Web Application Review'
    | 'Access Control & Auth Review'
    | 'Vulnerability Assessment'
    | 'Hardening & Config Review'
    | 'Incident Readiness & Backup Review';
  authorizationStatus: 'Pending Written Authorization' | 'Authorization Verified' | 'Declined';
  authorizationDocumentRef: string;
  authorizedBy: string;
  scopeDefinition: string;
  assignedLeadId?: string;
  assignedLeadName?: string;
  status:
    | 'Scope Definition'
    | 'Authorization Pending'
    | 'In Progress'
    | 'Findings Review'
    | 'Remediation Delivered'
    | 'Closed';
  findings: SecurityFinding[];
  executiveSummary?: string;
  reportGeneratedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ConversationMessage {
  id: string;
  sender: 'client' | 'staff' | 'ai_bot';
  senderName: string;
  channel: 'website_chat' | 'meta_whatsapp' | 'meta_messenger' | 'email';
  text: string;
  timestamp: string;
}

export interface ConversationThread {
  id: string;
  customerName: string;
  customerContact: string;
  channel: 'website_chat' | 'meta_whatsapp' | 'meta_messenger' | 'email';
  status: 'active' | 'resolved' | 'escalated_to_staff';
  inquiryId?: string;
  messages: ConversationMessage[];
  lastActivity: string;
}

export interface NotificationTemplate {
  id: string;
  name: string;
  trigger: string;
  channel: 'email' | 'whatsapp' | 'in_app';
  subject: string;
  body: string;
  variables: string[];
  active: boolean;
}

export interface MetaEventLog {
  id: string;
  eventType: string;
  source: 'leadgen' | 'messages' | 'whatsapp' | 'instagram';
  status: 'processed' | 'ignored' | 'failed';
  details: string;
  timestamp: string;
}

export interface MetaIntegrationConfig {
  appId: string;
  appSecret: string;
  webhookVerifyToken: string;
  pageAccessToken: string;
  whatsappPhoneNumberId: string;
  connectedPages: { id: string; name: string; category: string; isConnected: boolean }[];
  connectedInstagram: { id: string; username: string; isConnected: boolean }[];
  isVerified: boolean;
  lastVerifiedAt?: string;
  eventLogs: MetaEventLog[];
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  resource: string;
  resourceId?: string;
  details: string;
  timestamp: string;
  ip?: string;
}

export interface CMSContent {
  status: 'published' | 'draft';
  publishedAt?: string;
  lastEditedAt: string;
  editedBy: string;
  hero: {
    topLabel: string;
    headline: string;
    subtext: string;
    primaryCta: string;
    secondaryCta: string;
  };
  brand: {
    name: string;
    tagline: string;
    supportingLine: string;
    contactEmail: string;
  };
  announcement: {
    enabled: boolean;
    text: string;
    link?: string;
    badge?: string;
  };
  faqs: {
    question: string;
    answer: string;
    category: string;
  }[];
}
