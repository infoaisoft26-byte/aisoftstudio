import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db } from './db/store';
import { User, UserRole } from './db/types';

const SESSION_SECRET = process.env.SESSION_SECRET || 'aisoft_studio_session_secret_default_2026';

// Extend Express Request
export interface AuthenticatedRequest extends Request {
  user?: User;
}

export function generateAuthToken(user: User): string {
  const payload = {
    userId: user.id,
    role: user.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
  };
  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payloadB64)
    .digest('base64url');
  return `${payloadB64}.${signature}`;
}

export function verifyAuthToken(token: string): { userId: string; role: UserRole } | null {
  try {
    const [payloadB64, signature] = token.split('.');
    if (!payloadB64 || !signature) return null;

    const expectedSignature = crypto
      .createHmac('sha256', SESSION_SECRET)
      .update(payloadB64)
      .digest('base64url');

    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
      return null;
    }

    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf-8'));
    if (payload.exp < Date.now()) {
      return null; // Expired
    }
    return { userId: payload.userId, role: payload.role };
  } catch (err) {
    return null;
  }
}

export function authenticate(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || (req.headers['x-auth-token'] as string);
  if (!authHeader) {
    return res.status(401).json({ error: 'Authentication required. No token provided.' });
  }

  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader;
  const verified = verifyAuthToken(token);

  if (!verified) {
    return res.status(401).json({ error: 'Invalid or expired session token.' });
  }

  const user = db.getUserById(verified.userId);
  if (!user || user.status !== 'active') {
    return res.status(401).json({ error: 'User account not found or deactivated.' });
  }

  req.user = user;
  next();
}

export function requireRole(allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Access denied. Requires one of roles: [${allowedRoles.join(', ')}]. Current role: ${req.user.role}`,
      });
    }

    next();
  };
}

export function optionalAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || (req.headers['x-auth-token'] as string);
  if (authHeader) {
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader;
    const verified = verifyAuthToken(token);
    if (verified) {
      const user = db.getUserById(verified.userId);
      if (user && user.status === 'active') {
        req.user = user;
      }
    }
  }
  next();
}
