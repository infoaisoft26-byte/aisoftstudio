import { Router, Response } from 'express';
import { db, hashPassword, verifyPassword } from '../db/store';
import { generateAuthToken, authenticate, requireRole, AuthenticatedRequest } from '../auth';
import { UserRole } from '../db/types';

export const authRouter = Router();

// Public: Login
authRouter.post('/login', (req, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = db.getUserByEmail(email);
  if (!user || user.status !== 'active') {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const isValid = verifyPassword(password, user.passwordHash, user.salt);
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  // Update last login
  const users = db.getUsers();
  const idx = users.findIndex((u) => u.id === user.id);
  if (idx !== -1) {
    users[idx].lastLogin = new Date().toISOString();
    db.saveUsers(users);
  }

  const token = generateAuthToken(user);

  db.logAudit(
    user,
    'USER_LOGIN',
    'auth',
    `User ${user.email} logged in successfully`,
    user.id,
    req.ip
  );

  return res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      businessName: user.businessName,
      status: user.status,
    },
  });
});

// Current User Profile
authRouter.get('/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

  return res.json({
    user: {
      id: req.user.id,
      name: req.user.name,
      email: req.user.email,
      role: req.user.role,
      businessName: req.user.businessName,
      phone: req.user.phone,
      status: req.user.status,
      createdAt: req.user.createdAt,
      lastLogin: req.user.lastLogin,
    },
  });
});

// Admin/Staff: List all users
authRouter.get(
  '/users',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (_req: AuthenticatedRequest, res: Response) => {
    const users = db.getUsers().map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      businessName: u.businessName,
      phone: u.phone,
      status: u.status,
      createdAt: u.createdAt,
      lastLogin: u.lastLogin,
    }));
    return res.json({ users });
  }
);

// Super Admin: Create user account
authRouter.post(
  '/users',
  authenticate,
  requireRole(['super_admin']),
  (req: AuthenticatedRequest, res: Response) => {
    const { name, email, password, role, businessName, phone } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: 'Name, email, password, and role are required.' });
    }

    const validRoles: UserRole[] = ['super_admin', 'staff', 'developer', 'client'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ error: `Invalid role. Allowed: ${validRoles.join(', ')}` });
    }

    if (db.getUserByEmail(email)) {
      return res.status(409).json({ error: 'A user with this email address already exists.' });
    }

    const { hash, salt } = hashPassword(password);
    const newUser = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      passwordHash: hash,
      salt,
      role: role as UserRole,
      businessName: businessName ? businessName.trim() : undefined,
      phone: phone ? phone.trim() : undefined,
      status: 'active' as const,
      createdAt: new Date().toISOString(),
    };

    const users = db.getUsers();
    users.push(newUser);
    db.saveUsers(users);

    db.logAudit(
      req.user!,
      'USER_CREATE',
      'user',
      `Created new user ${newUser.email} with role ${newUser.role}`,
      newUser.id,
      req.ip
    );

    return res.status(201).json({
      success: true,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        businessName: newUser.businessName,
        status: newUser.status,
      },
    });
  }
);

// Super Admin: Update user status/role
authRouter.patch(
  '/users/:id',
  authenticate,
  requireRole(['super_admin']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { role, status, name, businessName } = req.body;

    const users = db.getUsers();
    const idx = users.findIndex((u) => u.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'User not found.' });
    }

    // Prevent deactivating own account
    if (users[idx].id === req.user!.id && status === 'inactive') {
      return res.status(400).json({ error: 'You cannot deactivate your own account.' });
    }

    if (role) users[idx].role = role;
    if (status) users[idx].status = status;
    if (name) users[idx].name = name.trim();
    if (businessName !== undefined) users[idx].businessName = businessName ? businessName.trim() : undefined;

    db.saveUsers(users);

    db.logAudit(
      req.user!,
      'USER_UPDATE',
      'user',
      `Updated user ${users[idx].email}: role=${users[idx].role}, status=${users[idx].status}`,
      users[idx].id,
      req.ip
    );

    return res.json({
      success: true,
      user: {
        id: users[idx].id,
        name: users[idx].name,
        email: users[idx].email,
        role: users[idx].role,
        status: users[idx].status,
      },
    });
  }
);

// Super Admin: View Audit Logs
authRouter.get(
  '/audit-logs',
  authenticate,
  requireRole(['super_admin']),
  (_req: AuthenticatedRequest, res: Response) => {
    const logs = db.getAuditLogs();
    return res.json({ logs });
  }
);
