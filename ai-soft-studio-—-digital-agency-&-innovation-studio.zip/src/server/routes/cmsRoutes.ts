import { Router, Request, Response } from 'express';
import { db } from '../db/store';
import { authenticate, requireRole, AuthenticatedRequest } from '../auth';
import { CMSContent } from '../db/types';

export const cmsRouter = Router();

// In-memory version history for rollbacks (persists during runtime)
let versionHistory: CMSContent[] = [];

// Public: Get Live Published Content
cmsRouter.get('/live', (_req: Request, res: Response) => {
  const content = db.getCMSContent();
  return res.json({ content });
});

// Admin: Get Current CMS Draft / Live Content
cmsRouter.get('/draft', authenticate, requireRole(['super_admin', 'staff']), (_req: AuthenticatedRequest, res: Response) => {
  const content = db.getCMSContent();
  return res.json({ content, historyCount: versionHistory.length });
});

// Admin: Save Content as Draft
cmsRouter.post('/draft', authenticate, requireRole(['super_admin', 'staff']), (req: AuthenticatedRequest, res: Response) => {
  const { hero, brand, announcement, faqs } = req.body;
  const current = db.getCMSContent();

  // Save current to history before updating draft
  if (versionHistory.length === 0 || JSON.stringify(versionHistory[0]) !== JSON.stringify(current)) {
    versionHistory.unshift(JSON.parse(JSON.stringify(current)));
    if (versionHistory.length > 10) versionHistory.pop();
  }

  const updatedDraft: CMSContent = {
    ...current,
    status: 'draft',
    lastEditedAt: new Date().toISOString(),
    editedBy: req.user!.name,
    hero: hero || current.hero,
    brand: brand || current.brand,
    announcement: announcement || current.announcement,
    faqs: Array.isArray(faqs) ? faqs : current.faqs,
  };

  db.saveCMSContent(updatedDraft);

  db.logAudit(
    req.user!,
    'CMS_DRAFT_SAVED',
    'cms',
    `Saved CMS content changes as Draft`,
    undefined,
    req.ip
  );

  return res.json({ success: true, content: updatedDraft, message: 'Draft saved. Changes not visible on public site until published.' });
});

// Admin: Publish Draft to Live
cmsRouter.post('/publish', authenticate, requireRole(['super_admin', 'staff']), (req: AuthenticatedRequest, res: Response) => {
  const current = db.getCMSContent();

  // Snapshot before publishing
  versionHistory.unshift(JSON.parse(JSON.stringify(current)));
  if (versionHistory.length > 10) versionHistory.pop();

  const publishedContent: CMSContent = {
    ...current,
    status: 'published',
    publishedAt: new Date().toISOString(),
    lastEditedAt: new Date().toISOString(),
    editedBy: req.user!.name,
  };

  db.saveCMSContent(publishedContent);

  db.logAudit(
    req.user!,
    'CMS_PUBLISHED',
    'cms',
    `Published CMS content updates to live public website`,
    undefined,
    req.ip
  );

  return res.json({ success: true, content: publishedContent, message: 'Website content successfully published to live website!' });
});

// Admin: Rollback to Previous Version
cmsRouter.post('/rollback', authenticate, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  if (versionHistory.length === 0) {
    return res.status(400).json({ error: 'No previous revision available to rollback to.' });
  }

  const previous = versionHistory.shift()!;
  previous.lastEditedAt = new Date().toISOString();
  previous.editedBy = `${req.user!.name} (Rollback)`;

  db.saveCMSContent(previous);

  db.logAudit(
    req.user!,
    'CMS_ROLLBACK',
    'cms',
    `Rolled back website CMS content to previous snapshot`,
    undefined,
    req.ip
  );

  return res.json({ success: true, content: previous, message: 'Successfully rolled back to previous content revision.' });
});
