import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { db } from '../db/store';
import { authenticate, requireRole, AuthenticatedRequest } from '../auth';
import { ServicePackage, Quotation, Invoice, Payment } from '../db/types';

export const financeRouter = Router();

// ==========================================
// 1. SERVICES & PACKAGES
// ==========================================

financeRouter.get('/services', (_req: Request, res: Response) => {
  const packages = db.getServicePackages();
  return res.json({ packages });
});

financeRouter.post('/services', authenticate, requireRole(['super_admin', 'staff']), (req: AuthenticatedRequest, res: Response) => {
  const { title, category, description, startingPrice, turnaround, features } = req.body;

  if (!title || !startingPrice) {
    return res.status(400).json({ error: 'Title and starting price are required.' });
  }

  const newPkg: ServicePackage = {
    id: `pkg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    title: title.trim(),
    category: category || 'Custom Digital Solution',
    description: description?.trim() || '',
    startingPrice: Number(startingPrice),
    currency: 'USD',
    turnaround: turnaround || '3–4 Weeks',
    features: Array.isArray(features) ? features : [],
    active: true,
  };

  const packages = db.getServicePackages();
  packages.push(newPkg);
  db.saveServicePackages(packages);

  db.logAudit(req.user!, 'SERVICE_CREATED', 'service_package', `Created service package "${newPkg.title}"`, newPkg.id, req.ip);

  return res.status(201).json({ success: true, package: newPkg });
});

// ==========================================
// 2. QUOTATIONS
// ==========================================

financeRouter.get('/quotations', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let quotations = db.getQuotations();

  if (user.role === 'client') {
    quotations = quotations.filter((q) => q.clientId === user.id || q.clientEmail.toLowerCase() === user.email.toLowerCase());
  }

  return res.json({ count: quotations.length, quotations });
});

financeRouter.post('/quotations', authenticate, requireRole(['super_admin', 'staff']), (req: AuthenticatedRequest, res: Response) => {
  const { inquiryId, clientId, clientName, clientEmail, items, taxRate, validUntil, notes } = req.body;

  if (!clientEmail || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Client email and line items are required.' });
  }

  const subtotal = items.reduce((acc: number, item: any) => acc + (Number(item.quantity) * Number(item.unitPrice)), 0);
  const taxPct = Number(taxRate) || 0;
  const taxAmount = Math.round((subtotal * taxPct) / 100);
  const total = subtotal + taxAmount;

  const quoteId = `QUO-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const newQuote: Quotation = {
    id: quoteId,
    inquiryId,
    clientId: clientId || 'usr_client_forma',
    clientName: clientName || 'Client',
    clientEmail: clientEmail.toLowerCase(),
    items: items.map((it: any, idx: number) => ({
      id: `item_${idx + 1}`,
      description: it.description,
      quantity: Number(it.quantity) || 1,
      unitPrice: Number(it.unitPrice) || 0,
      total: (Number(it.quantity) || 1) * (Number(it.unitPrice) || 0),
    })),
    subtotal,
    taxRate: taxPct,
    taxAmount,
    total,
    status: 'Sent',
    validUntil: validUntil || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    notes,
    createdAt: new Date().toISOString(),
  };

  const quotations = db.getQuotations();
  quotations.unshift(newQuote);
  db.saveQuotations(quotations);

  db.logAudit(req.user!, 'QUOTATION_CREATED', 'quotation', `Created quotation ${quoteId} totaling $${total}`, quoteId, req.ip);

  return res.status(201).json({ success: true, quotation: newQuote });
});

financeRouter.patch('/quotations/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;

  const quotations = db.getQuotations();
  const idx = quotations.findIndex((q) => q.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Quotation not found.' });

  const quote = quotations[idx];

  // Client can accept/decline their own quote
  if (req.user!.role === 'client' && quote.clientId !== req.user!.id && quote.clientEmail !== req.user!.email) {
    return res.status(403).json({ error: 'Access denied.' });
  }

  quote.status = status;
  db.saveQuotations(quotations);

  db.logAudit(req.user!, 'QUOTATION_STATUS_CHANGE', 'quotation', `Quotation ${id} status set to ${status}`, id, req.ip);

  return res.json({ success: true, quotation: quote });
});

// ==========================================
// 3. INVOICES
// ==========================================

financeRouter.get('/invoices', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let invoices = db.getInvoices();

  if (user.role === 'client') {
    invoices = invoices.filter((inv) => inv.clientId === user.id || inv.clientEmail.toLowerCase() === user.email.toLowerCase());
  }

  return res.json({ count: invoices.length, invoices });
});

financeRouter.post('/invoices', authenticate, requireRole(['super_admin', 'staff']), (req: AuthenticatedRequest, res: Response) => {
  const { quotationId, projectId, clientId, clientName, clientEmail, items, tax, dueDate } = req.body;

  if (!clientEmail || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Client email and line items are required.' });
  }

  const subtotal = items.reduce((acc: number, item: any) => acc + (Number(item.quantity) * Number(item.unitPrice)), 0);
  const taxAmount = Number(tax) || 0;
  const total = subtotal + taxAmount;

  const invId = `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const newInvoice: Invoice = {
    id: invId,
    quotationId,
    projectId,
    clientId: clientId || 'usr_client_forma',
    clientName: clientName || 'Client',
    clientEmail: clientEmail.toLowerCase(),
    items: items.map((it: any, idx: number) => ({
      id: `inv_item_${idx + 1}`,
      description: it.description,
      quantity: Number(it.quantity) || 1,
      unitPrice: Number(it.unitPrice) || 0,
      total: (Number(it.quantity) || 1) * (Number(it.unitPrice) || 0),
    })),
    subtotal,
    tax: taxAmount,
    total,
    amountPaid: 0,
    balanceDue: total,
    dueDate: dueDate || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'Unpaid',
    createdAt: new Date().toISOString(),
  };

  const invoices = db.getInvoices();
  invoices.unshift(newInvoice);
  db.saveInvoices(invoices);

  db.logAudit(req.user!, 'INVOICE_CREATED', 'invoice', `Created invoice ${invId} totaling $${total}`, invId, req.ip);

  return res.status(201).json({ success: true, invoice: newInvoice });
});

// ==========================================
// 4. PAYMENTS & RAZORPAY GATEWAY INTEGRATION
// ==========================================

// Razorpay webhook idempotency event cache
const processedRazorpayEvents = new Set<string>();

// Get Razorpay Configuration Status & Setup Checklist
financeRouter.get('/razorpay/status', authenticate, (_req: AuthenticatedRequest, res: Response) => {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;

  const isConfigured = Boolean(keyId && keySecret);

  return res.json({
    isConfigured,
    keyIdPreview: keyId ? `${keyId.substring(0, 8)}••••••••` : null,
    hasKeySecret: Boolean(keySecret),
    hasWebhookSecret: Boolean(webhookSecret),
    webhookEndpoint: '/api/webhooks/razorpay',
    checklist: [
      {
        step: 1,
        title: 'Obtain Razorpay API Credentials',
        description: 'Log in to the Razorpay Dashboard (Settings > API Keys) and generate Key Id and Key Secret.',
        completed: Boolean(keyId && keySecret),
      },
      {
        step: 2,
        title: 'Set Environment Variables',
        description: 'Add RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, and RAZORPAY_WEBHOOK_SECRET to your environment.',
        completed: Boolean(keyId && keySecret && webhookSecret),
      },
      {
        step: 3,
        title: 'Configure Webhook URL in Razorpay Dashboard',
        description: 'Add webhook pointing to https://your-domain.com/api/webhooks/razorpay for events: payment.captured, order.paid, payment.failed.',
        completed: Boolean(webhookSecret),
      },
      {
        step: 4,
        title: 'Server-Side Verification Active',
        description: 'All payments are cryptographically verified using HMAC SHA256 signatures before recording as verified.',
        completed: true,
      },
    ],
  });
});

financeRouter.get('/payments', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let payments = db.getPayments();

  if (user.role === 'client') {
    payments = payments.filter((p) => p.clientId === user.id);
  }

  return res.json({ count: payments.length, payments });
});

// Create Razorpay Order Server-Side
financeRouter.post('/razorpay/create-order', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { invoiceId, amount, currency } = req.body;

  if (!invoiceId || !amount) {
    return res.status(400).json({ error: 'Invoice ID and amount are required.' });
  }

  const invoice = db.getInvoices().find((i) => i.id === invoiceId);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found.' });

  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;

  if (!keyId || !keySecret) {
    return res.status(400).json({
      error: 'Razorpay payment gateway is not yet configured on this server.',
      requiresSetup: true,
      setupHelp:
        'Please supply RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in server environment variables to initiate live or test gateway orders.',
    });
  }

  try {
    const amountInSubunits = Math.round(Number(amount) * 100); // INR paise or USD cents
    const receiptId = `rcpt_${invoice.id.replace(/[^a-zA-Z0-9]/g, '_')}`;

    // Call Razorpay API using Basic Auth
    const authHeader = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
    const razorpayResponse = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${authHeader}`,
      },
      body: JSON.stringify({
        amount: amountInSubunits,
        currency: currency || 'USD',
        receipt: receiptId,
        notes: {
          invoiceId: invoice.id,
          clientId: invoice.clientId,
          clientEmail: invoice.clientEmail,
        },
      }),
    });

    if (!razorpayResponse.ok) {
      const errData = await razorpayResponse.json();
      return res.status(400).json({
        error: errData.error?.description || 'Failed to create order on Razorpay.',
      });
    }

    const orderData = await razorpayResponse.json();
    return res.json({
      success: true,
      orderId: orderData.id,
      amount: orderData.amount,
      currency: orderData.currency,
      keyId,
    });
  } catch (err: any) {
    return res.status(500).json({ error: `Razorpay order creation failed: ${err.message}` });
  }
});

// Verify Razorpay Payment Signature Server-Side
financeRouter.post('/razorpay/verify-payment', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const { invoiceId, razorpay_order_id, razorpay_payment_id, razorpay_signature, amount } = req.body;

  if (!invoiceId || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({
      error: 'Missing required Razorpay verification parameters: order_id, payment_id, or signature.',
    });
  }

  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keySecret) {
    return res.status(400).json({
      error: 'RAZORPAY_KEY_SECRET is not configured on server. Cannot verify payment signature.',
    });
  }

  // Cryptographic HMAC SHA256 verification
  const bodyToSign = `${razorpay_order_id}|${razorpay_payment_id}`;
  const expectedSignature = crypto.createHmac('sha256', keySecret).update(bodyToSign).digest('hex');

  const isValid = crypto.timingSafeEqual(
    Buffer.from(expectedSignature, 'utf-8'),
    Buffer.from(razorpay_signature, 'utf-8')
  );

  if (!isValid) {
    db.logAudit(
      req.user!,
      'PAYMENT_SIGNATURE_MISMATCH',
      'payment',
      `Tampered or invalid Razorpay signature detected for order ${razorpay_order_id}`,
      razorpay_order_id,
      req.ip
    );
    return res.status(400).json({ error: 'Invalid Razorpay payment signature. Verification failed.' });
  }

  // Fetch and update invoice
  const invoices = db.getInvoices();
  const invIdx = invoices.findIndex((i) => i.id === invoiceId);
  if (invIdx === -1) return res.status(404).json({ error: 'Invoice not found.' });

  const invoice = invoices[invIdx];
  const paidAmount = Number(amount) || invoice.balanceDue;
  const payId = `PAY-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const now = new Date().toISOString();

  const newPayment: Payment = {
    id: payId,
    invoiceId: invoice.id,
    clientId: invoice.clientId,
    clientName: invoice.clientName,
    amount: paidAmount,
    currency: 'USD',
    method: 'razorpay',
    status: 'verified',
    transactionReference: razorpay_payment_id,
    razorpayOrderId: razorpay_order_id,
    razorpayPaymentId: razorpay_payment_id,
    razorpaySignature: razorpay_signature,
    verifiedAt: now,
    notes: `Verified via Razorpay API. Order: ${razorpay_order_id}`,
    receiptUrl: `/receipts/${payId}`,
    createdAt: now,
  };

  invoice.amountPaid += paidAmount;
  invoice.balanceDue = Math.max(0, invoice.total - invoice.amountPaid);
  invoice.status = invoice.balanceDue === 0 ? 'Paid' : 'Partially Paid';
  db.saveInvoices(invoices);

  const payments = db.getPayments();
  payments.unshift(newPayment);
  db.savePayments(payments);

  db.logAudit(
    req.user!,
    'RAZORPAY_PAYMENT_VERIFIED',
    'payment',
    `Verified Razorpay payment ${payId} ($${paidAmount}) for invoice ${invoice.id}. Payment ID: ${razorpay_payment_id}`,
    payId,
    req.ip
  );

  return res.json({ success: true, payment: newPayment, invoice });
});

// Admin/Staff: Record & Verify Manual or Bank Transfer Payment
financeRouter.post('/payments/verify', authenticate, requireRole(['super_admin', 'staff']), (req: AuthenticatedRequest, res: Response) => {
  const { invoiceId, amount, method, transactionReference, notes } = req.body;

  if (!invoiceId || !amount || !transactionReference) {
    return res.status(400).json({ error: 'Invoice ID, amount, and transaction reference are required.' });
  }

  const invoices = db.getInvoices();
  const invIdx = invoices.findIndex((i) => i.id === invoiceId);
  if (invIdx === -1) return res.status(404).json({ error: 'Invoice not found.' });

  const invoice = invoices[invIdx];
  const payAmount = Number(amount);

  const payId = `PAY-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const now = new Date().toISOString();

  const newPayment: Payment = {
    id: payId,
    invoiceId: invoice.id,
    clientId: invoice.clientId,
    clientName: invoice.clientName,
    amount: payAmount,
    currency: 'USD',
    method: method === 'razorpay' ? 'razorpay' : 'bank_transfer',
    status: 'verified',
    transactionReference: transactionReference.trim(),
    verifiedAt: now,
    notes,
    receiptUrl: `/receipts/${payId}`,
    createdAt: now,
  };

  // Update invoice balance & status
  invoice.amountPaid += payAmount;
  invoice.balanceDue = Math.max(0, invoice.total - invoice.amountPaid);
  invoice.status = invoice.balanceDue === 0 ? 'Paid' : invoice.amountPaid > 0 ? 'Partially Paid' : 'Unpaid';

  db.saveInvoices(invoices);

  const payments = db.getPayments();
  payments.unshift(newPayment);
  db.savePayments(payments);

  db.logAudit(
    req.user!,
    'PAYMENT_VERIFIED',
    'payment',
    `Verified payment ${payId} ($${payAmount}) for invoice ${invoice.id}. Ref: ${transactionReference}`,
    payId,
    req.ip
  );

  return res.status(201).json({ success: true, payment: newPayment, invoice });
});

// Razorpay Official Webhook Handler with Idempotency & Duplicate Protection
financeRouter.post('/webhooks/razorpay', (req: Request, res: Response) => {
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.headers['x-razorpay-signature'] as string;

  if (!webhookSecret) {
    console.warn('[Razorpay Webhook] RAZORPAY_WEBHOOK_SECRET not configured. Rejecting request.');
    return res.status(400).json({
      error: 'Razorpay webhook unconfigured on server. Please configure RAZORPAY_WEBHOOK_SECRET.',
    });
  }

  if (!signature) {
    return res.status(400).json({ error: 'Missing x-razorpay-signature header.' });
  }

  try {
    const rawPayload = JSON.stringify(req.body);
    const expectedSig = crypto.createHmac('sha256', webhookSecret).update(rawPayload).digest('hex');

    const isValid = crypto.timingSafeEqual(
      Buffer.from(expectedSig, 'utf-8'),
      Buffer.from(signature, 'utf-8')
    );

    if (!isValid) {
      return res.status(400).json({ error: 'Invalid webhook signature.' });
    }

    const event = req.body;
    const eventId = event?.event_id || `${event?.event}_${event?.payload?.payment?.entity?.id}`;

    // Duplicate event protection (Idempotency)
    if (eventId && processedRazorpayEvents.has(eventId)) {
      console.log(`[Razorpay Webhook] Ignoring duplicate event ${eventId}`);
      return res.json({ received: true, duplicate: true });
    }

    if (eventId) {
      processedRazorpayEvents.add(eventId);
      // Clean old events cache if over 1000
      if (processedRazorpayEvents.size > 1000) {
        processedRazorpayEvents.clear();
      }
    }

    console.log(`[Razorpay Webhook] Processed event: ${event.event}`);

    // Handle payment.captured or order.paid
    if (event.event === 'payment.captured' || event.event === 'order.paid') {
      const paymentEntity = event.payload?.payment?.entity;
      const invoiceId = paymentEntity?.notes?.invoiceId;

      if (invoiceId) {
        const invoices = db.getInvoices();
        const invIdx = invoices.findIndex((i) => i.id === invoiceId);
        if (invIdx !== -1) {
          const inv = invoices[invIdx];
          const capturedAmount = paymentEntity.amount ? paymentEntity.amount / 100 : inv.balanceDue;
          inv.amountPaid += capturedAmount;
          inv.balanceDue = Math.max(0, inv.total - inv.amountPaid);
          inv.status = inv.balanceDue === 0 ? 'Paid' : 'Partially Paid';
          db.saveInvoices(invoices);

          const payId = `PAY-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
          const payments = db.getPayments();
          payments.unshift({
            id: payId,
            invoiceId: inv.id,
            clientId: inv.clientId,
            clientName: inv.clientName,
            amount: capturedAmount,
            currency: paymentEntity.currency || 'USD',
            method: 'razorpay',
            status: 'verified',
            transactionReference: paymentEntity.id,
            razorpayPaymentId: paymentEntity.id,
            verifiedAt: new Date().toISOString(),
            notes: 'Verified via Razorpay official webhook',
            receiptUrl: `/receipts/${payId}`,
            createdAt: new Date().toISOString(),
          });
          db.savePayments(payments);
        }
      }
    }

    return res.json({ received: true, event: event.event });
  } catch (err: any) {
    console.error('[Razorpay Webhook Error]:', err.message);
    return res.status(400).json({ error: 'Webhook processing failed.' });
  }
});
