import { Router, Request, Response } from 'express';
import { db } from '../db/store';
import { GoogleGenAI } from '@google/genai';
import { Inquiry } from '../db/types';

export const chatRouter = Router();

// In-memory conversation store for multi-turn sessions
interface ChatSession {
  id: string;
  history: { role: 'user' | 'model' | 'system'; text: string; timestamp: string }[];
  capturedLead?: { name?: string; email?: string; service?: string; description?: string };
}
const sessions = new Map<string, ChatSession>();

function getStudioSystemInstruction(): string {
  const cms = db.getCMSContent();
  const packages = db.getServicePackages();

  const packageSummaries = packages
    .map((p) => `• ${p.title} (${p.category}): Starting from $${p.startingPrice} ${p.currency}. Turnaround: ${p.turnaround}. Key deliverables: ${p.features.join(', ')}`)
    .join('\n');

  const faqSummaries = cms.faqs
    .map((f) => `Q: ${f.question}\nA: ${f.answer}`)
    .join('\n\n');

  return `You are the official AI Studio Consultant for AI SOFT STUDIO.
Brand: ${cms.brand.name}
Tagline: ${cms.brand.tagline}
Positioning: A modern digital technology studio specializing in high-performance website development, practical AI automation, headless e-commerce solutions, and custom operations admin panels.
Studio Email: ${cms.brand.contactEmail}

OFFICIAL SERVICE PACKAGES & PRICING:
${packageSummaries}

FREQUENTLY ASKED QUESTIONS & POLICIES:
${faqSummaries}

CORE PRINCIPLES & GUIDELINES:
1. Always be professional, concise, technically sound, and helpful.
2. If the user asks for pricing or delivery timelines, refer accurately to the official packages above.
3. If the user expresses interest in a project, quote, or consultation, offer to capture their contact details (Name, Work Email, Service Required, Brief) and confirm their consent before registering it into the studio CRM.
4. Do not invent fake client testimonials, fake awards, or non-existent partner programs.
5. If you do not know a specific company detail, direct them to contact the senior engineering team at ${cms.brand.contactEmail}.`;
}

// Check AI status
chatRouter.get('/status', (_req: Request, res: Response) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  return res.json({
    aiAvailable: hasKey,
    model: hasKey ? 'gemini-2.5-flash' : 'knowledge-base-fallback',
    modeDescription: hasKey
      ? 'Live Gemini AI Engine grounded on Studio Knowledge'
      : 'Rule-Based Knowledge Engine (Configure GEMINI_API_KEY in Secrets for generative reasoning)',
  });
});

// Chat message endpoint
chatRouter.post('/message', async (req: Request, res: Response) => {
  const { sessionId, message } = req.body;

  if (!message || typeof message !== 'string' || !message.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const sid = sessionId || `chat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  let session = sessions.get(sid);
  if (!session) {
    session = { id: sid, history: [] };
    sessions.set(sid, session);
  }

  session.history.push({
    role: 'user',
    text: message.trim(),
    timestamp: new Date().toISOString(),
  });

  const hasApiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');

  if (hasApiKey) {
    try {
      const ai = new GoogleGenAI();
      const systemInstruction = getStudioSystemInstruction();

      // Build recent conversation contents
      const conversationContext = session.history
        .slice(-8)
        .map((h) => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.text}`)
        .join('\n');

      const prompt = `${systemInstruction}\n\nRecent Conversation:\n${conversationContext}\n\nAssistant Response:`;

      const aiResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      const replyText = aiResponse.text || "Thank you for reaching out. How else can we help you plan your digital solution?";

      session.history.push({
        role: 'model',
        text: replyText,
        timestamp: new Date().toISOString(),
      });

      return res.json({
        sessionId: sid,
        reply: replyText,
        model: 'gemini-2.5-flash',
      });
    } catch (err: any) {
      console.warn('[AI Chatbot] Gemini API error, falling back to knowledge engine:', err.message);
    }
  }

  // Fallback Rule-Based Knowledge Engine
  const q = message.toLowerCase();
  const cms = db.getCMSContent();
  const packages = db.getServicePackages();

  let fallbackReply = `Thank you for reaching out to ${cms.brand.name}. We specialize in high-performance websites, AI workflow automation, e-commerce stores, and custom operations admin panels. Would you like to explore our service packages or discuss a project scope?`;

  if (q.includes('price') || q.includes('cost') || q.includes('package') || q.includes('rate')) {
    const pkgList = packages.map((p) => `• ${p.title}: from $${p.startingPrice} (${p.turnaround})`).join('\n');
    fallbackReply = `Our service packages start at transparent baseline rates:\n\n${pkgList}\n\nEvery project includes fixed milestones and dedicated senior engineering. Would you like a custom quotation for your specific requirements?`;
  } else if (q.includes('timeline') || q.includes('how long') || q.includes('turnaround') || q.includes('weeks')) {
    fallbackReply = `Most custom builds are completed in 3 to 7 weeks. For instance, website flagships take ~3–4 weeks, while complex AI automation pipelines or admin dashboards span 4–6 weeks. We provide weekly staging demos throughout.`;
  } else if (q.includes('ai') || q.includes('automation') || q.includes('workflow')) {
    fallbackReply = `Our AI Automation practice builds practical pipelines: automated document extraction, intelligent customer inquiry routing, and custom LLM reasoning connected to your existing databases and APIs.`;
  } else if (q.includes('quote') || q.includes('hire') || q.includes('start') || q.includes('contact') || q.includes('project')) {
    fallbackReply = `We'd love to explore your project! You can submit an enquiry directly through our website form, or share your name, work email, and brief here and I will register it with our senior engineering team.`;
  } else {
    // Check FAQs
    const matchedFaq = cms.faqs.find((f) => q.includes(f.category.toLowerCase()) || f.question.toLowerCase().split(' ').some((word) => word.length > 4 && q.includes(word)));
    if (matchedFaq) {
      fallbackReply = `${matchedFaq.answer}\n\nFeel free to ask for more details or submit a project scope.`;
    }
  }

  session.history.push({
    role: 'model',
    text: fallbackReply,
    timestamp: new Date().toISOString(),
  });

  return res.json({
    sessionId: sid,
    reply: fallbackReply,
    model: 'knowledge-base-fallback',
  });
});

// Capture lead from chat with consent and route to CRM
chatRouter.post('/capture-inquiry', (req: Request, res: Response) => {
  const { name, email, service, projectDescription, consent } = req.body;

  if (!consent) {
    return res.status(400).json({ error: 'User consent is required to register an inquiry.' });
  }

  if (!name || !email || !projectDescription) {
    return res.status(400).json({ error: 'Name, email, and project description are required.' });
  }

  const inquiryId = `AIS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const now = new Date().toISOString();

  const newInquiry: Inquiry = {
    id: inquiryId,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    service: service || 'Website Development',
    projectDescription: projectDescription.trim(),
    privacyConsent: true,
    source: 'ai_chatbot',
    status: 'New',
    notes: [
      {
        id: `note_chat_init`,
        authorId: 'ai_chatbot_agent',
        authorName: 'AI Studio Consultant',
        text: 'Lead captured interactively through the AI Studio Chatbot widget with explicit user consent.',
        createdAt: now,
      },
    ],
    tags: ['AI Chatbot Lead'],
    createdAt: now,
    updatedAt: now,
  };

  const inquiries = db.getInquiries();
  inquiries.unshift(newInquiry);
  db.saveInquiries(inquiries);

  db.logAudit(
    { id: 'chatbot_system', name: 'AI Chatbot Agent', role: 'staff' },
    'INQUIRY_CAPTURED_CHATBOT',
    'inquiry',
    `Captured enquiry ${inquiryId} from ${newInquiry.name} (${newInquiry.email})`,
    inquiryId,
    req.ip
  );

  return res.status(201).json({
    success: true,
    enquiryId: inquiryId,
    message: 'Your project enquiry has been registered with our engineering team. We will review your scope and get in touch within 24 hours.',
  });
});
