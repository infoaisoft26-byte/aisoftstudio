import { Router, Response } from 'express';
import { db } from '../db/store';
import { authenticate, requireRole, AuthenticatedRequest } from '../auth';
import { ConversationThread, ConversationMessage, NotificationTemplate } from '../db/types';

export const conversationRouter = Router();

// ==========================================
// 1. CUSTOMER CONVERSATIONS & CHAT THREADS
// ==========================================

conversationRouter.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let threads = db.getConversations();

  if (user.role === 'client') {
    threads = threads.filter(
      (t) =>
        t.customerContact.toLowerCase() === user.email.toLowerCase() ||
        t.customerName.toLowerCase().includes(user.name.toLowerCase())
    );
  }

  return res.json({ count: threads.length, threads });
});

// Staff Reply to Thread
conversationRouter.post(
  '/:id/reply',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: 'Reply text is required.' });
    }

    const threads = db.getConversations();
    const idx = threads.findIndex((t) => t.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Conversation thread not found.' });

    const msg: ConversationMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      sender: 'staff',
      senderName: req.user!.name,
      channel: threads[idx].channel,
      text: text.trim(),
      timestamp: new Date().toISOString(),
    };

    threads[idx].messages.push(msg);
    threads[idx].lastActivity = msg.timestamp;
    threads[idx].status = 'resolved';
    db.saveConversations(threads);

    db.logAudit(
      req.user!,
      'CONVERSATION_REPLY',
      'conversation',
      `Sent staff reply on thread ${id} to ${threads[idx].customerName}`,
      id,
      req.ip
    );

    return res.json({ success: true, message: msg, thread: threads[idx] });
  }
);

// ==========================================
// 2. NOTIFICATIONS & EMAIL TEMPLATES
// ==========================================

conversationRouter.get('/templates', authenticate, requireRole(['super_admin', 'staff']), (_req, res: Response) => {
  let templates = db.getNotificationTemplates();
  if (templates.length === 0) {
    // Seed standard templates
    templates = [
      {
        id: 'tmpl_inquiry_ack',
        name: 'Inquiry Confirmation & Tracking',
        trigger: 'inquiry.created',
        channel: 'email',
        subject: 'Thank you for contacting AI SOFT STUDIO [Ref: {{inquiryId}}]',
        body: 'Hello {{customerName}},\n\nWe have received your project brief for {{serviceName}}. Our engineering team will review your specifications and follow up within 24 business hours.\n\nReference ID: {{inquiryId}}\n\nWarm regards,\nAI SOFT STUDIO Technical Team',
        variables: ['customerName', 'inquiryId', 'serviceName'],
        active: true,
      },
      {
        id: 'tmpl_quotation_ready',
        name: 'Quotation Ready for Review',
        trigger: 'quotation.sent',
        channel: 'email',
        subject: 'Quotation Ready for Review: {{quotationId}} — AI SOFT STUDIO',
        body: 'Hello {{customerName}},\n\nYour custom proposal and statement of work {{quotationId}} totaling ${{amount}} is ready for your review and approval.\n\nLink: {{proposalUrl}}\n\nBest regards,\nAI SOFT STUDIO Operations',
        variables: ['customerName', 'quotationId', 'amount', 'proposalUrl'],
        active: true,
      },
      {
        id: 'tmpl_payment_verified',
        name: 'Payment Receipt Confirmation',
        trigger: 'payment.verified',
        channel: 'email',
        subject: 'Payment Verified: Receipt {{paymentId}} — AI SOFT STUDIO',
        body: 'Hello {{customerName}},\n\nYour payment of ${{amount}} for Invoice {{invoiceId}} has been verified through Razorpay.\n\nTransaction Reference: {{txRef}}\n\nThank you for choosing AI SOFT STUDIO.',
        variables: ['customerName', 'paymentId', 'invoiceId', 'amount', 'txRef'],
        active: true,
      },
      {
        id: 'tmpl_security_auth',
        name: 'Written Security Authorization Protocol',
        trigger: 'security.authorization_requested',
        channel: 'email',
        subject: 'Scope & Written Authorization Request [Ref: {{assessmentId}}]',
        body: 'Hello {{customerName}},\n\nTo conduct lawful security review on {{targetSystem}}, please sign and return the explicit written authorization statement.\n\nBest,\nAI SOFT STUDIO Security Team',
        variables: ['customerName', 'assessmentId', 'targetSystem'],
        active: true,
      },
    ];
    db.saveNotificationTemplates(templates);
  }

  return res.json({ templates });
});

conversationRouter.patch(
  '/templates/:id',
  authenticate,
  requireRole(['super_admin']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { subject, body, active } = req.body;

    const templates = db.getNotificationTemplates();
    const idx = templates.findIndex((t) => t.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Template not found.' });

    if (subject) templates[idx].subject = subject;
    if (body) templates[idx].body = body;
    if (active !== undefined) templates[idx].active = Boolean(active);

    db.saveNotificationTemplates(templates);

    db.logAudit(
      req.user!,
      'NOTIFICATION_TEMPLATE_UPDATED',
      'notification',
      `Updated template ${id} (${templates[idx].name})`,
      id,
      req.ip
    );

    return res.json({ success: true, template: templates[idx] });
  }
);
