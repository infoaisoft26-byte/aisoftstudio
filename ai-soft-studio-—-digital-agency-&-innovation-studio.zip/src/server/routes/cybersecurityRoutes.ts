import { Router, Response } from 'express';
import { db } from '../db/store';
import { authenticate, requireRole, AuthenticatedRequest } from '../auth';
import { SecurityAssessment, SecurityFinding } from '../db/types';

export const cybersecurityRouter = Router();

// List Security Assessments
cybersecurityRouter.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let list = db.getSecurityAssessments();

  if (user.role === 'client') {
    // Clients only see assessments where they are the authorized entity
    list = list.filter(
      (a) =>
        a.authorizedBy.toLowerCase() === user.email.toLowerCase() ||
        a.authorizedBy.toLowerCase().includes(user.name.toLowerCase())
    );
  } else if (user.role === 'developer') {
    // Developers see assessments assigned to them
    list = list.filter((a) => a.assignedLeadId === user.id);
  }

  return res.json({ count: list.length, assessments: list });
});

// Get Single Assessment
cybersecurityRouter.get('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const assessment = db.getSecurityAssessmentById(req.params.id);
  if (!assessment) return res.status(404).json({ error: 'Security assessment record not found.' });

  const user = req.user!;
  if (user.role === 'client') {
    if (
      assessment.authorizedBy.toLowerCase() !== user.email.toLowerCase() &&
      !assessment.authorizedBy.toLowerCase().includes(user.name.toLowerCase())
    ) {
      return res.status(403).json({ error: 'Access denied to this security assessment.' });
    }
  }

  return res.json({ assessment });
});

// Create Security Assessment Workflow (Requires Written Authorization Verification)
cybersecurityRouter.post(
  '/',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const {
      title,
      targetSystem,
      assessmentType,
      authorizedBy,
      authorizationDocumentRef,
      scopeDefinition,
      assignedLeadId,
    } = req.body;

    if (!title || !targetSystem || !assessmentType || !authorizedBy || !scopeDefinition) {
      return res.status(400).json({
        error:
          'Title, target system, assessment type, authorized client contact, and written scope definition are required for all cybersecurity reviews.',
      });
    }

    // Require authorization document reference before marking authorization verified
    const authStatus =
      authorizationDocumentRef && authorizationDocumentRef.trim().length > 3
        ? 'Authorization Verified'
        : 'Pending Written Authorization';

    const assignedUser = assignedLeadId ? db.getUserById(assignedLeadId) : undefined;
    const assessmentId = `SEC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    const newAssessment: SecurityAssessment = {
      id: assessmentId,
      title: title.trim(),
      targetSystem: targetSystem.trim(),
      assessmentType,
      authorizationStatus: authStatus,
      authorizationDocumentRef: authorizationDocumentRef?.trim() || 'Pending Document Submission',
      authorizedBy: authorizedBy.trim(),
      scopeDefinition: scopeDefinition.trim(),
      assignedLeadId: assignedUser?.id,
      assignedLeadName: assignedUser?.name,
      status: authStatus === 'Authorization Verified' ? 'In Progress' : 'Authorization Pending',
      findings: [],
      createdAt: now,
      updatedAt: now,
    };

    const all = db.getSecurityAssessments();
    all.unshift(newAssessment);
    db.saveSecurityAssessments(all);

    db.logAudit(
      req.user!,
      'SECURITY_ASSESSMENT_CREATED',
      'cybersecurity',
      `Registered security assessment ${assessmentId} for "${targetSystem}". Auth Status: ${authStatus}`,
      assessmentId,
      req.ip
    );

    return res.status(201).json({ success: true, assessment: newAssessment });
  }
);

// Update Assessment / Authorization Verification Status
cybersecurityRouter.patch(
  '/:id',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const {
      authorizationStatus,
      authorizationDocumentRef,
      scopeDefinition,
      status,
      assignedLeadId,
      executiveSummary,
    } = req.body;

    const all = db.getSecurityAssessments();
    const idx = all.findIndex((a) => a.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Assessment not found.' });

    const current = all[idx];

    if (authorizationStatus) current.authorizationStatus = authorizationStatus;
    if (authorizationDocumentRef) current.authorizationDocumentRef = authorizationDocumentRef.trim();
    if (scopeDefinition) current.scopeDefinition = scopeDefinition.trim();
    if (status) current.status = status;
    if (executiveSummary !== undefined) current.executiveSummary = executiveSummary;

    if (assignedLeadId !== undefined) {
      const dev = assignedLeadId ? db.getUserById(assignedLeadId) : null;
      current.assignedLeadId = dev?.id;
      current.assignedLeadName = dev?.name;
    }

    current.updatedAt = new Date().toISOString();
    db.saveSecurityAssessments(all);

    db.logAudit(
      req.user!,
      'SECURITY_ASSESSMENT_UPDATED',
      'cybersecurity',
      `Updated security assessment ${id} (${current.status}, Auth: ${current.authorizationStatus})`,
      id,
      req.ip
    );

    return res.json({ success: true, assessment: current });
  }
);

// Add / Update Security Finding (Vulnerability record)
cybersecurityRouter.post(
  '/:id/findings',
  authenticate,
  requireRole(['super_admin', 'staff', 'developer']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const {
      title,
      severity,
      category,
      targetEndpoint,
      description,
      impact,
      remediation,
      status,
    } = req.body;

    if (!title || !severity || !description || !remediation) {
      return res.status(400).json({
        error: 'Title, severity level (Critical, High, Medium, Low, Info), description, and remediation recommendations are required.',
      });
    }

    const all = db.getSecurityAssessments();
    const idx = all.findIndex((a) => a.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Assessment not found.' });

    const finding: SecurityFinding = {
      id: `vuln_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      severity: severity || 'Medium',
      category: category || 'Configuration / Access Control',
      targetEndpoint: targetEndpoint?.trim() || 'N/A',
      description: description.trim(),
      impact: impact?.trim() || 'Unauthorized resource interaction or data disclosure',
      remediation: remediation.trim(),
      status: status || 'Open',
      discoveredAt: new Date().toISOString(),
    };

    all[idx].findings.unshift(finding);
    all[idx].updatedAt = new Date().toISOString();
    db.saveSecurityAssessments(all);

    db.logAudit(
      req.user!,
      'SECURITY_FINDING_RECORDED',
      'cybersecurity',
      `Recorded ${finding.severity} finding "${finding.title}" on assessment ${id}`,
      id,
      req.ip
    );

    return res.status(201).json({ success: true, finding, assessment: all[idx] });
  }
);
