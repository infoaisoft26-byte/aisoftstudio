import { Router, Response } from 'express';
import { db } from '../db/store';
import { authenticate, AuthenticatedRequest } from '../auth';
import { Project, ProjectStatus, Milestone, Task, Deliverable } from '../db/types';

export const projectRouter = Router();

// List Projects (Filtered by Role)
projectRouter.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const allProjects = db.getProjects();

  let filtered: Project[] = [];

  if (user.role === 'super_admin' || user.role === 'staff') {
    filtered = allProjects;
  } else if (user.role === 'developer') {
    // Developers only see projects they are assigned to
    filtered = allProjects.filter((p) => p.assignedDeveloperIds.includes(user.id));
  } else if (user.role === 'client') {
    // Clients only see their own projects
    filtered = allProjects.filter((p) => p.clientId === user.id || p.clientEmail.toLowerCase() === user.email.toLowerCase());
  }

  return res.json({ count: filtered.length, projects: filtered });
});

// Get Single Project
projectRouter.get('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const project = db.getProjectById(req.params.id);

  if (!project) return res.status(404).json({ error: 'Project not found.' });

  // Access validation
  if (user.role === 'client' && project.clientId !== user.id && project.clientEmail.toLowerCase() !== user.email.toLowerCase()) {
    return res.status(403).json({ error: 'Access denied to this project.' });
  }

  if (user.role === 'developer' && !project.assignedDeveloperIds.includes(user.id)) {
    return res.status(403).json({ error: 'Access denied. You are not assigned to this project.' });
  }

  // Also fetch tasks for this project
  const tasks = db.getTasks().filter((t) => t.projectId === project.id);

  return res.json({ project, tasks });
});

// Admin/Staff: Create Project
projectRouter.post('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  if (user.role !== 'super_admin' && user.role !== 'staff') {
    return res.status(403).json({ error: 'Only admins and staff can create projects.' });
  }

  const { name, clientId, clientName, clientEmail, service, budget, deadline, description, assignedDeveloperIds } = req.body;

  if (!name || !service) {
    return res.status(400).json({ error: 'Project name and service are required.' });
  }

  const projectId = `PRJ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const now = new Date().toISOString();

  const newProject: Project = {
    id: projectId,
    name: name.trim(),
    clientId: clientId || 'usr_client_forma',
    clientName: clientName?.trim() || 'Elena Rostova',
    clientEmail: clientEmail?.trim() || 'client@forma.com',
    assignedDeveloperIds: Array.isArray(assignedDeveloperIds) ? assignedDeveloperIds : [],
    service: service.trim(),
    status: 'Planning',
    startDate: now.split('T')[0],
    deadline: deadline || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    budget: Number(budget) || 4500,
    progress: 0,
    description: description?.trim() || '',
    milestones: [
      {
        id: `ms_${Date.now()}_1`,
        projectId,
        title: '01. Architecture & Design Specification',
        description: 'Bespoke design tokens, responsive wireframes, API contracts.',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'In Progress',
        deliverables: ['UI Specifications', 'Architecture Document'],
        approvedByClient: false,
      },
    ],
    deliverables: [],
    createdAt: now,
    updatedAt: now,
  };

  const projects = db.getProjects();
  projects.unshift(newProject);
  db.saveProjects(projects);

  db.logAudit(user, 'PROJECT_CREATED', 'project', `Created project ${newProject.id}: ${newProject.name}`, newProject.id, req.ip);

  return res.status(201).json({ success: true, project: newProject });
});

// Update Project (Admin/Staff for all, Developer for assigned status/progress)
projectRouter.patch('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { status, progress, deadline, budget, repositoryUrl, stagingUrl, assignedDeveloperIds } = req.body;

  const projects = db.getProjects();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Project not found.' });

  const project = projects[idx];

  if (user.role === 'client') {
    return res.status(403).json({ error: 'Clients cannot update project configurations.' });
  }

  if (user.role === 'developer' && !project.assignedDeveloperIds.includes(user.id)) {
    return res.status(403).json({ error: 'Not assigned to this project.' });
  }

  const changes: string[] = [];

  if (status && status !== project.status) {
    changes.push(`status: ${project.status} -> ${status}`);
    project.status = status as ProjectStatus;
  }

  if (progress !== undefined && progress !== project.progress) {
    const num = Math.min(100, Math.max(0, Number(progress)));
    changes.push(`progress: ${project.progress}% -> ${num}%`);
    project.progress = num;
  }

  // Admin/Staff only edits
  if (user.role === 'super_admin' || user.role === 'staff') {
    if (deadline) project.deadline = deadline;
    if (budget !== undefined) project.budget = Number(budget);
    if (repositoryUrl !== undefined) project.repositoryUrl = repositoryUrl;
    if (stagingUrl !== undefined) project.stagingUrl = stagingUrl;
    if (Array.isArray(assignedDeveloperIds)) project.assignedDeveloperIds = assignedDeveloperIds;
  }

  project.updatedAt = new Date().toISOString();
  db.saveProjects(projects);

  if (changes.length > 0) {
    db.logAudit(user, 'PROJECT_UPDATED', 'project', `Updated project ${project.id}: ${changes.join(', ')}`, project.id, req.ip);
  }

  return res.json({ success: true, project });
});

// Milestones Management
projectRouter.post('/:id/milestones', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  if (user.role !== 'super_admin' && user.role !== 'staff') {
    return res.status(403).json({ error: 'Only admins and staff can add milestones.' });
  }

  const { title, description, dueDate, deliverables } = req.body;
  if (!title || !dueDate) {
    return res.status(400).json({ error: 'Title and due date are required.' });
  }

  const projects = db.getProjects();
  const idx = projects.findIndex((p) => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Project not found.' });

  const newMilestone: Milestone = {
    id: `ms_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    projectId: req.params.id,
    title: title.trim(),
    description: description?.trim() || '',
    dueDate,
    status: 'Pending',
    deliverables: Array.isArray(deliverables) ? deliverables : [],
    approvedByClient: false,
  };

  projects[idx].milestones.push(newMilestone);
  projects[idx].updatedAt = new Date().toISOString();
  db.saveProjects(projects);

  db.logAudit(user, 'MILESTONE_ADDED', 'project', `Added milestone "${title}" to project ${req.params.id}`, req.params.id, req.ip);

  return res.status(201).json({ success: true, milestone: newMilestone });
});

// Client: Approve Milestone
projectRouter.post('/:id/milestones/:mId/approve', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id, mId } = req.params;

  const projects = db.getProjects();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Project not found.' });

  const project = projects[idx];
  if (user.role === 'client' && project.clientId !== user.id && project.clientEmail.toLowerCase() !== user.email.toLowerCase()) {
    return res.status(403).json({ error: 'Access denied.' });
  }

  const msIdx = project.milestones.findIndex((m) => m.id === mId);
  if (msIdx === -1) return res.status(404).json({ error: 'Milestone not found.' });

  project.milestones[msIdx].approvedByClient = true;
  project.milestones[msIdx].status = 'Completed';
  project.milestones[msIdx].completedAt = new Date().toISOString();
  project.updatedAt = new Date().toISOString();

  // Recalculate progress based on completed milestones
  const completedCount = project.milestones.filter((m) => m.status === 'Completed').length;
  project.progress = Math.round((completedCount / project.milestones.length) * 100);

  db.saveProjects(projects);

  db.logAudit(user, 'MILESTONE_APPROVED', 'project', `Approved milestone ${mId} on project ${id}`, id, req.ip);

  return res.json({ success: true, project });
});

// Deliverables Upload / Link
projectRouter.post('/:id/deliverables', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { title, url, fileType } = req.body;

  if (!title || !url) {
    return res.status(400).json({ error: 'Title and URL are required.' });
  }

  const projects = db.getProjects();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Project not found.' });

  const project = projects[idx];

  // Developer or Staff/Admin allowed
  if (user.role === 'developer' && !project.assignedDeveloperIds.includes(user.id)) {
    return res.status(403).json({ error: 'Not assigned to this project.' });
  }
  if (user.role === 'client') {
    return res.status(403).json({ error: 'Clients cannot post developer deliverables.' });
  }

  const newDeliverable: Deliverable = {
    id: `deliv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    projectId: id,
    title: title.trim(),
    fileType: fileType || 'Architecture / Code',
    url: url.trim(),
    uploadedBy: user.id,
    uploadedByName: user.name,
    approvedByClient: false,
    createdAt: new Date().toISOString(),
  };

  project.deliverables.unshift(newDeliverable);
  project.updatedAt = new Date().toISOString();
  db.saveProjects(projects);

  db.logAudit(user, 'DELIVERABLE_UPLOADED', 'project', `Uploaded deliverable "${title}" for project ${id}`, id, req.ip);

  return res.status(201).json({ success: true, deliverable: newDeliverable });
});

// Tasks Endpoints (for Project Sprints)
projectRouter.get('/:id/tasks', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const tasks = db.getTasks().filter((t) => t.projectId === req.params.id);
  return res.json({ tasks });
});

projectRouter.post('/:id/tasks', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { title, description, assignedTo, priority, dueDate } = req.body;

  if (user.role !== 'super_admin' && user.role !== 'staff' && user.role !== 'developer') {
    return res.status(403).json({ error: 'Not authorized to create tasks.' });
  }

  if (!title) return res.status(400).json({ error: 'Task title is required.' });

  const assignedUser = assignedTo ? db.getUserById(assignedTo) : null;
  const now = new Date().toISOString();

  const newTask: Task = {
    id: `tsk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    projectId: id,
    title: title.trim(),
    description: description?.trim() || '',
    assignedTo: assignedTo || user.id,
    assignedToName: assignedUser ? assignedUser.name : user.name,
    status: 'To Do',
    priority: priority || 'Medium',
    dueDate,
    progressNotes: [],
    createdAt: now,
    updatedAt: now,
  };

  const tasks = db.getTasks();
  tasks.unshift(newTask);
  db.saveTasks(tasks);

  db.logAudit(user, 'TASK_CREATED', 'task', `Created task "${title}" on project ${id}`, newTask.id, req.ip);

  return res.status(201).json({ success: true, task: newTask });
});

// Update Task Status / Progress Notes
projectRouter.patch('/tasks/:taskId', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { taskId } = req.params;
  const { status, noteText } = req.body;

  const tasks = db.getTasks();
  const idx = tasks.findIndex((t) => t.id === taskId);
  if (idx === -1) return res.status(404).json({ error: 'Task not found.' });

  const task = tasks[idx];

  if (user.role === 'client') {
    return res.status(403).json({ error: 'Clients cannot update internal tasks.' });
  }

  const changes: string[] = [];
  if (status && status !== task.status) {
    changes.push(`status: ${task.status} -> ${status}`);
    task.status = status;
  }

  if (noteText && typeof noteText === 'string' && noteText.trim()) {
    task.progressNotes.unshift({
      id: `pnote_${Date.now()}`,
      authorId: user.id,
      authorName: user.name,
      text: noteText.trim(),
      createdAt: new Date().toISOString(),
    });
  }

  task.updatedAt = new Date().toISOString();
  db.saveTasks(tasks);

  if (changes.length > 0) {
    db.logAudit(user, 'TASK_UPDATED', 'task', `Updated task ${taskId}: ${changes.join(', ')}`, taskId, req.ip);
  }

  return res.json({ success: true, task });
});
