import { Router, Request, Response } from 'express';
import { db } from '../db/store';
import { authenticate, requireRole, optionalAuth, AuthenticatedRequest } from '../auth';
import { Inquiry, InquiryStatus, InquirySource, Project } from '../db/types';

export const inquiryRouter = Router();

// Simple in-memory rate limiter for public inquiry form
const submissionHistory = new Map<string, number>();

// Public Endpoint: Submit Inquiry (from Website Form, Scope Estimator, or Chatbot)
inquiryRouter.post('/', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  const ip = req.ip || '127.0.0.1';
  const now = Date.now();
  const lastTime = submissionHistory.get(ip);
  if (lastTime && now - lastTime < 3000) {
    return res.status(429).json({ error: 'Please wait a moment before submitting another enquiry.' });
  }
  submissionHistory.set(ip, now);

  const {
    name,
    email,
    phone,
    businessName,
    companyName,
    service,
    projectDescription,
    timeline,
    estimatedBudget,
    budgetRange,
    preferredContactMethod,
    privacyConsent,
    source,
    tags,
    website_url, // Honeypot spam trap
  } = req.body;

  // Spam protection: honeypot field
  if (website_url && String(website_url).trim().length > 0) {
    // Silently drop bot submission
    return res.status(200).json({
      success: true,
      enquiryId: `AIS-${new Date().getFullYear()}-0000`,
      message: 'Your inquiry has been received.',
    });
  }

  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    return res.status(400).json({ error: 'Please provide a valid name (at least 2 characters).' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || typeof email !== 'string' || !emailRegex.test(email.trim())) {
    return res.status(400).json({ error: 'Please provide a valid business email address.' });
  }

  if (!service || typeof service !== 'string') {
    return res.status(400).json({ error: 'Please specify the required service.' });
  }

  if (!projectDescription || typeof projectDescription !== 'string' || projectDescription.trim().length < 10) {
    return res.status(400).json({ error: 'Please provide a project description (at least 10 characters).' });
  }

  const cleanSource: InquirySource =
    source && ['website_form', 'scope_estimator', 'ai_chatbot', 'meta_leadgen', 'meta_whatsapp', 'meta_messenger'].includes(source)
      ? source
      : 'website_form';

  const enquiryId = `AIS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const timestamp = new Date().toISOString();
  const effectiveCompany = (companyName || businessName || '').trim() || undefined;

  const newInquiry: Inquiry = {
    id: enquiryId,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    phone: phone ? String(phone).trim() : undefined,
    businessName: effectiveCompany,
    companyName: effectiveCompany,
    service: service.trim(),
    projectDescription: projectDescription.trim(),
    timeline: timeline ? String(timeline).trim() : undefined,
    estimatedBudget: (budgetRange || estimatedBudget) ? String(budgetRange || estimatedBudget).trim() : undefined,
    budgetRange: (budgetRange || estimatedBudget) ? String(budgetRange || estimatedBudget).trim() : undefined,
    preferredContactMethod: ['Email', 'Phone', 'WhatsApp'].includes(preferredContactMethod)
      ? preferredContactMethod
      : 'Email',
    privacyConsent: Boolean(privacyConsent ?? true),
    source: cleanSource,
    status: 'New',
    notes: [],
    tags: Array.isArray(tags) ? tags : [cleanSource.replace('_', ' ')],
    createdAt: timestamp,
    updatedAt: timestamp,
  };

  const inquiries = db.getInquiries();
  inquiries.unshift(newInquiry);
  db.saveInquiries(inquiries);

  // Log audit if authenticated or anonymous
  db.logAudit(
    req.user || { id: 'public_lead', name: newInquiry.name, role: 'client' },
    'INQUIRY_RECEIVED',
    'inquiry',
    `New inquiry ${newInquiry.id} submitted for ${newInquiry.service} via ${cleanSource}`,
    newInquiry.id,
    ip
  );

  return res.status(201).json({
    success: true,
    enquiryId: newInquiry.id,
    createdAt: newInquiry.createdAt,
    message: 'Your project enquiry has been registered with the AI SOFT STUDIO technical team. We will review your requirements and respond within 24 hours.',
  });
});

// Admin/Staff: List inquiries with filters
inquiryRouter.get(
  '/',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const { status, search, service } = req.query;
    let list = db.getInquiries();

    if (status && typeof status === 'string' && status !== 'All') {
      list = list.filter((i) => i.status === status);
    }

    if (service && typeof service === 'string' && service !== 'All') {
      list = list.filter((i) => i.service.toLowerCase().includes(service.toLowerCase()));
    }

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      list = list.filter(
        (i) =>
          i.id.toLowerCase().includes(q) ||
          i.name.toLowerCase().includes(q) ||
          i.email.toLowerCase().includes(q) ||
          (i.businessName && i.businessName.toLowerCase().includes(q))
      );
    }

    return res.json({ count: list.length, inquiries: list });
  }
);

// Admin/Staff: Get single inquiry
inquiryRouter.get(
  '/:id',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const inquiry = db.getInquiryById(req.params.id);
    if (!inquiry) return res.status(404).json({ error: 'Inquiry not found.' });
    return res.json({ inquiry });
  }
);

// Admin/Staff: Update inquiry status / assignment / follow-up
inquiryRouter.patch(
  '/:id',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { status, assignedTo, followUpDate, tags } = req.body;

    const inquiries = db.getInquiries();
    const idx = inquiries.findIndex((i) => i.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Inquiry not found.' });

    const current = inquiries[idx];
    const changes: string[] = [];

    if (status && status !== current.status) {
      changes.push(`status: ${current.status} -> ${status}`);
      current.status = status as InquiryStatus;
    }

    if (assignedTo !== undefined) {
      const staffUser = assignedTo ? db.getUserById(assignedTo) : null;
      current.assignedTo = assignedTo || undefined;
      current.assignedToName = staffUser ? staffUser.name : undefined;
      changes.push(`assigned to: ${staffUser ? staffUser.name : 'Unassigned'}`);
    }

    if (followUpDate !== undefined) {
      current.followUpDate = followUpDate || undefined;
      changes.push(`follow-up date set: ${followUpDate || 'Cleared'}`);
    }

    if (Array.isArray(tags)) {
      current.tags = tags;
    }

    current.updatedAt = new Date().toISOString();
    db.saveInquiries(inquiries);

    if (changes.length > 0) {
      db.logAudit(
        req.user!,
        'INQUIRY_UPDATED',
        'inquiry',
        `Updated inquiry ${current.id}: ${changes.join(', ')}`,
        current.id,
        req.ip
      );
    }

    return res.json({ success: true, inquiry: current });
  }
);

// Admin/Staff: Add internal note to inquiry
inquiryRouter.post(
  '/:id/notes',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { text } = req.body;

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: 'Note text is required.' });
    }

    const inquiries = db.getInquiries();
    const idx = inquiries.findIndex((i) => i.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Inquiry not found.' });

    const note = {
      id: `note_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      authorId: req.user!.id,
      authorName: req.user!.name,
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };

    inquiries[idx].notes.unshift(note);
    inquiries[idx].updatedAt = new Date().toISOString();
    db.saveInquiries(inquiries);

    db.logAudit(
      req.user!,
      'INQUIRY_NOTE_ADDED',
      'inquiry',
      `Added note to inquiry ${id}: "${text.trim().substring(0, 50)}..."`,
      id,
      req.ip
    );

    return res.status(201).json({ success: true, note, notes: inquiries[idx].notes });
  }
);

// Admin/Staff: Convert Inquiry to Project
inquiryRouter.post(
  '/:id/convert-to-project',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (req: AuthenticatedRequest, res: Response) => {
    const { id } = req.params;
    const { projectName, clientId, budget, deadline, assignedDeveloperIds } = req.body;

    const inquiry = db.getInquiryById(id);
    if (!inquiry) return res.status(404).json({ error: 'Inquiry not found.' });

    // Find client
    let targetClientId = clientId;
    let targetClient = targetClientId ? db.getUserById(targetClientId) : null;

    if (!targetClient) {
      // Find or create client by email
      targetClient = db.getUserByEmail(inquiry.email);
      if (!targetClient) {
        // Create new client user
        const newClient = {
          id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          name: inquiry.name,
          email: inquiry.email,
          passwordHash: '', // Can set password via invite
          salt: '',
          role: 'client' as const,
          businessName: inquiry.businessName,
          phone: inquiry.phone,
          status: 'active' as const,
          createdAt: new Date().toISOString(),
        };
        const users = db.getUsers();
        users.push(newClient);
        db.saveUsers(users);
        targetClient = newClient;
      }
      targetClientId = targetClient.id;
    }

    const projectId = `PRJ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    const newProject: Project = {
      id: projectId,
      name: projectName?.trim() || `${inquiry.service} for ${inquiry.businessName || inquiry.name}`,
      inquiryId: inquiry.id,
      clientId: targetClient.id,
      clientName: targetClient.name,
      clientEmail: targetClient.email,
      assignedDeveloperIds: Array.isArray(assignedDeveloperIds) ? assignedDeveloperIds : [],
      service: inquiry.service,
      status: 'Planning',
      startDate: now.split('T')[0],
      deadline: deadline || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      budget: Number(budget) || 5000,
      progress: 0,
      description: inquiry.projectDescription,
      milestones: [
        {
          id: `ms_${Date.now()}_1`,
          projectId,
          title: '01. Architecture & Design Specification',
          description: 'Initial architectural review, user journeys and visual design prototype.',
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          status: 'In Progress',
          deliverables: ['System Blueprint', 'UI Tokens & Wireframes'],
          approvedByClient: false,
        },
        {
          id: `ms_${Date.now()}_2`,
          projectId,
          title: '02. Core Platform Development',
          description: 'Implementation of primary functional components, databases and APIs.',
          dueDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          status: 'Pending',
          deliverables: ['Staging Environment Release', 'Integration Test Suite'],
          approvedByClient: false,
        },
      ],
      deliverables: [],
      createdAt: now,
      updatedAt: now,
    };

    const projects = db.getProjects();
    projects.unshift(newProject);
    db.saveProjects(projects);

    // Update inquiry status
    const inquiries = db.getInquiries();
    const inqIdx = inquiries.findIndex((i) => i.id === id);
    if (inqIdx !== -1) {
      inquiries[inqIdx].status = 'In Progress';
      inquiries[inqIdx].convertedProjectId = projectId;
      inquiries[inqIdx].updatedAt = now;
      db.saveInquiries(inquiries);
    }

    db.logAudit(
      req.user!,
      'INQUIRY_CONVERTED_PROJECT',
      'project',
      `Converted inquiry ${inquiry.id} to new Project ${projectId} (${newProject.name})`,
      projectId,
      req.ip
    );

    return res.status(201).json({ success: true, project: newProject });
  }
);

// Admin/Staff: Export Authorized Inquiries as CSV
inquiryRouter.get(
  '/export/csv',
  authenticate,
  requireRole(['super_admin', 'staff']),
  (_req: AuthenticatedRequest, res: Response) => {
    const list = db.getInquiries();
    const headers = [
      'ID',
      'Name',
      'Email',
      'Phone',
      'Company',
      'Service',
      'Status',
      'Budget',
      'Timeline',
      'Preferred Contact',
      'Source',
      'Created At',
    ];

    const rows = list.map((i) => [
      i.id,
      `"${(i.name || '').replace(/"/g, '""')}"`,
      i.email,
      i.phone || '',
      `"${(i.companyName || i.businessName || '').replace(/"/g, '""')}"`,
      `"${(i.service || '').replace(/"/g, '""')}"`,
      i.status,
      i.budgetRange || i.estimatedBudget || '',
      i.timeline || '',
      i.preferredContactMethod || 'Email',
      i.source,
      i.createdAt,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="aisoft_inquiries_${new Date().toISOString().split('T')[0]}.csv"`
    );
    return res.send(csvContent);
  }
);

