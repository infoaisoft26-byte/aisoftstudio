import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { BackgroundAtmosphere } from './components/BackgroundAtmosphere';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { BusinessSolutions } from './components/BusinessSolutions';
import { SelectedWork } from './components/SelectedWork';
import { CreativeProcess } from './components/CreativeProcess';
import { WhyUs } from './components/WhyUs';
import { FAQ } from './components/FAQ';
import { FinalCTA } from './components/FinalCTA';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { CustomCursor } from './components/CustomCursor';
import { ScopeEstimate } from './components/ScopeEstimator';
import { WebsiteChatWidget } from './components/chat/WebsiteChatWidget';
import { LoginModal } from './components/admin/LoginModal';
import { AdminLayout, AdminTab } from './components/admin/AdminLayout';
import { DashboardOverview } from './components/admin/DashboardOverview';
import { InquiryCRM } from './components/admin/InquiryCRM';
import { ProjectHub } from './components/admin/ProjectHub';
import { FinanceHub } from './components/admin/FinanceHub';
import { MetaCenter } from './components/admin/MetaCenter';
import { WebsiteCMS } from './components/admin/WebsiteCMS';
import { UserManagement } from './components/admin/UserManagement';
import { ClientPortal } from './components/admin/ClientPortal';
import { ClientsHub } from './components/admin/ClientsHub';
import { CybersecurityHub } from './components/admin/CybersecurityHub';
import { ConversationsHub } from './components/admin/ConversationsHub';
import { ChatbotKnowledgeHub } from './components/admin/ChatbotKnowledgeHub';
import { TasksDeadlinesHub } from './components/admin/TasksDeadlinesHub';
import { NotificationsHub } from './components/admin/NotificationsHub';
import { AnalyticsHub } from './components/admin/AnalyticsHub';
import { AuditLogsHub } from './components/admin/AuditLogsHub';
import { SystemSettingsHub } from './components/admin/SystemSettingsHub';

function StudioApp() {
  const { user } = useAuth();
  const [view, setView] = useState<'public' | 'portal'>('public');
  const [activeAdminTab, setActiveAdminTab] = useState<AdminTab>('overview');
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<string>('Website Development');
  const [appliedScopeEstimate, setAppliedScopeEstimate] = useState<ScopeEstimate | null>(null);

  // Set default tab based on user role when entering portal
  useEffect(() => {
    if (user?.role === 'client') {
      setActiveAdminTab('client_portal');
    } else if (user?.role === 'developer') {
      setActiveAdminTab('projects');
    } else if (user?.role === 'super_admin' || user?.role === 'staff') {
      if (activeAdminTab === 'client_portal') {
        setActiveAdminTab('overview');
      }
    }
  }, [user]);

  const scrollToContact = (service?: string) => {
    if (service) {
      setSelectedService(service);
    }
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleApplyScopeEstimate = (estimate: ScopeEstimate) => {
    setAppliedScopeEstimate(estimate);
    setSelectedService(estimate.service);
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToWork = () => {
    const workElem = document.getElementById('work');
    if (workElem) {
      workElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToServices = () => {
    const svcElem = document.getElementById('services');
    if (svcElem) {
      svcElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenPortal = () => {
    if (!user) {
      setLoginModalOpen(true);
    } else {
      setView('portal');
    }
  };

  // Render Portal View (Full 18-Section Workspace)
  if (view === 'portal' && user) {
    return (
      <div className="relative min-h-screen bg-[#080D25] text-[#F4F6FB] selection:bg-[#FF5A1F] selection:text-white">
        <CustomCursor />
        <AdminLayout
          activeTab={activeAdminTab}
          onTabChange={(tab) => setActiveAdminTab(tab)}
          onBackToPublic={() => setView('public')}
        >
          {activeAdminTab === 'overview' && (
            <DashboardOverview onNavigateTab={(tab) => setActiveAdminTab(tab as AdminTab)} />
          )}
          {activeAdminTab === 'inquiries' && (
            <InquiryCRM onProjectCreated={() => setActiveAdminTab('projects')} />
          )}
          {activeAdminTab === 'clients' && <ClientsHub />}
          {activeAdminTab === 'services_packages' && <FinanceHub initialSubTab="packages" />}
          {activeAdminTab === 'quotations' && <FinanceHub initialSubTab="quotations" />}
          {activeAdminTab === 'invoices_payments' && <FinanceHub initialSubTab="invoices" />}
          {activeAdminTab === 'projects' && <ProjectHub />}
          {activeAdminTab === 'team' && <UserManagement />}
          {activeAdminTab === 'tasks' && <TasksDeadlinesHub />}
          {activeAdminTab === 'conversations' && <ConversationsHub />}
          {activeAdminTab === 'chatbot' && <ChatbotKnowledgeHub />}
          {activeAdminTab === 'meta' && <MetaCenter />}
          {activeAdminTab === 'cms' && <WebsiteCMS />}
          {activeAdminTab === 'cybersecurity' && <CybersecurityHub />}
          {activeAdminTab === 'notifications' && <NotificationsHub />}
          {activeAdminTab === 'analytics' && <AnalyticsHub />}
          {activeAdminTab === 'audit_logs' && <AuditLogsHub />}
          {activeAdminTab === 'settings' && <SystemSettingsHub />}
          {activeAdminTab === 'client_portal' && <ClientPortal />}
        </AdminLayout>
      </div>
    );
  }

  // Render Public Agency Website View
  return (
    <div className="relative min-h-screen bg-[#080D25] text-[#F4F6FB] selection:bg-[#FF5A1F] selection:text-white">
      {/* Desktop Magnetic Custom Circular Cursor */}
      <CustomCursor />

      {/* Dynamic Layered Background System */}
      <BackgroundAtmosphere />

      {/* Persistent Glass Navigation */}
      <Navbar
        onOpenContact={() => scrollToContact()}
        onOpenPortal={handleOpenPortal}
      />

      {/* Main Content Flow */}
      <main className="relative z-10">
        {/* 1. Hero Section: Build Smarter. Grow Faster. Stay Secure. */}
        <Hero
          onExploreWork={scrollToServices}
          onStartProject={() => scrollToContact()}
        />

        {/* 2. Services: Core Categories & Interactive Scope Estimator */}
        <Services
          onSelectService={(serviceTitle) => scrollToContact(serviceTitle)}
          onApplyScopeEstimate={handleApplyScopeEstimate}
        />

        {/* 3. Business Problems and Solutions */}
        <BusinessSolutions />

        {/* 4. Selected Work: Genuine Projects and Concepts */}
        <SelectedWork onStartProject={() => scrollToContact()} />

        {/* 5. Creative Process: From First Idea To Final Launch */}
        <CreativeProcess />

        {/* 6. Why AI SOFT STUDIO: Built Around Your Goals */}
        <WhyUs />

        {/* 7. Frequently Asked Questions */}
        <FAQ />

        {/* 8. Strong Final Call to Action */}
        <FinalCTA
          onStartProject={() => scrollToContact()}
          onExploreServices={scrollToServices}
        />

        {/* 9. Functional Contact & Backend Enquiry Registry */}
        <Contact
          preselectedService={selectedService}
          appliedScopeEstimate={appliedScopeEstimate}
          onClearAppliedEstimate={() => setAppliedScopeEstimate(null)}
        />
      </main>

      {/* 10. Studio Footer with Contact & Legal Modals */}
      <Footer />

      {/* 11. AI Chatbot & Automation Widget */}
      <WebsiteChatWidget />

      {/* 12. Authorized Team Credentials Sign-In Modal */}
      <LoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        onSuccess={() => {
          setLoginModalOpen(false);
          setView('portal');
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <StudioApp />
    </AuthProvider>
  );
}
